    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
    import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signOut, onAuthStateChanged, updatePassword, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
    import { getFirestore, initializeFirestore, persistentLocalCache, persistentMultipleTabManager, collection, doc, getDoc, setDoc, onSnapshot, getDocs, query, orderBy, serverTimestamp, updateDoc, deleteDoc, writeBatch, increment, where, limit } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

    const firebaseConfig = {
  apiKey: "AIzaSyCeju_nfB7nnf-dftrZwR5qXhssF2e9XQk",
  authDomain: "ludo-ff742.firebaseapp.com",
  projectId: "ludo-ff742",
  storageBucket: "ludo-ff742.firebasestorage.app",
  messagingSenderId: "246862675626",
  appId: "1:246862675626:web:e8bb5a705ae6fd9abc9ad3",
  measurementId: "G-E1L2FR6VKJ"
};

    const firebaseApp = initializeApp(firebaseConfig);
    const auth = getAuth(firebaseApp);
    let db;
    try { db = initializeFirestore(firebaseApp, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }), experimentalAutoDetectLongPolling: true }); }
    catch (e) { try { db = initializeFirestore(firebaseApp, { experimentalAutoDetectLongPolling: true }); } catch (e2) { db = getFirestore(firebaseApp); } }
    if (!window.lucide) window.lucide = { createIcons() {} };
    const __ci = lucide.createIcons; let __ct;
    lucide.createIcons = function () { cancelAnimationFrame(__ct); __ct = requestAnimationFrame(() => { try { __ci.call(lucide); } catch (e) {} }); };

    class UserClientApp {
      constructor() {
        this.appVersion = "v10.0.0";
        this.theme = localStorage.getItem('gghor_theme') || 'white';
        this.lang = localStorage.getItem('gghor_lang') || 'en';
        this.currentUser = null;
        this.currentView = 'home';
        this.products = [];
        this.categories = [];
        this.magazineCategories = [];
        this.banners = [];
        this.gateways = [];
        this.orders = [];
        this.notifications = [];
        this._ownNotifs = [];
        this._broadcasts = [];
        this._notifState = { read: {}, hidden: {} };
        this.wallets = { BDT: 0, USD: 0 };
        this.walletTransactions = [];
        this.recentlyViewedIds = [];
        this.currencyRates = { USD: 120 };
        this.selectedProduct = null;
        this.selectedItem = null;
        this.selectedPackage = null;
        this.selectedQuantity = 1;
        this.checkoutCurrency = 'BDT';
        this.checkoutPayMode = 'wallet';
        this.selectedInstantGateway = null;
        this.appliedDiscountCoupon = null;
        this.scrollText = "NexaGHOR-এ স্বাগতম!";
        this.tutorials = { depositUrl: '', orderUrl: '' };
        this.paymentDescription = "";
        this.orderDescription = "";
        this.activeDepositCurrency = 'BDT';
        this.selectedCategoryFilter = 'All'; this.magCategory = 'All';
        this.expandedCats = {};
        this.favs = new Set();
        this.ghorLevels = {};
        this.books = []; this.bookEps = []; this.bookFavs = new Set(); this.subscriptionPlans = {};
        this.bookReads = {}; this._readSeen = new Set(); this._subState = null; this._wbPos = null;
        this.curBookId = null; this.curEpId = null; this.curSeason = null; this._epText = {};
        this._reqSection = 'magazine';
      }

      /* ===== Favorites (প্রিয় পণ্য) ===== */
      loadFavs(uid) {
        try { this.favs = new Set(JSON.parse(localStorage.getItem('gghor_fav_' + (uid || 'guest')) || '[]')); }
        catch (e) { this.favs = new Set(); }
        this.scheduleRender && this.scheduleRender();
        this.updateFavButtons();
        this.loadBookFavs(uid);
      }
      isFav(id) { return this.favs.has(id); }
      toggleFav(id, ev) {
        if (ev) { ev.stopPropagation(); ev.preventDefault(); }
        if (!id) return;
        if (this.favs.has(id)) { this.favs.delete(id); this.toast('প্রিয় তালিকা থেকে সরানো হয়েছে'); }
        else { this.favs.add(id); this.toast('প্রিয় তালিকায় যোগ হয়েছে ❤', 'success'); }
        try { localStorage.setItem('gghor_fav_' + (this.currentUser ? this.currentUser.uid : 'guest'), JSON.stringify([...this.favs])); } catch (e) {}
        this.updateFavButtons();
        this.scheduleRender();
      }
      updateFavButtons() {
        const pid = this.selectedProduct && this.selectedProduct.id;
        ['productFavBtn', 'itemFavBtn'].forEach(i => { const b = document.getElementById(i); if (b) b.classList.toggle('on', !!pid && this.favs.has(pid)); });
      }
      _cmpName(a, b) { return String(a.name || '').localeCompare(String(b.name || ''), 'en', { numeric: true, sensitivity: 'base' }); }
      // Item Firstname + Package Name + Item Lastname; supports older items without prefix/suffix.
      _packageDisplayName(item, pkg) {
        return [item && item.firstName, pkg && pkg.name, item && item.lastName]
          .map(v => String(v == null ? '' : v).trim())
          .filter(Boolean)
          .join(' ');
      }
      _cmpFavName(a, b) { return (this.isFav(b.id) - this.isFav(a.id)) || this._cmpName(a, b); }
      _minPrice(p) {
        let m = null;
        (p.items || []).forEach(it => (it.packages || []).forEach(pk => { if (!pk.soldOut && (m === null || pk.bdtPaisa < m)) m = pk.bdtPaisa; }));
        return m;
      }
      _pkgUnavailable() {
        const p = this.products.find(x => x.id === (this.selectedProduct && this.selectedProduct.id));
        const it = p && (p.items || []).find(x => x.id === (this.selectedItem && this.selectedItem.id));
        const pk = it && (it.packages || []).find(x => x.id === (this.selectedPackage && this.selectedPackage.id));
        return !pk || !!pk.soldOut;
      }

      _dedupeInner(ids) {
        const d = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
        ids.forEach(id => {
          const el = document.getElementById(id); if (!el || el._dd) return; el._dd = 1;
          Object.defineProperty(el, 'innerHTML', { configurable: true, get() { return d.get.call(this); }, set(v) { if (this._lastH === v) return; this._lastH = v; d.set.call(this, v); } });
        });
      }
      init() {
        this._dedupeInner(['homeProductGrid','categoryScrollContainer','magazineGrid','magazineCategoryScroll','episodeList','seasonEpisodeList','recentlyViewedShelf']);
        this.applyTheme(this.theme);
        this.initLang();
        this.renderThemeBox();
        this.listenPublicData();
        getRedirectResult(auth).then(r => { if (r && r.user) return this.ensureGoogleProfile(r.user).then(() => { this.closeModal('userAuthModal'); this.toast('গুগল দিয়ে লগইন সফল!', 'success'); if (this.currentView === 'register') this.navigate('home'); }); }).catch(e => this.googleErr(e));
        onAuthStateChanged(auth, u => this.handleAuthState(u));
        this._reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
        this.initBubble();
        this.initPlayerGestures();
        this.initFloatBubbles();
        setInterval(() => { if (this.currentUser) this.checkSubState(false); }, 15000);
        this.newExpiryWatch();
        window.addEventListener('resize', () => { clearTimeout(this._rz); this._rz = setTimeout(() => { this.wbApplyPos();  }, 200); });
        lucide.createIcons();
      }

      applyTheme(t) {
        const h = document.documentElement; h.classList.add('theme-switching');
        clearTimeout(this._ts); this._ts = setTimeout(() => h.classList.remove('theme-switching'), 120);
        this.theme = t;
        document.documentElement.setAttribute('data-theme', t);
        try { localStorage.setItem('gghor_theme', t); } catch(e){}
      }
      renderThemeBox() {
        const T = [['dark','#0a0d14','#00f2fe','Dark'],['white','#f1f5f9','#0284c7','Light'],['blue','#060d1f','#60a5fa','Blue'],['green','#05110c','#22c55e','Green'],['pink','#14060e','#f472b6','Pink'],['yellow','#130f03','#facc15','Gold'],['red','#140606','#f87171','Red'],['purple','#0d0716','#c084fc','Purple']];
        const g = document.getElementById('themeGrid'); if (!g) return;
        const cur = T.find(x => x[0] === this.theme) || T[0];
        const n = document.getElementById('themeCurName'); if (n) n.textContent = cur[3];
        g.innerHTML = T.map(x => `<button type="button" class="theme-swatch ${x[0] === this.theme ? 'active' : ''}" onclick="app.applyTheme('${x[0]}'); app.renderThemeBox();"><span class="theme-dot" style="background:linear-gradient(135deg,${x[2]} 0 50%,${x[1]} 50% 100%)"></span><span>${x[3]}</span></button>`).join('');
      }

      initLang() {
        document.getElementById('langCurLabel').textContent = this.lang === 'bn' ? 'বাং' : 'EN';
        document.querySelectorAll('#langMenu button').forEach(b => b.classList.toggle('active', b.dataset.lang === this.lang));
      }
      toggleLangMenu(e) { e.stopPropagation(); document.getElementById('langMenu').classList.toggle('open'); }
      setLanguage(l) {
        this.lang = l;
        document.getElementById('langMenu').classList.remove('open');
        window.gghorSetLang(l);
        this.initLang();
        this.renderThemeBox();
      }

      toMinor(m) { return Math.round(Number(m) * 100); }
      toMajor(m) { return (Number(m) / 100).toFixed(2); }
      formatMoney(minor, cur = 'BDT') {
        const val = this.toMajor(minor);
        return cur === 'USD' ? `$ ${val}` : `৳ ${val}`;
      }
      convertFromBDT(bdtMinor, target) {
        if (target === 'USD') return Math.round(bdtMinor / (this.currencyRates.USD || 120));
        return bdtMinor;
      }

      listenPublicData() {
        onSnapshot(collection(db, 'books'), snap => {
          this.books = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.renderMagazine();
          if (['book', 'season', 'reader'].includes(this.currentView)) {
            const b = this.books.find(x => x.id === this.curBookId);
            if (!b || this._bookLocked(b)) { this.toast('এই বুকটি এখন উপলব্ধ নয়', 'danger'); this.navigate('magazine'); }
            else if (this.currentView === 'book') this.openBook(this.curBookId, true);
          }
        }, e => console.warn('books', e));
        onSnapshot(collection(db, 'book_episodes'), snap => {
          this.bookEps = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.renderMagazine();
          if (this.currentView === 'book') this.renderEpisodes();
          if (this.currentView === 'season' && this.curSeason != null) this.renderSeasonEpisodes(this.curSeason);
          if (this.currentView === 'reader') {
            const ep = this.bookEps.find(x => x.id === this.curEpId);
            if (!ep || this._episodeLocked(ep)) { this.toast('এই পর্বটি এখন লক করা হয়েছে', 'danger'); this.navigate('season'); if (this.curSeason != null) this.renderSeasonEpisodes(this.curSeason); }
            else this.updateReaderNav();
          }
        }, e => console.warn('book_episodes', e));
        onSnapshot(collection(db, 'book_reads'), snap => {
          this.bookReads = {};
          snap.docs.forEach(d => { this.bookReads[d.id] = Number(d.data().count) || 0; });
          this.renderMagazine();
          if (this.currentView === 'book' && this.curBookId) this.openBook(this.curBookId, true);
        }, e => console.warn('book_reads', e));
        onSnapshot(collection(db, 'ghor_levels'), snap => {
          this.ghorLevels = {};
          snap.docs.forEach(d => { const x = d.data(); if (x && x.logo) this.ghorLevels[d.id] = x.logo; });
          this.renderGhorCard();
        }, e => console.warn('ghor_levels', e));
        onSnapshot(doc(db, 'settings', 'app'), snap => {
          if (!snap.exists()) return;
          const d = snap.data();
          this.scrollText = d.scrollText || 'NexaGHOR-এ স্বাগতম!';
          const mq = document.getElementById('homeMarqueeText'); if (mq) mq.textContent = this.scrollText;
          if (d.currencyRates) this.currencyRates = { USD: Number(d.currencyRates.USD) || 120 };
          this.tutorials = d.tutorials || { depositUrl: '', orderUrl: '' };
          this.paymentDescription = d.paymentDescription || '';
          this.orderDescription = d.orderDescription || '';
          this.subscriptionPlans = d.subscriptionPlans || {}; this.renderMagazineSubscriptions();
          if (d.appUpdateConfig) this.checkUpdateLock(d.appUpdateConfig);
          if (d.headerCfg) {
            const h = d.headerCfg;
            const nm = h.name || 'NexaGHOR';
            document.querySelectorAll('.brand-text h1').forEach(el => el.textContent = nm);
            const tg = document.getElementById('hdrBrandTag'); if (tg) tg.textContent = h.tagline || 'Your Digital World';
            document.documentElement.style.setProperty('--header-height', (Number(h.height) > 0 ? Number(h.height) : 68) + 'px');
            const b = document.getElementById('hdrLogoBox');
            if (b) {
              const ls = Number(h.logoSize) > 0 ? Number(h.logoSize) : 36;
              b.style.width = ls + 'px'; b.style.height = ls + 'px';
              if (h.logo) { b.classList.add('has-logo'); b.innerHTML = `<img src="${h.logo}" alt="logo">`; }
              else { b.classList.remove('has-logo'); b.textContent = nm.charAt(0).toUpperCase(); }
            }
          }
          this.refreshLive();
        });

        onSnapshot(collection(db, 'banners'), snap => {
          this.banners = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.renderBanners();
        });

        onSnapshot(collection(db, 'categories'), snap => {
          this.categories = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          if (this.selectedCategoryFilter !== 'All' && !this.categories.some(c => c.name === this.selectedCategoryFilter)) this.selectedCategoryFilter = 'All';
          this.renderCategories();
          this.scheduleRender();
        });

        onSnapshot(collection(db, 'magazine_categories'), snap => { this.magazineCategories = snap.docs.map(d => ({ id: d.id, ...d.data() })); this.renderMagazineCategories(); this.renderMagazine(); });
        let P = [], I = [];
        const merge = () => {
          const m = {}; I.forEach(it => { (m[it.productId] = m[it.productId] || []).push(it); });
          this.products = P.map(p => ({ ...p, items: m[p.id] || [] }));
          this.scheduleRender();
          this.refreshLive();
        };
        onSnapshot(collection(db, 'products'), sn => { P = sn.docs.map(d => ({ id: d.id, ...d.data() })); merge(); });
        onSnapshot(collection(db, 'items'), sn => { I = sn.docs.map(d => ({ id: d.id, ...d.data() })); merge(); });

        onSnapshot(collection(db, 'gateways'), snap => {
          this.gateways = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          const am = document.getElementById('addMoneyModal');
          if (am && am.classList.contains('active')) this.switchDepositCurrencyTab(this.activeDepositCurrency);
          if (this.currentView === 'checkout' && this.checkoutPayMode === 'instant') this.renderGatewaysForCheckout();
        });

        onSnapshot(collection(db, 'broadcasts'), snap => {
          this._broadcasts = snap.docs.map(d => ({ ...d.data(), id: d.id }));
          this.rebuildNotifications();
        });
      }

      renderBanners() {
        const c = document.getElementById('bannerSlidesContainer');
        const d = document.getElementById('bannerDotsContainer');
        if (!this.banners.length) { c.innerHTML = '<div class="banner-slide active" style="background:#111726;"></div>'; return; }
        c.innerHTML = this.banners.map((b, i) => `<div class="banner-slide ${i === 0 ? 'active' : ''}" style="background-image:url('${b.image}')"></div>`).join('');
        d.innerHTML = this.banners.map((_, i) => `<div class="banner-dot ${i === 0 ? 'active' : ''}" onclick="app.goBanner(${i})"></div>`).join('');
        this.goBanner(0);
      }

      goBanner(i) {
        const sl = document.querySelectorAll('#bannerSlidesContainer .banner-slide'), dt = document.querySelectorAll('#bannerDotsContainer .banner-dot');
        sl.forEach((x, k) => x.classList.toggle('active', k === i)); dt.forEach((x, k) => x.classList.toggle('active', k === i));
        clearTimeout(this._bt);
        if (sl.length > 1) this._bt = setTimeout(() => this.goBanner((i + 1) % sl.length), 5000);
      }

      renderCategories() {
        const c = document.getElementById('categoryScrollContainer');
        c.innerHTML = `<div class="cat-chip ${this.selectedCategoryFilter === 'All' ? 'active' : ''}" onclick="app.filterCat('All')">সব ক্যাটেগরি</div>` +
          this.categories.map(cat => `<div class="cat-chip ${this.selectedCategoryFilter === cat.name ? 'active' : ''}" onclick="app.filterCat('${cat.name}')">${cat.name}</div>`).join('');
      }

      filterCat(name) {
        this.selectedCategoryFilter = name;
        this.renderCategories();
        this.renderProducts();
      }

      renderProducts(search = '') {
        const c = document.getElementById('homeProductGrid');
        let list = this.products.slice();
        if (this.selectedCategoryFilter !== 'All') list = list.filter(p => p.category === this.selectedCategoryFilter);
        if (search) list = list.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
        list.sort((a, b) => this._cmpFavName(a, b));

        document.getElementById('productCountLabel').textContent = `${list.length}টি পণ্য`;
        if (!list.length) {
          c.classList.remove('grouped');
          c.innerHTML = `<div style="grid-column:1/-1; text-align:center; padding:30px; color:var(--text-dim);">কোনো পণ্য পাওয়া যায়নি</div>`;
          return;
        }

        const card = p => {
          const fav = this.isFav(p.id);
          const mn = this._minPrice(p);
          return `
          <div class="home-product-card" onclick="app.openProduct('${p.id}')">
            <div class="home-product-thumb">
              <img src="${p.image || ''}" alt="${p.name}" loading="eager" decoding="async" />
              ${p.category ? `<span class="hp-tag">${p.category}</span>` : ''}
              <button type="button" class="fav-btn ${fav ? 'on' : ''}" onclick="app.toggleFav('${p.id}', event)" aria-label="Favorite"><i data-lucide="heart"></i></button>
            </div>
            <div class="home-product-info">
              <h4 class="home-product-name">${p.name}</h4>
              <div class="hp-foot">
                <span>${(p.items || []).length}টি আইটেম</span>
                ${mn === null ? '<span class="hp-from none">SOLD OUT</span>' : `<span class="hp-from">৳ ${this.toMajor(mn)}+</span>`}
              </div>
            </div>
          </div>
        `; };

        if (search || this.selectedCategoryFilter !== 'All') {
          c.classList.remove('grouped');
          c.innerHTML = list.map(card).join('');
        } else {
          const limit = 9;
          const names = this.categories.map(cat => cat.name);
          const groups = [];
          const favList = list.filter(p => this.isFav(p.id));
          if (favList.length) groups.push({ name: '❤ প্রিয় পণ্য', items: favList, fav: true });
          names.forEach(n => {
            const items = list.filter(p => p.category === n);
            if (items.length) groups.push({ name: n, items });
          });
          const other = list.filter(p => !names.includes(p.category));
          if (other.length) groups.push({ name: 'অন্যান্য', items: other });

          c.classList.add('grouped');
          c.innerHTML = groups.map(g => {
            const exp = !!this.expandedCats[g.name];
            const hasMore = g.items.length > limit;
            const shown = exp || !hasMore ? g.items : g.items.slice(0, limit);
            return `
              <div class="cat-section ${g.fav ? 'fav-section' : ''}">
                <div class="cat-section-head">
                  <span class="cat-section-bar"></span>
                  <span class="cat-section-title">${g.name}</span>
                  <span class="cat-section-count">${g.items.length}টি পণ্য</span>
                </div>
                <div class="cat-grid">${shown.map(card).join('')}</div>
                ${hasMore ? `
                  <button type="button" class="cat-more-btn" onclick="app.toggleCatMore('${g.name}')">
                    ${exp ? 'কম দেখুন' : `আরও দেখুন (${g.items.length - limit})`}
                  </button>
                ` : ''}
              </div>
            `;
          }).join('');
        }
        lucide.createIcons();
      }

      toggleCatMore(catName) {
        this.expandedCats[catName] = !this.expandedCats[catName];
        this.renderProducts();
      }

      scheduleRender() {
        if (this._rq) return; this._rq = true;
        requestAnimationFrame(() => { this._rq = false; this.renderProducts(this._search || ''); this.renderShelves(); });
      }
      handleSearch(v) { this._search = v.trim(); this.renderProducts(this._search); }

      openProduct(pid, silent = false) {
        const p = this.products.find(x => x.id === pid);
        if (!p) return;
        this.selectedProduct = p;
        if (!silent) {
          this.recentlyViewedIds = [pid, ...this.recentlyViewedIds.filter(x => x !== pid)].slice(0, 4);
          this.renderShelves();
        }
        document.getElementById('productItemsTopImg').src = p.image || '';
        document.getElementById('productHeroBg').style.backgroundImage = p.image ? `url('${p.image}')` : 'none';
        document.getElementById('productItemsTitle').textContent = p.name;
        const nItems = (p.items || []).length;
        document.getElementById('productHeroChips').innerHTML =
          (p.category ? `<span class="ph-chip">${p.category}</span>` : '') +
          `<span class="ph-chip">${nItems}টি আইটেম</span>` +
          `<span class="ph-chip green">⚡ ইনস্ট্যান্ট ডেলিভারি</span>`;
        this.updateFavButtons();
        const grid = document.getElementById('productItemsGrid');
        const sortedItems = (p.items || []).slice().sort((a, b) => this._cmpName(a, b));
        grid.innerHTML = sortedItems.map(it => {
          const pkgs = it.packages || [];
          const allSold = pkgs.length > 0 && pkgs.every(x => x.soldOut);
          let prText = 'মূল্য নেই';
          if (pkgs.length) {
            const prices = pkgs.map(x => x.bdtPaisa);
            const min = Math.min(...prices), max = Math.max(...prices);
            prText = min === max ? `৳ ${this.toMajor(min)}` : `৳ ${this.toMajor(min)} - ৳ ${this.toMajor(max)}`;
          }
          return `
            <div class="item-card-vertical ${allSold ? 'is-sold' : ''}" onclick="app.openItem('${it.id}')">
              <div class="ic-img">
                <img src="${it.photo || ''}" alt="${it.name}" loading="eager" decoding="async" />
                ${allSold ? '<span class="ic-soldout">SOLD OUT</span>' : ''}
              </div>
              <div class="ic-body">
                <div class="item-card-title">${it.name}</div>
                <div class="item-card-price-range">${prText}</div>
              </div>
            </div>
          `;
        }).join('') || '<div style="grid-column:1/-1; text-align:center; color:var(--text-muted);">কোনো আইটেম নেই</div>';
        if (!silent) this.navigate('product-items');
        lucide.createIcons();
      }

      /* Admin যা পরিবর্তন করে তা ইউজারের খোলা পেজেও লাইভ আপডেট হয় */
      refreshLive() {
        try {
          const v = this.currentView;
          const am = document.getElementById('addMoneyModal');
          if (am && am.classList.contains('active')) {
            document.getElementById('addMoneyPaymentDesc').innerHTML = `<div class="desc-body">${this.paymentDescription || 'নির্দেশিকা অনুযায়ী পেমেন্ট সম্পন্ন করুন।'}</div>`;
          }
          if (!this.selectedProduct) return;
          const p = this.products.find(x => x.id === this.selectedProduct.id);
          if (!p) {
            if (v === 'product-items' || v === 'item-packages') { this.toast('এই পণ্যটি আর পাওয়া যাচ্ছে না', 'danger'); this.selectedProduct = null; this.selectedItem = null; this.selectedPackage = null; this.navigate('home'); }
            return;
          }
          this.selectedProduct = p;
          const it = this.selectedItem ? (p.items || []).find(x => x.id === this.selectedItem.id) : null;
          if (v === 'product-items') { this.openProduct(p.id, true); return; }
          if (!it) {
            if (v === 'item-packages') { this.selectedItem = null; this.selectedPackage = null; this.openProduct(p.id); }
            return;
          }
          this.selectedItem = it;
          if (v === 'item-packages') { this.openItem(it.id, true); return; }
          if (v === 'checkout') {
            const pk = this.selectedPackage ? (it.packages || []).find(x => x.id === this.selectedPackage.id) : null;
            if (!pk || pk.soldOut) {
              this.toast('এই প্যাকেজটি এখন সোল্ড আউট! অন্য প্যাকেজ বেছে নিন', 'danger');
              this.openItem(it.id, true);
              this.navigate('item-packages');
              return;
            }
            if (pk) {
              this.selectedPackage = pk;
              document.getElementById('checkoutItemName').textContent = it.name;
              document.getElementById('checkoutPackageName').textContent = this._packageDisplayName(it, pk);
              this.updateCheckoutTotal();
            }
          }
        } catch (e) { console.warn('refreshLive', e); }
      }

      openItem(itid, silent = false) {
        const it = (this.selectedProduct?.items || []).find(x => x.id === itid);
        if (!it) return;
        const keep = {};
        if (silent) {
          ['dynPlayerId', 'dynZoneId', 'dynPlatformSelect', 'dynServerSelect'].forEach(i => { const e = document.getElementById(i); if (e) keep[i] = e.value; });
          keep.pkg = this.selectedPackage && this.selectedPackage.id;
        }
        this.selectedItem = it;
        if (!silent) this.selectedQuantity = 1;
        document.getElementById('packageItemThumb').src = it.photo || '';
        document.getElementById('packageItemHeading').textContent = it.name;
        document.getElementById('packageItemDesc').textContent = it.description || '';
        document.getElementById('packageOrderInstructions').innerHTML = `<div class="desc-body">${this.orderDescription || 'সঠিক তথ্য প্রদান করে অর্ডার করুন।'}</div>`;

        let f = '';
        if (it.options?.playerId) f += `<div class="input-group"><label class="input-label">${it.options?.playerIdLabel || 'Player ID'} *</label><input type="text" id="dynPlayerId" class="input-control" placeholder="${it.options?.playerIdPlaceholder || 'আপনার Player ID লিখুন'}" required /></div>`;
        if (it.options?.zoneId) f += `<div class="input-group"><label class="input-label">${it.options?.zoneIdLabel || 'Zone ID'} *</label><input type="text" id="dynZoneId" class="input-control" placeholder="${it.options?.zoneIdPlaceholder || 'Zone ID লিখুন'}" required /></div>`;
        if (it.platformEnabled && (it.platforms || []).length) {
          f += `<div class="input-group"><label class="input-label">Select Platform *</label><select id="dynPlatformSelect" class="input-control"><option value="">-- Platform নির্বাচন করুন --</option>${it.platforms.map(x => `<option value="${x}">${x}</option>`).join('')}</select></div>`;
        }
        if (it.serverEnabled && (it.servers || []).length) {
          f += `<div class="input-group"><label class="input-label">Select Server *</label><select id="dynServerSelect" class="input-control"><option value="">-- Server নির্বাচন করুন --</option>${it.servers.map(x => `<option value="${x}">${x}</option>`).join('')}</select></div>`;
        }
        if (it.options?.quantity) f += `<div class="input-group"><label class="input-label">পরিমাণ</label><div class="qty-picker"><button type="button" class="qty-btn" onclick="app.setQty(-1)">-</button><span class="qty-val" id="dynQty">1</span><button type="button" class="qty-btn" onclick="app.setQty(1)">+</button></div></div>`;
        document.getElementById('itemDynamicFieldsContainer').innerHTML = f;
        if (silent) {
          Object.keys(keep).forEach(k => { if (k === 'pkg') return; const e = document.getElementById(k); if (e) e.value = keep[k]; });
          const q = document.getElementById('dynQty'); if (q) q.textContent = this.selectedQuantity;
        }

        const pGrid = document.getElementById('itemPackagesGrid');
        const pkgs = (it.packages || []).slice().sort((a, b) => (a.bdtPaisa - b.bdtPaisa) || String(a.name || '').localeCompare(String(b.name || '')));
        this.selectedPackage = (silent && keep.pkg && pkgs.find(x => x.id === keep.pkg && !x.soldOut)) || pkgs.find(x => !x.soldOut) || null;
        pGrid.innerHTML = pkgs.map(pk => `
          <div class="package-item ${(this.selectedPackage && pk.id === this.selectedPackage.id) ? 'selected' : ''} ${pk.soldOut ? 'sold-out' : ''}" ${pk.soldOut ? 'aria-disabled="true"' : `onclick="app.selectPkg('${pk.id}')"`} data-pkid="${pk.id}">
            <div class="pk-name">${this._esc(this._packageDisplayName(it, pk))}</div>
            <div class="premium-package-price">${this.formatMoney(pk.bdtPaisa, 'BDT')}</div>
            <div class="premium-package-alt-price">${this.formatMoney(this.convertFromBDT(pk.bdtPaisa, 'USD'), 'USD')}</div>
            ${pk.soldOut ? '<span class="pk-sold">SOLD OUT</span>' : ''}
          </div>
        `).join('') || '<div style="color:var(--text-muted); grid-column:1/-1;">কোনো প্যাকেজ নেই</div>';

        this.updateFavButtons();
        this.updatePkgTotal();
        if (!silent) this.navigate('item-packages');
        lucide.createIcons();
      }

      setQty(d) {
        this.selectedQuantity = Math.max(1, this.selectedQuantity + d);
        const el = document.getElementById('dynQty'); if (el) el.textContent = this.selectedQuantity;
        this.updatePkgTotal();
      }
      selectPkg(id) {
        const pk = (this.selectedItem?.packages || []).find(p => p.id === id);
        if (!pk) return;
        if (pk.soldOut) { this.toast('এই প্যাকেজটি সোল্ড আউট!', 'danger'); return; }
        this.selectedPackage = pk;
        document.querySelectorAll('#itemPackagesGrid .package-item').forEach(el => el.classList.toggle('selected', el.dataset.pkid === id));
        this.updatePkgTotal();
      }
      updatePkgTotal() {
        const btn = document.getElementById('pkgCheckoutBtn');
        if (btn) {
          const none = !this.selectedPackage;
          btn.disabled = none;
          btn.classList.toggle('is-disabled', none);
          btn.innerHTML = none ? '<i data-lucide="ban"></i> সকল প্যাকেজ সোল্ড আউট' : '<i data-lucide="shopping-bag"></i> চেকআউটে এগিয়ে যান';
        }
        if (!this.selectedPackage) {
          document.getElementById('pkgPriceBDT').textContent = this.formatMoney(0, 'BDT');
          document.getElementById('pkgPriceUSD').textContent = this.formatMoney(0, 'USD');
          lucide.createIcons();
          return;
        }
        const tot = this.selectedPackage.bdtPaisa * this.selectedQuantity;
        document.getElementById('pkgPriceBDT').textContent = this.formatMoney(tot, 'BDT');
        document.getElementById('pkgPriceUSD').textContent = this.formatMoney(this.convertFromBDT(tot, 'USD'), 'USD');
      }

      initiateCheckout() {
        if (!this.currentUser) { this.toast('অর্ডার করতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        if (!this.selectedPackage) { this.toast('প্যাকেজ নির্বাচন করুন', 'danger'); return; }
        if (this._pkgUnavailable()) { this.toast('এই প্যাকেজটি সোল্ড আউট! চেকআউট করা যাবে না', 'danger'); this.openItem(this.selectedItem.id, true); return; }

        let reqData = [];
        if (this.selectedItem.options?.playerId) {
          const val = document.getElementById('dynPlayerId')?.value.trim();
          if (!val) { this.toast('Player ID দিন', 'danger'); return; }
          reqData.push(`Player ID: ${val}`);
        }
        if (this.selectedItem.options?.zoneId) {
          const val = document.getElementById('dynZoneId')?.value.trim();
          if (!val) { this.toast('Zone ID দিন', 'danger'); return; }
          reqData.push(`Zone ID: ${val}`);
        }
        if (this.selectedItem.platformEnabled && (this.selectedItem.platforms || []).length) {
          const val = document.getElementById('dynPlatformSelect')?.value;
          if (!val) { this.toast('Platform নির্বাচন করুন', 'danger'); return; }
          reqData.push(`Platform: ${val}`);
        }
        if (this.selectedItem.serverEnabled && (this.selectedItem.servers || []).length) {
          const val = document.getElementById('dynServerSelect')?.value;
          if (!val) { this.toast('Server নির্বাচন করুন', 'danger'); return; }
          reqData.push(`Server: ${val}`);
        }
        this.orderMeta = reqData.join(' | ');

        document.getElementById('checkoutItemName').textContent = this.selectedItem.name;
        document.getElementById('checkoutPackageName').textContent = this._packageDisplayName(this.selectedItem, this.selectedPackage);
        document.getElementById('checkoutQtyDisplay').textContent = this.selectedQuantity;
        document.getElementById('checkoutAccountMeta').textContent = this.orderMeta || 'N/A';
        this.appliedDiscountCoupon = null;
        document.getElementById('checkoutDiscountRow').style.display = 'none';
        this.updateCheckoutTotal();
        this.navigate('checkout');
      }

      setCheckoutCurrency(c) {
        if (!['BDT', 'USD'].includes(c)) c = 'BDT';
        this.checkoutCurrency = c;
        ['BDT', 'USD'].forEach(x => document.getElementById(`chkTab${x}`).classList.toggle('active', x === c));
        this.updateCheckoutTotal();
        if (this.checkoutPayMode === 'instant') this.renderGatewaysForCheckout();
      }

      setCheckoutPayMode(m) {
        this.checkoutPayMode = m;
        document.getElementById('paymodeWalletBtn').classList.toggle('active', m === 'wallet');
        document.getElementById('paymodeInstantBtn').classList.toggle('active', m === 'instant');
        document.getElementById('checkoutInstantGatewaysArea').style.display = m === 'instant' ? 'block' : 'none';
        if (m === 'instant') this.renderGatewaysForCheckout();
      }

      renderGatewaysForCheckout() {
        const c = document.getElementById('checkoutGatewaysList');
        const list = this.gateways.filter(g => this.gwCur(g) === this.checkoutCurrency);
        c.innerHTML = list.map((g, idx) => `
          <div class="package-item ${idx === 0 ? 'selected' : ''}" onclick="app.selectInstantGw('${g.id}')">
            <div style="font-weight:700;">${g.name}</div>
          </div>
        `).join('') || '<div style="color:var(--text-muted); grid-column:1/-1;">কোনো গেটওয়ে নেই</div>';
        if (list[0]) this.selectInstantGw(list[0].id);
      }

      selectInstantGw(gid) {
        const gw = this.gateways.find(g => g.id === gid);
        if (!gw) return;
        this.selectedInstantGateway = gw;
        const box = document.getElementById('checkoutGatewayInstructionBox');
        box.style.display = 'block';
        document.getElementById('gatewayInstructionTitle').textContent = `${gw.name} (${gw.number})`;
        document.getElementById('gatewayInstructionBody').textContent = gw.instructions;
      }

      /* ===== Common helpers (deposit / coupon) ===== */
      gwCur(g) { const c = String(g.currency || '').toUpperCase(); return ['BDT','USD'].includes(c) ? c : null; }
      _timeout(p, ms = 25000) {
        return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
      }
      _errMsg(e) {
        const c = String((e && e.code) || ''), m = String((e && e.message) || e || '');
        if (c.includes('permission-denied') || /insufficient permissions/i.test(m)) return 'সার্ভার অনুমতি দিচ্ছে না (Firestore Rules আপডেট প্রয়োজন)';
        if (c.includes('unavailable') || c.includes('network') || m === 'timeout') return 'ইন্টারনেট/সার্ভার সমস্যা, আবার চেষ্টা করুন';
        return 'ত্রুটি: ' + (m || 'অজানা সমস্যা');
      }
      _isPerm(e) { return String((e && e.code) || '').includes('permission') || /insufficient permissions/i.test(String((e && e.message) || '')); }
      _lock(key) { if (this['_busy_' + key]) return false; this['_busy_' + key] = true; return true; }
      _unlock(key) { this['_busy_' + key] = false; }

      async fetchCoupon(code) {
        const s = await this._timeout(getDoc(doc(db, 'coupons', code)));
        if (s.exists()) return { _id: s.id, ...s.data() };
        for (const v of [code, code.toLowerCase()]) {
          try {
            const q = await this._timeout(getDocs(query(collection(db, 'coupons'), where('code', '==', v), limit(1))));
            if (!q.empty) { const d = q.docs[0]; return { _id: d.id, ...d.data() }; }
          } catch (e) { /* ignore */ }
        }
        return null;
      }
      _couponExpired(exp) {
        if (!exp) return false;
        let t;
        if (typeof exp.toDate === 'function') t = exp.toDate().getTime();
        else if (typeof exp === 'number') t = exp;
        else { const s = String(exp).trim(); t = new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? s + 'T23:59:59' : s).getTime(); }
        return !isNaN(t) && t < Date.now();
      }
      _couponAmount(c) { return Number(c.amount ?? c.value ?? c.discount ?? 0); }
      // returns error text or '' if the coupon is usable
      _couponProblem(c, type) {
        if (!c || String(c.type || '').toLowerCase() !== type) return type === 'cash' ? 'ভুল ক্যাশ কুপন কোড!' : 'অবৈধ ডিসকাউন্ট কুপন!';
        if (c.active === false) return 'এই কুপনটি বর্তমানে নিষ্ক্রিয়!';
        if (this._couponExpired(c.expiry)) return 'কুপনের মেয়াদ শেষ!';
        const max = Number(c.maxUsers);
        if (max > 0 && Number(c.usedCount || 0) >= max) return 'কুপন লিমিট শেষ!';
        if (!(this._couponAmount(c) > 0)) return 'অবৈধ কুপন (পরিমাণ সঠিক নয়)!';
        return '';
      }

      async guardCoupon(code) {
        if (!this.currentUser) { this.toast('কুপন ব্যবহার করতে লগইন করুন', 'danger'); this.openAuthModal(); return false; }
        try {
          const u = await this._timeout(getDoc(doc(db, 'users', this.currentUser.uid, 'usedCoupons', code)));
          if (u.exists()) { this.toast('আপনি এই কুপনটি ইতিমধ্যে ব্যবহার করেছেন!', 'danger'); return false; }
        } catch (e) {
          this.toast(this._errMsg(e), 'danger'); return false;
        }
        return true;
      }

      async applyOrderCoupon() {
        const code = document.getElementById('orderCouponInput').value.trim().toUpperCase();
        if (!code) { this.toast('কুপন কোড দিন', 'danger'); return; }
        if (!this.selectedPackage) return;
        if (!this._lock('cpn')) return;
        try {
          if (!(await this.guardCoupon(code))) return;
          const c = await this.fetchCoupon(code);
          const bad = this._couponProblem(c, 'discount');
          if (bad) { this.toast(bad, 'danger'); return; }
          this.appliedDiscountCoupon = { ...c, code, amount: this._couponAmount(c) };
          this.toast('কুপন প্রয়োগ করা হয়েছে!', 'success');
          this.updateCheckoutTotal();
        } catch (e) {
          console.error('applyOrderCoupon', e);
          this.toast(this._errMsg(e), 'danger');
        } finally { this._unlock('cpn'); }
      }

      updateCheckoutTotal() {
        const base = this.selectedPackage.bdtPaisa * this.selectedQuantity;
        let tot = this.convertFromBDT(base, this.checkoutCurrency);
        document.getElementById('checkoutSubtotal').textContent = this.formatMoney(tot, this.checkoutCurrency);

        if (this.appliedDiscountCoupon) {
          const disc = this.convertFromBDT(this.toMinor(this.appliedDiscountCoupon.amount), this.checkoutCurrency);
          const finalTot = Math.max(0, tot - disc);
          document.getElementById('checkoutDiscountRow').style.display = 'flex';
          document.getElementById('appliedCouponCodeTag').textContent = this.appliedDiscountCoupon.code;
          document.getElementById('checkoutDiscountAmount').textContent = `-${this.formatMoney(disc, this.checkoutCurrency)}`;
          document.getElementById('checkoutFinalTotal').textContent = this.formatMoney(finalTot, this.checkoutCurrency);
        } else {
          document.getElementById('checkoutDiscountRow').style.display = 'none';
          document.getElementById('checkoutFinalTotal').textContent = this.formatMoney(tot, this.checkoutCurrency);
        }
      }

      async submitOrderPayment() {
        if (!this.currentUser) { this.toast('অর্ডার করতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        if (!this.selectedPackage || !this.selectedItem || !this.selectedProduct) return;
        if (this._pkgUnavailable()) { this.toast('এই প্যাকেজটি সোল্ড আউট! অর্ডার করা যাবে না', 'danger'); this.openItem(this.selectedItem.id, true); this.navigate('item-packages'); return; }
        if (!this._lock('order')) return;
        try {
          const ordId = 'ORD-' + Math.floor(10000000 + Math.random() * 90000000);
          const curr = this.checkoutCurrency;
          const base = this.selectedPackage.bdtPaisa * this.selectedQuantity;
          let tot = this.convertFromBDT(base, curr);
          let cpn = this.appliedDiscountCoupon;

          if (cpn) {
            // re-verify coupon at the final moment
            if (!(await this.guardCoupon(cpn.code))) { this.appliedDiscountCoupon = null; this.updateCheckoutTotal(); return; }
            const fresh = await this.fetchCoupon(cpn.code);
            const bad = this._couponProblem(fresh, 'discount');
            if (bad) { this.toast(bad, 'danger'); this.appliedDiscountCoupon = null; this.updateCheckoutTotal(); return; }
            cpn = this.appliedDiscountCoupon = { ...fresh, code: cpn.code, amount: this._couponAmount(fresh) };
            const disc = this.convertFromBDT(this.toMinor(cpn.amount), curr);
            tot = Math.max(0, tot - disc);
          }

          let trx = '';
          if (this.checkoutPayMode === 'wallet') {
            if ((this.wallets[curr] || 0) < tot) { this.toast('ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই!', 'danger'); return; }
          } else {
            trx = document.getElementById('orderTrxId').value.trim();
            if (!trx) { this.toast('TrxID প্রদান করুন', 'danger'); return; }
          }

          const orderData = {
            id: ordId, orderNumber: ordId, userId: this.currentUser.uid, userEmail: this.currentUser.email,
            productName: this.selectedProduct.name, itemName: this.selectedItem.name, packageName: this._packageDisplayName(this.selectedItem, this.selectedPackage),
            quantity: this.selectedQuantity, totalPaisa: tot, currency: curr,
            requiredInfo: this.orderMeta || 'N/A',
            paymentMethod: this.checkoutPayMode === 'wallet' ? 'Wallet' : `Instant (${this.selectedInstantGateway?.name || 'Direct'})`,
            trxId: this.checkoutPayMode === 'wallet' ? 'WLT-' + Date.now() : trx,
            status: 'pending', createdAt: new Date().toISOString()
          };
          if (cpn) { orderData.couponCode = cpn.code; orderData.couponDiscountBDT = cpn.amount; }

          const build = (b, withCounter) => {
            if (this.checkoutPayMode === 'wallet') {
              b.set(doc(db, 'wallets', this.currentUser.uid), { [curr]: increment(-tot) }, { merge: true });
              b.set(doc(db, 'wallets', this.currentUser.uid, 'txs', 'TXN-' + Date.now()), {
                title: `পণ্য ক্রয়: ${this.selectedProduct.name}`, amountPaisa: -tot, currency: curr, date: new Date().toISOString()
              });
            }
            b.set(doc(db, 'orders', ordId), orderData);
            if (cpn) {
              b.set(doc(db, 'users', this.currentUser.uid, 'usedCoupons', cpn.code), { code: cpn.code, type: 'discount', usedAt: new Date().toISOString() });
              if (withCounter) b.update(doc(db, 'coupons', cpn._id || cpn.code), { usedCount: increment(1) });
            }
          };
          await this.commitSmart(build, cpn ? (cpn._id || cpn.code) : null);

          const L = '━━━━━━━━━━━━━━━━━━';
          this.addUserNotification('✅ অর্ডার সফলভাবে গ্রহণ করা হয়েছে',
            `প্রিয় গ্রাহক,\n\nআপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে। আমাদের টিম যাচাই করে দ্রুত প্রসেস করবে।\n\n${L}\n🧾 অর্ডার নম্বর: #${ordId}\n🎮 পণ্য: ${orderData.productName} — ${orderData.itemName}\n📦 প্যাকেজ: ${orderData.packageName} × ${orderData.quantity}\n💳 পেমেন্ট: ${orderData.paymentMethod}\n💰 সর্বমোট: ${this.formatMoney(tot, curr)}\n📌 স্ট্যাটাস: পেন্ডিং\n${L}\n\n“আমার অর্ডারসমূহ” পেজে অর্ডারের সর্বশেষ অবস্থা দেখতে পারবেন।\nNexaGHOR-এর সাথে থাকার জন্য ধন্যবাদ। 💙`, 'order',
            { title: '✅ Order Placed Successfully', message: `Dear customer,\n\nYour order has been received successfully. Our team will verify and process it shortly.\n\n${L}\n🧾 Order No: #${ordId}\n🎮 Product: ${orderData.productName} — ${orderData.itemName}\n📦 Package: ${orderData.packageName} × ${orderData.quantity}\n💳 Payment: ${orderData.paymentMethod}\n💰 Total: ${this.formatMoney(tot, curr)}\n📌 Status: Pending\n${L}\n\nYou can track your order in the “My Orders” page.\nThank you for choosing NexaGHOR. 💙` });
          this.toast('অর্ডার সফলভাবে জমা দেওয়া হয়েছে!', 'success');
          this.appliedDiscountCoupon = null; document.getElementById('orderCouponInput').value = '';
          const t = document.getElementById('orderTrxId'); if (t) t.value = '';
          this.navigate('orders');
        } catch (e) {
          console.error('submitOrderPayment', e);
          this.toast(this._errMsg(e), 'danger');
        } finally { this._unlock('order'); }
      }

      // Atomic commit: ওয়ালেট + অর্ডার + কুপন ব্যবহার + কুপন কাউন্টার একসাথে সফল হবে, নয়তো কিছুই হবে না
      async commitSmart(build, counterDocId) {
        const b = writeBatch(db);
        build(b, true);
        try { await this._timeout(b.commit()); }
        catch (e) {
          if (counterDocId && this._isPerm(e)) throw new Error('কুপনটি এখন আর ব্যবহার করা যাচ্ছে না (লিমিট শেষ / মেয়াদ শেষ / আগেই ব্যবহৃত)');
          throw e;
        }
      }

      handleAuthState(u) {
        this.currentUser = u;
        if (this._profUnsub) { try { this._profUnsub(); } catch (e) {} this._profUnsub = null; }
        this.loadFavs(u ? u.uid : null);
        if (u) {
          // এডমিন ইউজার তথ্য এডিট করলে লাইভ আপডেট হবে
          this._profUnsub = onSnapshot(doc(db, 'users', u.uid), s => {
            if (!this.currentUser || this.currentUser.uid !== u.uid) return;
            const data = s.data() || {};
            this.currentUser.displayName = data.displayName || u.email.split('@')[0];
            this.currentUser.phone = data.phone || '';
            this.currentUser.ghorPoints = Math.max(0, Math.floor(Number(data.ghorPoints) || 0));
            this.currentUser.subscriptions = data.subscriptions || {};
            this.updateUserUI(); this.checkSubState(true);
          }, e => console.warn('profile listener', e));
          this.listenUserData(u.uid);
        } else {
          (this._uu || []).forEach(u => u()); this._uu = [];
          this.wallets = { BDT: 0, USD: 0 };
          this._watchLater = [];
          this.orders = [];
          this.walletTransactions = [];
          this.updateUserUI();
        }
      }

      listenUserData(uid) {
        (this._uu || []).forEach(u => u()); this._uu = [];
        const L = (...a) => this._uu.push(onSnapshot(...a));
        L(doc(db, 'wallets', uid), snap => {
          this.wallets = snap.exists() ? snap.data() : { BDT: 0, USD: 0 };
          this.renderWalletCards();
        });
        L(collection(db, 'wallets', uid, 'txs'), snap => {
          this.walletTransactions = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.renderTxs();
        });
        L(query(collection(db, 'orders'), where('userId', '==', uid)), snap => {
          this.orders = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.renderOrders();
        });
        L(collection(db, 'users', uid, 'notifications'), snap => {
          this._ownNotifs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
          this.rebuildNotifications();
        });
        L(query(collection(db, 'support_chats', uid, 'messages'), orderBy('createdAt', 'asc')), snap => {
          this.renderChatMessages(snap.docs.map(d => d.data()));
        });
        L(query(collection(db, 'users', uid, 'history'), orderBy('ts', 'desc')), snap => { this._hist = snap.docs.map(d => ({ id: d.id, ...d.data() })); this.histRefresh(); });
        L(collection(db, 'users', uid, 'watch_later'), snap => { this._watchLater = snap.docs.map(d => ({ id:d.id, ...d.data() })); this.renderWatchLater(); });
      }

      _bcReadSet() {
        try { return new Set(JSON.parse(localStorage.getItem('gghor_bc_read_' + (this.currentUser ? this.currentUser.uid : '')) || '[]')); } catch (e) { return new Set(); }
      }
      _bcSetRead(id, isRead) {
        const s = this._bcReadSet();
        if (isRead) s.add(id); else s.delete(id);
        try { localStorage.setItem('gghor_bc_read_' + (this.currentUser ? this.currentUser.uid : ''), JSON.stringify([...s])); } catch (e) {}
      }
      // একটি নোটিফিকেশনের পঠিত/অপঠিত অবস্থা সেভ করে (নিজের → Firestore, ব্রডকাস্ট → এই ডিভাইসে)
      _setNotifRead(n, isRead) {
        n.read = isRead;
        if (n.userId && db) updateDoc(doc(db, 'users', n.userId, 'notifications', n.id), { read: isRead }).catch(() => {});
        else this._bcSetRead(n.id, isRead);
      }

      rebuildNotifications() {
        const bcRead = this._bcReadSet();
        const bcs = this._broadcasts.map(b => ({ ...b, read: bcRead.has(b.id) }));
        const all = [...this._ownNotifs, ...bcs].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
        this.notifications = all;
        this.renderNotifications();
      }

      updateUserUI() {
        const u = this.currentUser;
        document.querySelectorAll('[data-auth]').forEach(el => { el.hidden = el.dataset.auth === 'user' ? !u : !!u; });
        document.getElementById('authHeaderLabel').textContent = u ? u.displayName : 'লগইন';
        document.getElementById('userDisplayName').textContent = u ? u.displayName : 'লগইন করা নেই';
        document.getElementById('userEmailTag').textContent = u ? u.email : '';
        document.getElementById('userPhoneTag').textContent = u ? (u.phone || '') : '';
        document.getElementById('userAvatar').textContent = u ? u.displayName.charAt(0).toUpperCase() : '?';
        document.getElementById('menuUserName').textContent = u ? u.displayName : 'অতিথি ব্যবহারকারী';
        document.getElementById('menuUserEmail').textContent = u ? u.email : 'লগইন করা নেই';
        document.getElementById('authActionBtnsContainer').style.display = u ? 'none' : 'flex';
        document.getElementById('accountLogoutBtn').style.display = u ? 'block' : 'none';
        document.getElementById('editProfileBtn').style.display = u ? 'inline-flex' : 'none';
        this.renderWalletCards();
        const rc = document.getElementById('redeemCard'); if (rc) rc.style.display = u ? 'block' : 'none';
        this.renderGhorCard();
        this.updateBubble();
      }

      /* ===== GHOR PRIME POINTS (২০০,০০০ GP = ১৫ লেভেল) ===== */
      ghorInfo(pts) {
        const T = 200000, N = 15, S = 13333;
        pts = Math.max(0, Math.floor(Number(pts) || 0));
        const level = pts >= T ? N : Math.min(N, Math.floor(pts / S) + 1);
        const start = (level - 1) * S, end = level === N ? T : level * S;
        const into = Math.min(pts, end) - start, size = end - start;
        const tiers = [['Bronze', '#e0954a'], ['Silver', '#cbd5e1'], ['Gold', '#fbbf24'], ['Platinum', '#22d3ee'], ['Diamond', '#a78bfa']];
        const t = tiers[Math.floor((level - 1) / 3)];
        return { pts, level, maxed: pts >= T, start, end, into, size, pct: Math.min(100, (into / size) * 100), remain: Math.max(0, end - pts), tier: t[0], color: t[1], name: `${t[0]} ${['I', 'II', 'III'][(level - 1) % 3]}` };
      }
      ghorBadge(level, size) {
        const logo = this.ghorLevels[level];
        if (logo) return `<img class="gb-img" src="${logo}" alt="Level ${level}" style="width:${size}px;height:${size}px" />`;
        const c = this.ghorInfo((level - 1) * 13333).color;
        const id = 'gbg' + level + '_' + size;
        return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" aria-hidden="true">
          <defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".35" stop-color="${c}"/><stop offset="1" stop-color="${c}" stop-opacity=".45"/></linearGradient></defs>
          <polygon points="50,4 90,27 90,73 50,96 10,73 10,27" fill="url(#${id})" stroke="rgba(255,255,255,.55)" stroke-width="2.5"/>
          <polygon points="50,15 80,32 80,68 50,85 20,68 20,32" fill="rgba(8,12,22,.78)"/>
          <text x="50" y="62" text-anchor="middle" font-size="${level > 9 ? 34 : 40}" font-weight="900" fill="${c}" font-family="system-ui,sans-serif">${level}</text>
        </svg>`;
      }
      renderGhorCard() {
        const box = document.getElementById('ghorCard'), chip = document.getElementById('userLevelChip');
        if (!box) return;
        const u = this.currentUser;
        if (!u) { box.innerHTML = ''; if (chip) chip.innerHTML = ''; return; }
        const g = this.ghorInfo(u.ghorPoints || 0), fmt = n => Number(n).toLocaleString('en-US');
        if (chip) chip.innerHTML = `<span class="user-level-chip" style="--gc:${g.color}">${this.ghorBadge(g.level, 20)} Lv ${g.level} · ${g.name}</span>`;
        const C = 276.46;
        let ladder = '';
        for (let L = 1; L <= 15; L++) {
          const cls = L < g.level || (g.maxed && L === 15) ? 'done' : L === g.level ? 'cur' : 'lock';
          ladder += `<div class="gl-node ${cls}" style="--nc:${this.ghorInfo((L - 1) * 13333).color}"><div class="gl-b">${this.ghorBadge(L, 32)}</div><small>L${L}</small></div>`;
        }
        box.innerHTML = `
          <div class="ghor-card" style="--gc:${g.color}">
            <div class="ghor-glow"></div>
            <div class="ghor-top">
              <div class="ghor-ring">
                <svg viewBox="0 0 100 100"><circle class="gr-bg" cx="50" cy="50" r="44"/><circle class="gr-fg" cx="50" cy="50" r="44" stroke-dasharray="${C}" stroke-dashoffset="${(C * (1 - g.pct / 100)).toFixed(2)}"/></svg>
                <div class="ghor-ring-badge">${this.ghorBadge(g.level, 60)}</div>
              </div>
              <div style="min-width:0;">
                <div class="ghor-kicker">GHOR PRIME POINTS</div>
                <div class="ghor-title">${g.name}</div>
                <div class="ghor-lvl">LEVEL ${g.level} <span>/ 15</span></div>
                <div class="ghor-pts"><b>${fmt(g.pts)}</b> / ${fmt(200000)} GP</div>
              </div>
            </div>
            <div class="ghor-bar"><i style="width:${g.pct.toFixed(2)}%"></i></div>
            <div class="ghor-bar-row">
              <span>${fmt(g.into)} / ${fmt(g.size)} GP</span>
              <span>${g.maxed ? '👑 MAX LEVEL' : `Level ${g.level + 1} এ আর ${fmt(g.remain)} GP`}</span>
            </div>
            <div class="ghor-ladder" id="ghorLadder">${ladder}</div>
            <div class="ghor-rates">
              <div class="gr-rate"><span>1 BDT = 1 GP</span><span>1 USD = 122 GP</span></div>
              অর্ডার এডমিন Approve বা Complete করলে অর্ডারের মূল্য অনুযায়ী Ghor Points যোগ হয়ে লেভেল আপ হবে।
            </div>
          </div>`;
        requestAnimationFrame(() => {
          const l = document.getElementById('ghorLadder'), c = l && l.querySelector('.gl-node.cur');
          if (l && c) l.scrollLeft = c.offsetLeft - l.clientWidth / 2 + c.clientWidth / 2;
        });
        // লেভেল আপ সেলিব্রেশন
        try {
          const k = 'gghor_lvl_' + u.uid, prev = Number(localStorage.getItem(k) || 0);
          if (prev && g.level > prev) this.toast(`🎉 অভিনন্দন! আপনি Level ${g.level} (${g.name}) এ উন্নীত হয়েছেন!`, 'success');
          if (!prev || g.level !== prev) localStorage.setItem(k, String(g.level));
        } catch (e) {}
      }

      renderWalletCards() {
        const html = `
          <div class="wallet-curr-box"><span class="wallet-curr-lbl">BDT (৳)</span><div class="wallet-curr-val">${this.formatMoney(this.wallets.BDT || 0, 'BDT')}</div></div>
          <div class="wallet-curr-box"><span class="wallet-curr-lbl">USD ($)</span><div class="wallet-curr-val">${this.formatMoney(this.wallets.USD || 0, 'USD')}</div></div>
        `;
        const wg = document.getElementById('walletPageBalancesGrid'); if (wg) wg.innerHTML = html;
        this.updateBubble();
      }

      renderTxs() {
        const c = document.getElementById('walletTransactionsList');
        const hid = this.hidden('txs'), txl = this.walletTransactions.filter(t => !hid.has(t.id));
        if (!txl.length) { c.innerHTML = '<div style="color:var(--text-dim); text-align:center; padding:16px;">কোনো ট্রানজেকশন নেই</div>'; return; }
        c.innerHTML = txl.map(t => `
          <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:10px 14px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:700;">${t.title}</div>
              <small style="color:var(--text-muted);">${new Date(t.date).toLocaleDateString()}</small>
            </div>
            <div style="font-weight:800; color:${t.amountPaisa < 0 ? 'var(--accent-rose)' : 'var(--accent-emerald)'};">
              ${this.formatMoney(Math.abs(t.amountPaisa), t.currency)}
            </div>
          </div>
        `).join('');
      }

      renderOrders() {
        const c = document.getElementById('ordersListContainer');
        const countBadge = document.getElementById('navBadgeOrders');
        const hid = this.hidden('orders'), list = this.orders.filter(o => !hid.has(o.id));
        const pend = list.filter(o => o.status === 'pending').length;
        if (pend > 0) { countBadge.style.display = 'inline-block'; countBadge.textContent = pend; }
        else countBadge.style.display = 'none';

        if (!list.length) { c.innerHTML = '<div style="color:var(--text-dim); text-align:center; padding:20px;">কোনো অর্ডার হিস্ট্রি নেই</div>'; return; }

        const steps = [['file-check', 'অর্ডার গৃহীত'], ['loader', 'প্রসেসিং'], ['package-check', 'ডেলিভারি']];
        c.innerHTML = list.map(o => {
          const st = o.status || 'pending';
          const reached = st === 'completed' ? 3 : st === 'processing' ? 2 : st === 'pending' ? 1 : 0;
          return `
            <div class="ord-card st-${st}">
              <div class="ord-head">
                <div class="ord-ico"><i data-lucide="package"></i></div>
                <div class="ord-title">
                  <span class="ord-no">#${o.orderNumber}</span>
                  <h4>${o.productName}</h4>
                  <div class="ord-pkg">${o.packageName} <span class="ord-qty">× ${o.quantity || 1}</span></div>
                </div>
                <span class="ord-status">${st}</span>
              </div>
              ${st === 'cancelled' ? `
                <div class="ord-cancel">
                  <i data-lucide="x-circle" style="color:var(--accent-rose); width:20px; flex-shrink:0;"></i>
                  <div>
                    <b>বাতিলের কারণ:</b> ${o.cancelReason || 'অননুমোদিত তথ্য বা টেকনিক্যাল সমস্যা'}
                    ${o.refunded ? `<div style="font-size:0.75rem; color:var(--accent-emerald); margin-top:2px;">Wallet-এ ফেরত দেওয়া হয়েছে (${this.formatMoney(o.refundedAmountPaisa || o.totalPaisa, o.currency)})</div>` : ''}
                  </div>
                </div>
              ` : `
                <div class="ord-steps">
                  ${steps.map((sp, i) => `
                    <div class="ord-step ${i < reached ? 'done' : ''}">
                      <span class="ord-dot"><i data-lucide="${sp[0]}"></i></span>
                      <small>${sp[1]}</small>
                    </div>
                  `).join('<span class="ord-line"></span>')}
                </div>
              `}
              <div class="ord-info">
                <div><i data-lucide="user"></i><span>${o.requiredInfo || 'N/A'}</span></div>
                <div><i data-lucide="credit-card"></i><span>${o.paymentMethod} · ${o.trxId}</span></div>
              </div>
              ${o.secretDelivery ? `<div style="margin-top:6px;"><small style="color:var(--accent-emerald); font-weight:700;">ডেলিভারি তথ্য:</small><div class="delivery-box">${o.secretDelivery}</div></div>` : ''}
              <div class="ord-foot">
                <small style="color:var(--text-dim);">${new Date(o.createdAt).toLocaleDateString()}</small>
                <strong style="color:var(--accent-cyan); font-size:1.1rem;">${this.formatMoney(o.totalPaisa, o.currency)}</strong>
              </div>
            </div>
          `;
        }).join('');
        lucide.createIcons();
      }

      renderNotifications() {
        const c = document.getElementById('notifContainerList');
        const b = document.getElementById('notifBadge');
        const unreadCount = this.notifications.filter(n => !n.read).length;
        b.style.display = unreadCount ? 'flex' : 'none';
        b.textContent = unreadCount > 99 ? '99+' : unreadCount;
        document.getElementById('notifCountText').textContent = `${this.notifications.length}টি নোটিফিকেশন`;
        c.innerHTML = this.notifications.map(n => `
          <div class="notif-item ${!n.read ? 'unread' : ''}" onclick="app.openNotificationDetail('${n.id}')">
            <div class="notif-ico"><i data-lucide="bell"></i></div>
            <div class="notif-body">
              <div class="notif-title">${this.nt(n, 'title')}</div>
              <div class="notif-time">${new Date(n.createdAt).toLocaleDateString()}</div>
            </div>
            ${!n.read ? '<span class="notif-dot"></span>' : ''}
            <i data-lucide="chevron-right" class="notif-chev"></i>
          </div>
        `).join('') || '<div style="color:var(--text-dim); text-align:center; padding:20px;">কোনো নোটিফিকেশন নেই</div>';
        lucide.createIcons();
      }

      openNotificationDetail(id) {
        const n = this.notifications.find(x => x.id === id);
        if (!n) return;
        this._setNotifRead(n, true);
        this.renderNotifications();
        document.getElementById('ndType').innerHTML = `<i data-lucide="bell"></i> ${this.typeLabel(n.type)}`;
        document.getElementById('ndTitle').textContent = this.nt(n, 'title');
        document.getElementById('ndDate').textContent = new Date(n.createdAt).toLocaleDateString();
        document.getElementById('ndTime').textContent = new Date(n.createdAt).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
        document.getElementById('ndMessage').textContent = this.nt(n, 'message');
        this.closeNotifDrawer();
        this.navigate('notif-detail');
      }

      closeNotificationDetail() {
        this.navigate('home');
        this.openNotifications();
      }

      markAllNotificationsRead() {
        this.notifications.forEach(n => this._setNotifRead(n, true));
        this.renderNotifications();
        this.toast('সব নোটিফিকেশন পঠিত চিহ্নিত করা হয়েছে');
      }

      markAllNotificationsUnread() {
        this.notifications.forEach(n => this._setNotifRead(n, false));
        this.renderNotifications();
        this.toast('সব নোটিফিকেশন অপঠিত চিহ্নিত করা হয়েছে');
      }

      clearAllNotifications() {
        if (!confirm('আপনি কি সকল নোটিফিকেশন মুছে ফেলতে চান?')) return;
        if (this.currentUser && db) {
          this.notifications.filter(n => n.userId === this.currentUser.uid).forEach(n => {
            deleteDoc(doc(db, 'users', this.currentUser.uid, 'notifications', n.id)).catch(() => {});
          });
        }
        this.notifications = [];
        this.renderNotifications();
        this.toast('সকল নোটিফিকেশন মুছে ফেলা হয়েছে');
      }

      renderShelves() {
        const sec = document.getElementById('recentlyViewedSection');
        const list = this.recentlyViewedIds.map(id => this.products.find(p => p.id === id)).filter(Boolean);
        sec.style.display = list.length ? 'block' : 'none';
        document.getElementById('recentlyViewedShelf').innerHTML = list.map(p => `
          <div class="rv-card" onclick="app.openProduct('${p.id}')">
            <img class="rv-card-img" src="${p.image || ''}" />
            <div class="rv-card-text"><strong>${p.name}</strong><small>${p.category || ''}</small></div>
          </div>
        `).join('');
      }

      async sendChatMessage() {
        const inp = document.getElementById('userChatMessageInput');
        const txt = inp.value.trim();
        if (!txt || !this.currentUser) return;
        inp.value = '';
        await setDoc(doc(db, "support_chats", this.currentUser.uid), {
          userId: this.currentUser.uid, userName: this.currentUser.displayName, lastMessage: txt, lastUpdated: serverTimestamp()
        }, { merge: true });
        await setDoc(doc(collection(db, "support_chats", this.currentUser.uid, "messages")), {
          senderId: this.currentUser.uid, text: txt, isAdmin: false, createdAt: serverTimestamp()
        });

        // Auto-reply simulation
        setTimeout(async () => {
          await setDoc(doc(collection(db, "support_chats", this.currentUser.uid, "messages")), {
            senderId: "ADMIN", text: "দয়া করে কিছুক্ষণ অপেক্ষা করুন, এডমিন শীঘ্রই আপনার সাথে যুক্ত হবেন।", isAdmin: true, createdAt: serverTimestamp()
          });
        }, 1500);
      }

      renderChatMessages(msgs) {
        this._chatMsgs = msgs; this.chatUnreadUpdate();
        const box = document.getElementById('userChatMessagesBox');
        if (!msgs.length) { box.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-dim);">এডমিনের সাথে সরাসরি কথা বলতে মেসেজ লিখুন।</div>'; return; }
        box.innerHTML = msgs.map(m => `
          <div class="chat-bubble ${m.isAdmin ? 'from-admin' : 'from-user'}">
            <div>${m.text}</div>
          </div>
        `).join('');
        box.scrollTop = box.scrollHeight;
      }

      openAddMoneyModal() {
        if (!this.currentUser) { this.toast('লগইন করুন', 'danger'); this.openAuthModal(); return; }
        document.getElementById('addMoneyPaymentDesc').innerHTML = `<div class="desc-body">${this.paymentDescription || 'নির্দেশিকা অনুযায়ী পেমেন্ট সম্পন্ন করুন।'}</div>`;
        this.switchDepositCurrencyTab('BDT');
        document.getElementById('addMoneyModal').classList.add('active');
        lucide.createIcons();
      }

      switchDepositCurrencyTab(c) {
        if (!['BDT', 'USD'].includes(c)) c = 'BDT';
        this.activeDepositCurrency = c;
        ['BDT', 'USD'].forEach(x => {
          document.getElementById(`depTab${x}`).classList.toggle('btn-primary', x === c);
          document.getElementById(`depTab${x}`).classList.toggle('btn-secondary', x !== c);
        });
        const lbl = document.getElementById('depositAmountLabel');
        if (lbl) lbl.textContent = c === 'USD' ? 'ডলারের পরিমাণ ($) *' : 'টাকার পরিমাণ (৳) *';
        const gws = this.gateways.filter(g => this.gwCur(g) === c);
        const box = document.getElementById('walletGatewayButtons');
        box.innerHTML = gws.map((g, i) => `
          <button type="button" class="gw-btn ${i === 0 ? 'active' : ''}" data-gwid="${g.id}" onclick="app.selectDepositGw('${g.id}')">
            ${g.photo ? `<img src="${g.photo}" alt="" />` : ''}
            <span>${g.name || ''}</span>
          </button>
        `).join('') || '<div style="color:var(--text-muted);">গেটওয়ে নেই</div>';
        if (gws[0]) this.selectDepositGw(gws[0].id);
        else {
          document.getElementById('addMoneyGwName').textContent = '';
          document.getElementById('addMoneyGwNumberRow').style.display = 'none';
          document.getElementById('addMoneyGwInstruction').textContent = '';
          document.getElementById('addMoneyGwPhoto').style.display = 'none';
        }
      }
      handleDepositGatewaySelect(id) { if (id) this.selectDepositGw(id); }

      selectDepositGw(id) {
        const g = this.gateways.find(x => x.id === id);
        if (!g) return;
        document.querySelectorAll('#walletGatewayButtons .gw-btn').forEach(b => b.classList.toggle('active', b.dataset.gwid === id));
        document.getElementById('addMoneyGwName').textContent = g.name || '';
        document.getElementById('addMoneyGwNumber').textContent = g.number || '';
        document.getElementById('addMoneyGwNumberRow').style.display = g.number ? 'flex' : 'none';
        document.getElementById('addMoneyGwInstruction').textContent = g.instructions || '';
        const photo = document.getElementById('addMoneyGwPhoto');
        if (g.photo) { photo.src = g.photo; photo.style.display = 'block'; }
        else photo.style.display = 'none';
        lucide.createIcons();
      }

      async copyGatewayNumber() {
        const num = document.getElementById('addMoneyGwNumber').textContent.trim();
        if (!num) return;
        try { await navigator.clipboard.writeText(num); }
        catch (e) {
          const t = document.createElement('textarea'); t.value = num; t.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
          document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (_) {} t.remove();
        }
        this.toast('নম্বর কপি করা হয়েছে!', 'success');
      }

      previewProofPhoto(inp) {
        const f = inp.files && inp.files[0];
        const img = document.getElementById('walletProofPreview');
        if (f && f.size > 1048576) {
          this.toast('ছবির সাইজ সর্বোচ্চ ১ MB হতে পারবে (আপনার ছবি ' + (f.size / 1048576).toFixed(2) + ' MB)', 'danger');
          inp.value = ''; img.style.display = 'none'; return;
        }
        if (f && !/^image\//.test(f.type)) {
          this.toast('শুধু ছবি আপলোড করুন', 'danger');
          inp.value = ''; img.style.display = 'none'; return;
        }
        if (f) {
          img.src = URL.createObjectURL(f);
          img.style.display = 'block';
        } else {
          img.style.display = 'none';
        }
      }

      // Shrink proof image so the Firestore document stays well under the 1 MB limit
      compressImage(file) {
        return new Promise((resolve0) => {
          let done = false;
          const resolve = (v) => { if (!done) { done = true; resolve0(v); } };
          setTimeout(() => resolve(''), 10000);
          const fr = new FileReader();
          fr.onerror = () => resolve('');
          fr.onload = () => {
            const img = new Image();
            img.onerror = () => resolve('');
            img.onload = () => {
              let max = 1000, q = 0.7, out = '';
              for (let i = 0; i < 4; i++) {
                const r = Math.min(1, max / Math.max(img.width, img.height));
                const cv = document.createElement('canvas');
                cv.width = Math.max(1, Math.round(img.width * r)); cv.height = Math.max(1, Math.round(img.height * r));
                const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(img, 0, 0, cv.width, cv.height);
                out = cv.toDataURL('image/jpeg', q);
                if (out.length < 600000) break;
                max = Math.round(max * 0.75); q = Math.max(0.4, q - 0.1);
              }
              resolve(out.length < 900000 ? out : '');
            };
            img.src = fr.result;
          };
          fr.readAsDataURL(file);
        });
      }

      async submitAddMoney() {
        if (!this.currentUser) { this.toast('লগইন করুন', 'danger'); this.openAuthModal(); return; }
        const amt = Number(document.getElementById('walletAddAmount').value);
        const trx = document.getElementById('walletAddTrxId').value.trim();
        const activeBtn = document.querySelector('#walletGatewayButtons .gw-btn.active');
        const gw = activeBtn ? this.gateways.find(x => x.id === activeBtn.dataset.gwid) : null;

        if (!(amt > 0) || !isFinite(amt)) { this.toast('সঠিক টাকার পরিমাণ দিন', 'danger'); return; }
        if (!gw) { this.toast('পেমেন্ট গেটওয়ে নির্বাচন করুন', 'danger'); return; }
        if (!trx) { this.toast('TrxID প্রদান করুন', 'danger'); return; }
        const pf0 = document.getElementById('walletAddProofFile');
        if (pf0 && pf0.files && pf0.files[0] && pf0.files[0].size > 1048576) {
          this.toast('প্রুফ ছবি সর্বোচ্চ ১ MB হতে পারবে', 'danger'); return;
        }
        if (!this._lock('dep')) return;
        const btn = document.getElementById('depositSubmitBtn');
        if (btn) { btn.disabled = true; btn.style.opacity = '.6'; }
        try {
          let proofBase64 = '';
          const pf = document.getElementById('walletAddProofFile');
          if (pf && pf.files && pf.files[0]) proofBase64 = await this.compressImage(pf.files[0]);

          if (pf && pf.files && pf.files[0] && !proofBase64) this.toast('ছবি প্রসেস করা যায়নি, ছবি ছাড়াই জমা হচ্ছে', 'info');

          const depId = 'DEP-' + Math.floor(10000000 + Math.random() * 90000000);
          const wp = setDoc(doc(db, 'deposits', depId), {
            id: depId, userId: this.currentUser.uid, userEmail: this.currentUser.email || '', userName: this.currentUser.displayName || '',
            originalAmount: amt, currency: this.activeDepositCurrency, method: gw.name || '', trxId: trx, proofImage: proofBase64, status: 'pending', createdAt: new Date().toISOString()
          });
          let queued = false;
          await Promise.race([wp, new Promise(res => setTimeout(() => { queued = true; res(); }, 20000))]);
          if (queued) {
            // network is slow: request is saved on device & will sync automatically. Report a late failure if any.
            wp.catch(err => { console.error('late deposit failure', err); this.toast(this._errMsg(err), 'danger'); });
            this.toast('নেটওয়ার্ক ধীর — রিকোয়েস্ট সেভ হয়েছে, নেট পেলে অটো এডমিনের কাছে যাবে (#' + depId + ')', 'info');
          } else {
            this.toast('ডিপোজিট রিকোয়েস্ট জমা হয়েছে!', 'success');
          }
          document.getElementById('walletAddAmount').value = '';
          document.getElementById('walletAddTrxId').value = '';
          if (pf) pf.value = '';
          document.getElementById('walletProofPreview').style.display = 'none';
          this.closeModal('addMoneyModal');
          const L = '━━━━━━━━━━━━━━━━━━', am = `${amt} ${this.activeDepositCurrency}`;
          this.addUserNotification('⏳ ডিপোজিট রিকোয়েস্ট জমা হয়েছে', `প্রিয় গ্রাহক,\n\nআপনার ডিপোজিট রিকোয়েস্ট সফলভাবে জমা হয়েছে। যাচাই শেষে ব্যালেন্স আপনার ওয়ালেটে যুক্ত হবে।\n\n${L}\n🧾 রিকোয়েস্ট নম্বর: #${depId}\n💰 পরিমাণ: ${am}\n🏦 মাধ্যম: ${gw.name}\n🔑 TrxID: ${trx}\n📌 স্ট্যাটাস: পেন্ডিং\n${L}`, 'wallet',
            { title: '⏳ Deposit Request Submitted', message: `Dear customer,\n\nYour deposit request has been submitted. The balance will be added to your wallet after verification.\n\n${L}\n🧾 Request No: #${depId}\n💰 Amount: ${am}\n🏦 Method: ${gw.name}\n🔑 TrxID: ${trx}\n📌 Status: Pending\n${L}` });
        } catch (e) {
          console.error('submitAddMoney', e);
          this.toast(this._errMsg(e), 'danger');
        } finally {
          this._unlock('dep');
          if (btn) { btn.disabled = false; btn.style.opacity = ''; }
        }
      }

      async redeemCashCoupon() {
        const code = document.getElementById('cashCouponInput').value.trim().toUpperCase();
        if (!code) { this.toast('কুপন কোড দিন', 'danger'); return; }
        if (!this._lock('cash')) return;
        try {
          if (!(await this.guardCoupon(code))) return;
          const c = await this.fetchCoupon(code);
          const bad = this._couponProblem(c, 'cash');
          if (bad) { this.toast(bad, 'danger'); return; }

          const amount = this._couponAmount(c);
          const amtMinor = this.toMinor(amount);
          const uid = this.currentUser.uid, cid = c._id || code;
          const build = (b, withCounter) => {
            b.set(doc(db, 'wallets', uid), { BDT: increment(amtMinor), _cpn: code }, { merge: true });
            b.set(doc(db, 'wallets', uid, 'txs', 'CPN-' + Date.now()), {
              title: `ক্যাশ কুপন রিডিম [${code}]`, amountPaisa: amtMinor, currency: 'BDT', date: new Date().toISOString()
            });
            b.set(doc(db, 'users', uid, 'usedCoupons', code), { code, type: 'cash', usedAt: new Date().toISOString() });
            if (withCounter) b.update(doc(db, 'coupons', cid), { usedCount: increment(1) });
          };
          await this.commitSmart(build, cid);

          document.getElementById('cashCouponInput').value = '';
          this.addUserNotification('🎁 কুপন সফলভাবে রিডিম হয়েছে', `অভিনন্দন!\n\nকুপন [${code}] রিডিম সফল হয়েছে এবং ৳ ${amount} আপনার ওয়ালেটে যুক্ত করা হয়েছে।\n\nনিজের ব্যালেন্স দেখতে “ডিজিটাল ওয়ালেট” পেজে যান। 💙`, 'coupon',
            { title: '🎁 Coupon Redeemed Successfully', message: `Congratulations!\n\nCoupon [${code}] was redeemed and ৳ ${amount} has been added to your wallet.\n\nVisit the “Digital Wallet” page to see your balance. 💙` });
          this.toast(`৳ ${amount} ওয়ালেটে যুক্ত হয়েছে!`, 'success');
        } catch (e) {
          console.error('redeemCashCoupon', e);
          this.toast(this._errMsg(e), 'danger');
        } finally { this._unlock('cash'); }
      }

      openTutorialModal(type) {
        const url = type === 'deposit' ? this.tutorials.depositUrl : this.tutorials.orderUrl;
        if (!url) { this.toast('টিউটোরিয়াল ভিডিও এখনো যোগ করা হয়নি'); return; }
        let embed = url;
        if (url.includes('watch?v=')) embed = url.replace('watch?v=', 'embed/');
        else if (url.includes('youtu.be/')) embed = url.replace('youtu.be/', 'www.youtube.com/embed/');
        document.getElementById('tutorialVideoFrame').src = embed;
        document.getElementById('tutorialModalTitle').textContent = type === 'deposit' ? 'ডিপোজিট টিউটোরিয়াল' : 'অর্ডার টিউটোরিয়াল';
        document.getElementById('tutorialModal').classList.add('active');
      }
      closeTutorialModal() {
        document.getElementById('tutorialVideoFrame').src = '';
        document.getElementById('tutorialModal').classList.remove('active');
      }

      hidden(kind) { try { return new Set(JSON.parse(localStorage.getItem(`gghor_hide_${kind}_${this.currentUser ? this.currentUser.uid : ''}`) || '[]')); } catch (e) { return new Set(); } }
      hideAll(kind, ids) { const h = this.hidden(kind); ids.forEach(i => h.add(i)); try { localStorage.setItem(`gghor_hide_${kind}_${this.currentUser.uid}`, JSON.stringify([...h])); } catch (e) {} }

      clearOrderHistory() {
        if (!confirm('অর্ডার হিস্ট্রি মুছে ফেলতে চান?')) return;
        this.hideAll('orders', this.orders.map(o => o.id));
        this.renderOrders();
        this.toast('অর্ডার হিস্ট্রি মুছে ফেলা হয়েছে');
      }

      clearWalletHistory() {
        if (!confirm('ওয়ালেট হিস্ট্রি মুছে ফেলতে চান?')) return;
        this.hideAll('txs', this.walletTransactions.map(t => t.id));
        this.renderTxs();
        this.toast('ওয়ালেট হিস্ট্রি মুছে ফেলা হয়েছে');
      }

      addUserNotification(title, message, type, en) {
        if (!this.currentUser) return;
        const id = 'NTF-' + Date.now() + Math.floor(Math.random() * 100);
        setDoc(doc(db, 'users', this.currentUser.uid, 'notifications', id), {
          id, title, message, titleEn: (en && en.title) || '', messageEn: (en && en.message) || '', type, read: false, createdAt: new Date().toISOString(), userId: this.currentUser.uid
        }).catch(e => console.warn('notification write failed', e));
      }
      nt(n, k) { return (this.lang === 'en' && n[k + 'En']) ? n[k + 'En'] : n[k]; }
      typeLabel(t) {
        const m = { order: ['অর্ডার আপডেট', 'Order Update'], wallet: ['ওয়ালেট', 'Wallet'], coupon: ['কুপন রিওয়ার্ড', 'Coupon Reward'] };
        return m[t] ? m[t][this.lang === 'en' ? 1 : 0] : (t || (this.lang === 'en' ? 'Notice' : 'বিজ্ঞপ্তি'));
      }

      checkUpdateLock(cfg) {
        if (!cfg || !cfg.latestVersion) return;
        const outdated = cfg.latestVersion !== this.appVersion;
        const modal = document.getElementById('appUpdateBlockerModal');
        if (outdated) {
          document.getElementById('updateModalCurrent').textContent = this.appVersion;
          document.getElementById('updateModalVersion').textContent = cfg.latestVersion;
          document.getElementById('updateModalLink').href = cfg.downloadUrl || '#';
          document.getElementById('updateModalDesc').textContent = cfg.notes || 'নতুন ভার্সনে আপডেট করুন।';
          if (cfg.forceUpdate) {
            modal.classList.add('active', 'force-lock');
            document.getElementById('updateModalLater').style.display = 'none';
          } else {
            modal.classList.add('active');
            document.getElementById('updateModalLater').style.display = 'block';
          }
        }
      }
      openUpdateLink(e) {
        e.preventDefault();
        const href = document.getElementById('updateModalLink').href;
        if (href && href !== '#') window.open(href, '_blank');
      }
      dismissUpdate() { document.getElementById('appUpdateBlockerModal').classList.remove('active'); }

      /* ===== MAGAZINE (বই / ম্যাগাজিন / পর্ব) ===== */
      _esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
      _kindLabel(k) { return k === 'magazine' ? 'ম্যাগাজিন' : k === 'text' ? 'লেখা' : 'বই'; }
      loadBookFavs(uid) {
        try { this.bookFavs = new Set(JSON.parse(localStorage.getItem('gghor_bfav_' + (uid || 'guest')) || '[]')); }
        catch (e) { this.bookFavs = new Set(); }
        this.renderMagazine();
        this.updateBookFavBtn();
      }
      isBookFav(id) { return this.bookFavs.has(id); }
      toggleBookFav(id, ev) {
        if (ev) { ev.stopPropagation(); ev.preventDefault(); }
        if (!id) return;
        if (this.bookFavs.has(id)) { this.bookFavs.delete(id); this.toast('প্রিয় তালিকা থেকে সরানো হয়েছে'); }
        else { this.bookFavs.add(id); this.toast('প্রিয় তালিকায় যোগ হয়েছে ❤', 'success'); }
        try { localStorage.setItem('gghor_bfav_' + (this.currentUser ? this.currentUser.uid : 'guest'), JSON.stringify([...this.bookFavs])); } catch (e) {}
        this.updateBookFavBtn();
        this.renderMagazine();
      }
      updateBookFavBtn() {
        const b = document.getElementById('bookFavBtn');
        if (b) b.classList.toggle('on', !!this.curBookId && this.bookFavs.has(this.curBookId));
      }
      _bookEps(bid) {
        return this.bookEps.filter(e => e.bookId === bid).sort((a, b) => ((a.number || 0) - (b.number || 0)) || String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
      }
      _subscriptionExpiry(v){
        if(!v||typeof v!=='object'||v.expiresAt==null)return 0;
        const raw=v.expiresAt;
        let exp=raw&&typeof raw.toMillis==='function'?raw.toMillis():typeof raw==='string'?Date.parse(raw):Number(raw);
        if(!Number.isFinite(exp))return 0;
        if(exp>0&&exp<1e12)exp*=1000;
        return exp> Date.now() ? exp : 0;
      }
      _activeSubscription(){
        if(!this.currentUser)return null;
        const s=this.currentUser.subscriptions;
        if(!s||typeof s!=='object')return null;
        return Object.values(s).find(v=>this._subscriptionExpiry(v)>0)||null;
      }
      _activeMagazineSubscription(){
        if(!this.currentUser)return null;
        const s=this.currentUser.subscriptions||{};
        return this._subscriptionExpiry(s.weekly)>0||this._subscriptionExpiry(s.monthly)>0||this._subscriptionExpiry(s.yearly)>0
          ? (s.weekly&&this._subscriptionExpiry(s.weekly)>0?s.weekly:s.monthly&&this._subscriptionExpiry(s.monthly)>0?s.monthly:s.yearly) : null;
      }
      _bookLocked(b){return !!(b&&b.locked&&!this._activeMagazineSubscription());}
      _episodeLocked(ep){if(!ep)return false;if(this._activeMagazineSubscription())return false;if(ep.locked)return true;const b=this.books.find(x=>x.id===ep.bookId);return !!(b&&b.locked);}
      renderMagazineSubscriptions(){const c=document.getElementById('magSubscriptionBox');if(!c)return;if(this.currentUser&&this._activeMagazineSubscription()){const x=this._activeMagazineSubscription();c.innerHTML=`<div style="padding:12px 14px;border:1px solid var(--accent-emerald);border-radius:var(--radius-md);background:rgba(16,185,129,.1)"><b>Subscription চালু আছে</b><div style="font-size:.8rem;color:var(--text-muted)">মেয়াদ: ${new Date(x.expiresAt).toLocaleString('bn-BD')}</div></div>`;return;}const plans=Object.values(this.subscriptionPlans||{}).filter(p=>p&&p.enabled!==false);c.innerHTML=`<div style="padding:14px;border:1px solid var(--border-color);border-radius:var(--radius-lg);background:var(--bg-card)"><div style="font-weight:800;margin-bottom:8px">Magazine Subscription</div><div style="display:grid;gap:8px">${plans.map(p=>`<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;padding:10px;background:var(--bg-surface);border-radius:var(--radius-md)"><div><b>${this._esc(p.label||p.id)}</b><div style="font-size:.76rem;color:var(--text-muted)">${this._esc(p.description||'')}</div></div><button class="btn btn-primary btn-sm" onclick="app.buySubscription('${this._esc(p.id)}')">৳ ${Number(p.price||0).toFixed(2)} কিনুন</button></div>`).join('')||'<div style="color:var(--text-muted);font-size:.8rem">কোনো plan নেই</div>'}</div></div>`;lucide.createIcons();}
      async buySubscription(id){if(!this.currentUser){this.toast('Subscription কিনতে লগইন করুন','danger');this.openAuthModal();return;}const p=this.subscriptionPlans[id],price=this.toMinor(p&&p.price);if(!p||!(price>0)){this.toast('Plan পাওয়া যায়নি','danger');return;}if(Number(this.wallets.BDT||0)<price){this.toast('ওয়ালেটে পর্যাপ্ত BDT ব্যালেন্স নেই','danger');return;}const old=(this.currentUser.subscriptions||{})[id]||{},base=Math.max(Date.now(),Number(old.expiresAt)||0),days={weekly:7,monthly:30,yearly:365}[id]||30,expiresAt=base+days*86400000,b=writeBatch(db);b.set(doc(db,'wallets',this.currentUser.uid),{BDT:increment(-price)},{merge:true});b.set(doc(db,'wallets',this.currentUser.uid,'txs','SUB-'+Date.now()),{title:'Magazine '+(p.label||id),amountPaisa:-price,currency:'BDT',date:new Date().toISOString()});b.set(doc(db,'users',this.currentUser.uid),{subscriptions:{[id]:{plan:id,source:'purchase',startedAt:Number(old.startedAt)||Date.now(),expiresAt}}},{merge:true});await b.commit();setDoc(doc(db,'subscription_sales','SUBS-'+Date.now()+'-'+this.currentUser.uid.slice(0,6)),{userId:this.currentUser.uid,userEmail:this.currentUser.email||'',userName:this.currentUser.displayName||'',plan:id,planLabel:(p.label||id),amountPaisa:price,currency:'BDT',createdAt:new Date().toISOString()}).catch(e=>console.warn('subscription sale log',e));this.toast('Subscription চালু হয়েছে','success');}
      renderMagazineCategories(){const c=document.getElementById('magazineCategoryScroll');if(!c)return;const cats=['All',...(this.magazineCategories||[]).map(x=>x.name)];c.innerHTML=cats.map(x=>`<div class="cat-chip ${this.magCategory===x?'active':''}" onclick="app.filterMagazineCategory('${this._esc(x)}')">${x==='All'?'সব ক্যাটেগরি':this._esc(x)}</div>`).join('');}
      filterMagazineCategory(name){this.magCategory=name;this.renderMagazineCategories();this.renderMagazine();}
      renderMagazine() {
        this.renderMagazineCategories();
        this.renderMagRails();
                const c = document.getElementById('magazineGrid');
        if (!c) return;
        const q = ((document.getElementById('magazineSearch') || {}).value || '').trim().toLowerCase();
        const list = this.books
          .filter(b => this.magCategory === 'All' || b.magazineCategory === this.magCategory)
          .filter(b => !q || String(b.title || '').toLowerCase().includes(q) || String(b.author || '').toLowerCase().includes(q))
          .sort((a, b) => this._newFirst(a, b) || (this.isBookFav(b.id) - this.isBookFav(a.id)) || (this._tsMs(b.createdAt) - this._tsMs(a.createdAt)));
        const cnt = document.getElementById('magCount'); if (cnt) cnt.textContent = `${list.length}টি`;
        if (!list.length) {
          c.classList.remove('grouped');
          c.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:30px; color:var(--text-dim);">কোনো বই বা ম্যাগাজিন পাওয়া যায়নি</div>';
          return;
        }
        const card = b => {
          const fav = this.isBookFav(b.id), n = this._bookEps(b.id).length, lk = this._bookLocked(b), rd = this._fmtCount(this._reads(b.id));
          return `
          <div class="home-product-card book-card" onclick="app.openBook('${b.id}')">
            <div class="home-product-thumb">
              ${b.cover ? `<img src="${b.cover}" alt="" loading="eager" decoding="async" />` : '<div class="bk-ph"><i data-lucide="book-open"></i></div>'}
              ${b.magazineCategory ? `<span class="hp-tag">${this._esc(b.magazineCategory)}</span>` : ''}
              <button type="button" class="fav-btn ${fav ? 'on' : ''}" onclick="app.toggleBookFav('${b.id}', event)" aria-label="Favorite"><i data-lucide="heart"></i></button>
              <span class="bk-count">${this._eyeSvg()}${rd}</span>
              ${lk ? '<div class="bk-lock"><i data-lucide="lock"></i>LOCKED</div>' : ''}
              ${this._newBadge(b)}
            </div>
            <div class="home-product-info">
              <h4 class="home-product-name">${this._esc(b.title)}</h4>
              <div class="hp-foot"><span>${n}টি পর্ব</span>${lk ? '<span class="hp-from none">🔒 লক</span>' : ''}</div>
            </div>
          </div>`;
        };
        const favs = list.filter(b => this.isBookFav(b.id));
        if (q || !favs.length) {
          c.classList.remove('grouped');
          c.innerHTML = list.map(card).join('');
        } else {
          const sec = (title, items, fav) => `
            <div class="cat-section ${fav ? 'fav-section' : ''}">
              <div class="cat-section-head"><span class="cat-section-bar"></span><span class="cat-section-title">${title}</span><span class="cat-section-count">${items.length}টি</span></div>
              <div class="cat-grid">${items.map(card).join('')}</div>
            </div>`;
          c.classList.add('grouped');
          c.innerHTML = sec('❤ প্রিয়', favs, true) + sec('সকল বই ও ম্যাগাজিন', list, false);
        }
        lucide.createIcons();
      }
      openBook(id, silent) {
        const b = this.books.find(x => x.id === id);
        if (!b) return;
        if (!this.currentUser) { this.toast('Magazine পড়তে লগইন Required', 'danger'); this.openAuthModal(); return; } if (this._bookLocked(b)) { this.toast(`এই ${this._kindLabel(b.kind)}টি এখন লক করা আছে 🔒`, 'danger'); return; }
        this.curBookId = id;
        document.getElementById('bookHeroImg').src = b.cover || '';
        document.getElementById('bookHeroBg').style.backgroundImage = b.cover ? `url('${b.cover}')` : 'none';
        document.getElementById('bookTitle').textContent = b.title || '';
        document.getElementById('bookAuthor').textContent = b.author ? `✍ ${b.author}` : '';
        document.getElementById('bookDesc').textContent = b.description || '';
        const allEps=this._bookEps(id), n=allEps.length, seasonCount=new Set(allEps.map(e=>e.season||1)).size;
        document.getElementById('bookChips').innerHTML = `${b.magazineCategory?`<span class="ph-chip">${this._esc(b.magazineCategory)}</span>`:''}<span class="ph-chip green">${n}টি পর্ব</span><span class="ph-chip">👁 ${this._fmtCount(this._reads(id))}</span>`;
        document.getElementById('bookSeasonCount').textContent=seasonCount; document.getElementById('bookEpisodeTotal').textContent=n; document.getElementById('bookCategoryLabel').textContent=b.magazineCategory||'General';
        this.updateBookFavBtn();
        this.renderEpisodes();
        if (!silent) this.navigate('book');
      }
      renderSeasons(){const box=document.getElementById('episodeList');if(!box||!this.curBookId)return;const groups={};this._bookEps(this.curBookId).forEach(e=>(groups[e.season||1]??=[]).push(e));const ss=Object.keys(groups).sort((a,b)=>a-b);document.getElementById('bookEpCount').textContent=`${ss.length}টি সিজন`;box.innerHTML=ss.map(s=>`<div class="ep-row" onclick="app.openSeason(${s})"><div class="ep-num">${s}</div><div class="ep-info"><b>Season ${s}</b><small>${groups[s].length}টি পর্ব</small></div><i data-lucide="chevron-right"></i></div>`).join('');lucide.createIcons();}
      renderSeasonEpisodes(s){const box=document.getElementById('seasonEpisodeList');if(!box||!this.curBookId)return;const eps=this._bookEps(this.curBookId).filter(e=>(e.season||1)==s);box.innerHTML=eps.map(e=>{const locked=this._episodeLocked(e);return `<div class="ep-row ${locked?'locked':''}" onclick="app.openEpisode('${e.id}')"><div class="ep-num">${e.number||'•'}</div><div class="ep-info"><b>${this._esc(e.title)}</b><small>পর্ব ${e.number||'-'}</small></div><i data-lucide="${locked?'lock':'chevron-right'}"></i></div>`;}).join('');lucide.createIcons();}
      openSeason(s){if(!this.currentUser){this.toast('Magazine পড়তে লগইন Required','danger');this.openAuthModal();return;}const b=this.books.find(x=>x.id===this.curBookId),eps=this._bookEps(this.curBookId).filter(e=>(e.season||1)==s);if(!b)return;this.curSeason=s;document.getElementById('seasonHeroImg').src=b.cover||'';document.getElementById('seasonBookTitle').textContent=b.title||'';document.getElementById('seasonTitle').textContent=`Season ${s}`;document.getElementById('seasonEpCount').textContent=`${eps.length}টি পর্ব`;this.renderSeasonEpisodes(s);this.navigate('season');}
      renderEpisodes(){this.renderSeasons();}
      async openEpisode(epId) {
        const ep = this.bookEps.find(e => e.id === epId);
        const b = this.books.find(x => x.id === (ep && ep.bookId));
        if (!ep || !b) return;
        if (!this.currentUser) { this.toast('Magazine পড়তে লগইন Required', 'danger'); this.openAuthModal(); return; } if (this._episodeLocked(ep)) { this.toast('এই পর্বটি লক করা আছে 🔒', 'danger'); return; }
        this.curBookId = b.id; this.curEpId = epId; this.curSeason = ep.season || 1;
        document.getElementById('readerBookTitle').textContent = b.title || '';
        document.getElementById('readerTitle').textContent = ep.title || '';
        document.getElementById('readerEpNo').textContent = `পর্ব ${ep.number || '-'}`;
        const body = document.getElementById('readerBody');
        body.style.fontSize = (parseFloat(localStorage.getItem('gghor_rfs') || '1.02')) + 'rem';
        body.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-dim);">লোড হচ্ছে...</div>';
        this.navigate('reader');
        this.updateReaderNav();
        this.recordRead(b.id, epId);
        try {
          const key = epId + '|' + (ep.updatedAt || '');
          let t = this._epText[key];
          if (t === undefined) {
            this._epText[key] = t;
          }
          if (this.curEpId !== epId) return;
          body.innerHTML = t ? this._esc(t).split(/\n{2,}/).map(x => `<p>${x.replace(/\n/g, '<br>')}</p>`).join('') : '<div style="text-align:center; color:var(--text-dim);">এই পর্বে এখনো কোনো লেখা নেই</div>';
        } catch (e) {
          console.warn('episode text', e);
          if (this.curEpId === epId) body.innerHTML = '<div style="text-align:center; padding:30px; color:var(--accent-rose);">🔒 এই পর্বটি পড়া যাচ্ছে না (লক করা থাকতে পারে)</div>';
        }
      }
      _seasonEps(bid, s) { return this._bookEps(bid).filter(e => (e.season || 1) == s); }
      updateReaderNav() {
        const cur = this.bookEps.find(e => e.id === this.curEpId), sn = cur ? (cur.season || 1) : (this.curSeason || 1);
        const eps = this._seasonEps(this.curBookId, sn), i = eps.findIndex(e => e.id === this.curEpId);
        const prev = i > 0 ? eps[i - 1] : null, next = i >= 0 ? eps[i + 1] : null;
        const pb = document.getElementById('readerPrevBtn'), nb = document.getElementById('readerNextBtn');
        pb.disabled = !prev; nb.disabled = !next;
        pb.innerHTML = `<i data-lucide="${prev && this._episodeLocked(prev) ? 'lock' : 'chevron-left'}"></i> Previous`;
        nb.innerHTML = `Next <i data-lucide="${next && this._episodeLocked(next) ? 'lock' : 'chevron-right'}"></i>`;
        lucide.createIcons();
      }
      readerGo(d) {
        const cur = this.bookEps.find(e => e.id === this.curEpId), sn = cur ? (cur.season || 1) : (this.curSeason || 1);
        const eps = this._seasonEps(this.curBookId, sn), i = eps.findIndex(e => e.id === this.curEpId), t = i < 0 ? null : eps[i + d];
        if (!t) return;
        if (this._episodeLocked(t)) { this.toast(d > 0 ? 'পরের পর্বটি পড়তে subscription প্রয়োজন 🔒' : 'আগের পর্বটি পড়তে subscription প্রয়োজন 🔒', 'danger'); return; }
        this.openEpisode(t.id);
      }
      backToEpisodes() {
        if (this.curSeason == null) { this.navigate('book'); return; }
        this.openSeason(this.curSeason);
      }
      readerFont(d) {
        let v = parseFloat(localStorage.getItem('gghor_rfs') || '1.02');
        v = Math.min(1.6, Math.max(0.85, +(v + d * 0.1).toFixed(2)));
        try { localStorage.setItem('gghor_rfs', String(v)); } catch (e) {}
        document.getElementById('readerBody').style.fontSize = v + 'rem';
      }

      /* ===== Magazine Request ===== */
      openMagRequest(section) {
        if (!this.currentUser) { this.toast('রিকোয়েস্ট পাঠাতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        this._reqSection = 'magazine';
        document.getElementById('magReqTitle').textContent = 'Request Magazine';
        document.getElementById('magReqName').value = ''; document.getElementById('magReqDetails').value = '';
        document.getElementById('magRequestModal').classList.add('active');
      }
      async submitMagRequest() {
        const title = document.getElementById('magReqName').value.trim(), details = document.getElementById('magReqDetails').value.trim();
        if (!title) { this.toast('নামটি লিখুন', 'danger'); return; }
        if (!this.currentUser || this._reqBusy) return;
        this._reqBusy = true;
        try {
          const u = this.currentUser;
          await setDoc(doc(db, 'magazine_requests', 'MRQ-' + Date.now() + '-' + u.uid.slice(0, 6)), { section: this._reqSection, title, details, userId: u.uid, userName: u.displayName || '', userEmail: u.email || '', status: 'pending', createdAt: new Date().toISOString() });
          this.closeModal('magRequestModal');
          this.toast('রিকোয়েস্ট পাঠানো হয়েছে!', 'success');
        } catch (e) { console.warn('magazine request', e); this.toast('রিকোয়েস্ট পাঠানো যায়নি', 'danger'); }
        this._reqBusy = false;
      }

      /* ===== Read count / subscription state ===== */
      _reads(id) { return Number(this.bookReads[id]) || 0; }
      _fmtCount(n) {
        n = Number(n) || 0;
        if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
        if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, '') + 'K';
        return String(n);
      }
      _eyeSvg() { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'; }
      recordRead(bookId, epId) {
        if (!this.currentUser || !bookId || !epId || this._readSeen.has(epId)) return;
        this._readSeen.add(epId);
        setDoc(doc(db, 'book_reads', bookId), { bookId, count: increment(1) }, { merge: true }).catch(e => console.warn('read count', e));
        setDoc(doc(db, 'reader_stats', this.currentUser.uid), { userId: this.currentUser.uid, userName: this.currentUser.displayName || '', userEmail: this.currentUser.email || '', count: increment(1) }, { merge: true }).catch(e => console.warn('reader stats', e));
      }
      checkSubState(force) {
        const st = this._activeMagazineSubscription() ? 'm' : '-';
        if (!force && st === this._subState) return;
        this._subState = st;
        this.onSubChange();
      }
      onSubChange() {
        this.renderMagazine();
        this.renderMagazineSubscriptions();
        const v = this.currentView;
        if (['book', 'season', 'reader'].includes(v)) {
          const b = this.books.find(x => x.id === this.curBookId);
          if (!b || this._bookLocked(b)) { this.toast('Subscription শেষ — বইটি আবার লক হয়েছে 🔒', 'danger'); this.navigate('magazine'); return; }
        }
        if (v === 'book') this.renderEpisodes();
        else if (v === 'season' && this.curSeason != null) this.renderSeasonEpisodes(this.curSeason);
        else if (v === 'reader') {
          const ep = this.bookEps.find(x => x.id === this.curEpId);
          if (!ep || this._episodeLocked(ep)) { this.toast('Subscription শেষ — এই পর্বটি আবার লক হয়েছে 🔒', 'danger'); this.navigate('season'); if (this.curSeason != null) this.renderSeasonEpisodes(this.curSeason); }
          else this.updateReaderNav();
        }
      }

      /* ===== Most-read rails (Magazine), CSS-transform marquee ===== */
      _railCard(b, adult) {
        const lk = this._bookLocked(b), n = this._reads(b.id);
        const open = 'openBook';
        const img = b.cover ? `<img src="${b.cover}" alt="" loading="eager" decoding="async" draggable="false" />` : '<div class="bk-ph" style="font-weight:900;font-size:1.6rem">' + this._esc(String(b.title || '?').charAt(0)) + '</div>';
        return `<div class="rail-card" onclick="app.${open}('${b.id}')"><div class="rail-thumb">${img}<span class="bk-count">${this._eyeSvg()}${this._fmtCount(n)}</span>${lk ? '<div class="bk-lock">🔒</div>' : ''}${this._newBadge(b)}</div><div class="rail-title">${this._esc(b.title)}</div></div>`;
      }
      _fillRail(railId, trackId, list, adult) {
        const rail = document.getElementById(railId), tr = document.getElementById(trackId);
        if (!rail || !tr) return;
        if (!list.length) { rail.style.display = 'none'; tr._sig = ''; return; }
        rail.style.display = 'block';
        const vw = tr.parentElement.clientWidth;
        if (!vw) return;
        const sig = list.map(b => b.id + ':' + this._reads(b.id) + ':' + (this._bookLocked(b) ? 1 : 0) + ':' + String(b.title || '') + ':' + (b.cover ? b.cover.length : 0)).join('|') + '@' + vw;
        if (tr._sig === sig) return;
        tr._sig = sig;
        const cw = (window.innerWidth >= 700 ? 132 : 112) + 10;
        const reps = Math.max(1, Math.ceil(vw / (list.length * cw)));
        const half = list.map(b => this._railCard(b, adult)).join('').repeat(reps);
        tr.innerHTML = half + half;
        tr.style.setProperty('--dur', Math.max(12, Math.round((list.length * reps * cw) / 40)) + 's');
      }
      renderMagRails() {
        const q = ((document.getElementById('magazineSearch') || {}).value || '').trim();
        const rail = document.getElementById('magTopRail'); if (!rail) return;
        if (q || this.magCategory !== 'All') { rail.style.display = 'none'; const t = document.getElementById('magTopTrack'); if (t) t._sig = ''; return; }
        const top = this.books.filter(b => this._reads(b.id) > 0).sort((a, b) => this._reads(b.id) - this._reads(a.id)).slice(0, 5);
        this._fillRail('magTopRail', 'magTopTrack', top, false);
      }
      /* ===== Floating bubbles: Request (Wallet bubble-এর মতো draggable) ===== */
      initFloatBubbles() {
        this._fbDefs = {
          fbReqMag:   { off: 232, act: () => this.openMagRequest('magazine'), views: ['magazine'] }
        };
        this._fbPos = {};
        Object.keys(this._fbDefs).forEach(id => {
          const w = document.getElementById(id); if (!w) return;
          const fab = w.querySelector('.wb-fab'), key = 'gghor_fb_' + id;
          try { const p = JSON.parse(localStorage.getItem(key) || 'null'); if (p && (p.side === 'l' || p.side === 'r') && isFinite(p.y)) this._fbPos[id] = p; } catch (e) {}
          this.fbApplyPos(id);
          let down = false, drag = false, sx = 0, sy = 0, ox = 0, oy = 0;
          fab.addEventListener('pointerdown', e => {
            down = true; drag = false; sx = e.clientX; sy = e.clientY;
            const r = w.getBoundingClientRect(); ox = r.left; oy = r.top;
            try { fab.setPointerCapture(e.pointerId); } catch (_) {}
          });
          fab.addEventListener('pointermove', e => {
            if (!down) return;
            const dx = e.clientX - sx, dy = e.clientY - sy;
            if (!drag && Math.hypot(dx, dy) < 6) return;
            drag = true;
            const x = Math.min(Math.max(ox + dx, 4), window.innerWidth - w.offsetWidth - 4);
            w.style.left = x + 'px'; w.style.right = 'auto'; w.style.top = this.wbClampY(oy + dy) + 'px'; w.style.bottom = 'auto';
          });
          fab.addEventListener('pointerup', () => {
            if (!down) return; down = false;
            if (drag) {
              const r = w.getBoundingClientRect();
              this._fbPos[id] = { side: (r.left + r.width / 2) < window.innerWidth / 2 ? 'l' : 'r', y: this.wbClampY(r.top) };
              try { localStorage.setItem(key, JSON.stringify(this._fbPos[id])); } catch (e) {}
              this.fbApplyPos(id);
            } else this._fbDefs[id].act();
          });
          fab.addEventListener('pointercancel', () => { down = false; this.fbApplyPos(id); });
        });
        window.addEventListener('resize', () => Object.keys(this._fbDefs).forEach(id => this.fbApplyPos(id)));
        this.updateFloatBubbles();
      }
      fbApplyPos(id) {
        const w = document.getElementById(id), p = this._fbPos[id]; if (!w) return;
        if (!p) { w.style.left = 'auto'; w.style.right = '12px'; w.style.top = 'auto'; w.style.bottom = `calc(var(--bottom-nav-height) + ${this._fbDefs[id].off}px)`; return; }
        w.style.top = this.wbClampY(p.y) + 'px'; w.style.bottom = 'auto';
        if (p.side === 'l') { w.style.left = '8px'; w.style.right = 'auto'; } else { w.style.right = '8px'; w.style.left = 'auto'; }
      }
      updateFloatBubbles() {
        if (!this._fbDefs) return;
        Object.keys(this._fbDefs).forEach(id => {
          const w = document.getElementById(id); if (w) w.hidden = !this._fbDefs[id].views.includes(this.currentView);
        });
        lucide.createIcons();
      }

      /* ===== Available Balance bubble ===== */
      initBubble() {
        const w = document.getElementById('walletBubble'), fab = document.getElementById('wbFab');
        if (!w || !fab) return;
        try { const p = JSON.parse(localStorage.getItem('gghor_wb_pos') || 'null'); if (p && (p.side === 'l' || p.side === 'r') && isFinite(p.y)) this._wbPos = p; } catch (e) {}
        this.wbApplyPos();
        let down = false, drag = false, sx = 0, sy = 0, ox = 0, oy = 0;
        fab.addEventListener('pointerdown', e => {
          down = true; drag = false; sx = e.clientX; sy = e.clientY;
          const r = w.getBoundingClientRect(); ox = r.left; oy = r.top;
          try { fab.setPointerCapture(e.pointerId); } catch (_) {}
        });
        fab.addEventListener('pointermove', e => {
          if (!down) return;
          const dx = e.clientX - sx, dy = e.clientY - sy;
          if (!drag && Math.hypot(dx, dy) < 6) return;
          if (!drag) w.classList.remove('open');
          drag = true;
          const x = Math.min(Math.max(ox + dx, 4), window.innerWidth - w.offsetWidth - 4);
          const y = this.wbClampY(oy + dy);
          w.style.left = x + 'px'; w.style.right = 'auto'; w.style.top = y + 'px'; w.style.bottom = 'auto';
        });
        const end = () => {
          if (!down) return;
          down = false;
          if (drag) {
            const r = w.getBoundingClientRect();
            this._wbPos = { side: (r.left + r.width / 2) < window.innerWidth / 2 ? 'l' : 'r', y: this.wbClampY(r.top) };
            try { localStorage.setItem('gghor_wb_pos', JSON.stringify(this._wbPos)); } catch (e) {}
            this.wbApplyPos();
          } else this.toggleBubble();
        };
        fab.addEventListener('pointerup', end);
        fab.addEventListener('pointercancel', () => { down = false; this.wbApplyPos(); });
        document.addEventListener('pointerdown', e => { if (!w.contains(e.target)) w.classList.remove('open'); });
      }
      wbClampY(y) {
        const h = document.querySelector('header.app-header');
        const top = (h ? h.getBoundingClientRect().bottom : 68) + 8;
        return Math.min(Math.max(y, top), Math.max(top, window.innerHeight - 150));
      }
      wbApplyPos() {
        const w = document.getElementById('walletBubble'); if (!w) return;
        const p = this._wbPos;
        if (!p) { w.style.left = 'auto'; w.style.right = '12px'; w.style.top = 'auto'; w.style.bottom = 'calc(var(--bottom-nav-height) + 120px)'; return; }
        w.style.top = this.wbClampY(p.y) + 'px'; w.style.bottom = 'auto';
        if (p.side === 'l') { w.style.left = '8px'; w.style.right = 'auto'; } else { w.style.right = '8px'; w.style.left = 'auto'; }
      }
      toggleBubble() {
        const w = document.getElementById('walletBubble'), pn = document.getElementById('wbPanel'); if (!w || !pn) return;
        const r = w.getBoundingClientRect();
        pn.classList.toggle('wb-down', r.top < window.innerHeight / 2);
        pn.classList.toggle('wb-left', r.left + r.width / 2 < window.innerWidth / 2);
        w.classList.toggle('open');
      }
      updateBubble() {
        const w = document.getElementById('walletBubble'); if (!w) return;
        const show = !!this.currentUser && !['season', 'reader', 'aseason', 'areader'].includes(this.currentView);
        w.hidden = !show;
        if (!show) { w.classList.remove('open'); return; }
        const bdt = this.formatMoney(this.wallets.BDT || 0, 'BDT'), usd = this.formatMoney(this.wallets.USD || 0, 'USD');
        const set = (id, t) => { const e = document.getElementById(id); if (e && e.textContent !== t) e.textContent = t; };
        set('wbFabAmt', bdt); set('wbBDT', bdt); set('wbUSD', usd);
        this.wbApplyPos();
      }
      wbAddMoney() { const w = document.getElementById('walletBubble'); if (w) w.classList.remove('open'); this.openAddMoneyModal(); }
      wbWallet() { const w = document.getElementById('walletBubble'); if (w) w.classList.remove('open'); this.navigate('wallet'); }

/* ===== v12 chat bubble ===== */
      chatSeenKey() { return 'gg_chat_seen_' + (this.currentUser ? this.currentUser.uid : ''); }
      chatUnreadUpdate() {
        const b = document.getElementById('userChatBadge'); if (!b) return;
        if (this._chatOpen) { try { localStorage.setItem(this.chatSeenKey(), Date.now()); } catch (e) { } b.style.display = 'none'; return; }
        let seen = 0; try { seen = +localStorage.getItem(this.chatSeenKey()) || 0; } catch (e) { }
        const ts = x => (x.createdAt && x.createdAt.toMillis) ? x.createdAt.toMillis() : Date.now();
        const n = (this._chatMsgs || []).filter(x => x.isAdmin && ts(x) > seen).length;
        b.style.display = n ? 'grid' : 'none'; b.textContent = n > 99 ? '99+' : n;
      }
      toggleChatPopup() { this._chatOpen ? this.closeChatPopup() : this.openChatPopup(); }
      openChatPopup() {
        if (!this.currentUser) { this.toast('এই অংশ দেখতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        this._chatOpen = true; document.getElementById('userChatPopup').classList.add('open'); this.chatUnreadUpdate();
        const box = document.getElementById('userChatMessagesBox'); if (box) box.scrollTop = box.scrollHeight; lucide.createIcons();
      }
      closeChatPopup() { this._chatOpen = false; document.getElementById('userChatPopup').classList.remove('open'); this.chatUnreadUpdate(); }

      /* ===== v13 Entertainment ===== */
      tvE(x) { return String(x == null ? '' : x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
      ensureTvData() {
        if (this._tvOn) return; this._tvOn = 1;
        onSnapshot(collection(db, 'tv_categories'), sn => { this._tvC = sn.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.order || 0) - (b.order || 0)); this.tvRefresh(); });
        onSnapshot(collection(db, 'tv_platforms'), sn => { this._tvP = sn.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.order || 0) - (b.order || 0)); this.tvRefresh(); }, e => console.warn('tv_platforms', e));
        onSnapshot(collection(db, 'tv_items'), sn => { this._tvIr = sn.docs.map(d => ({ id: d.id, ...d.data() })).filter(x => x.active !== false).sort((a, b) => (a.order || 0) - (b.order || 0)); this.tvMerge(); this.tvRefresh(); });
        onSnapshot(collection(db, 'tv_reads'), sn => { this._tvR = {}; sn.docs.forEach(d => { this._tvR[d.id] = Number(d.data().count) || 0; }); this.tvRefresh(); }, e => console.warn('tv_reads', e));
        onSnapshot(collection(db, 'tv_seasons'), sn => { this._tvSer = sn.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.order || 0) - (b.order || 0)); this.tvMerge(); if (this.currentView === 'tvitem') this.tvOpen(this._tvCur, true); });
        ['fullscreenchange', 'webkitfullscreenchange'].forEach(ev => document.addEventListener(ev, () => { this.tvFsMark(); if (!(document.fullscreenElement || document.webkitFullscreenElement)) { try { screen.orientation.unlock(); } catch (e) { } } }));
        onSnapshot(collection(db, 'tv_episodes'), sn => { this._tvEr = sn.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.order || 0) - (b.order || 0)); this.tvMerge(); if (this.currentView === 'tvitem') this.tvOpen(this._tvCur, true); });
      }
      tvRefresh() { if (this.currentView === 'tv') this.renderTv(); else if (this.currentView === 'tvcat') this.renderTvCat(); else if (this.currentView === 'anime') this.renderAnime(); else if (this.currentView === 'tvmore') this.renderTvMore(); else if (this.currentView === 'tvplat') this.renderTvPlat(); else if (this.currentView === 'tvsc') this.renderTvSc(); }
      /* ===== Anime & Cartoon: tv_* এর সাথে একই প্লেয়ার/সিজন/এপিসোড সিস্টেম ব্যবহার করে ===== */
      /* ===== v23: Download (Episode / Movie) ===== */
      /* ===== Direct Download -> phone Downloads (NexaGHOR) ; কোনো Offline সেভ/Download Manager নেই ===== */
      _dlSafe(n) { return String(n || 'video').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120) || 'video'; }
      _dlExt(url, ct) { const m = String(url).split('?')[0].match(/\.(mp4|webm|ogg|mov|m4v|mkv|avi)$/i); return m ? m[1].toLowerCase() : (/webm/i.test(ct) ? 'webm' : /ogg/i.test(ct) ? 'ogg' : /quicktime/i.test(ct) ? 'mov' : /matroska/i.test(ct) ? 'mkv' : 'mp4'); }
      _dlUI() {
        let p = document.getElementById('dlPanel'); if (!p) { p = document.createElement('div'); p.id = 'dlPanel'; p.className = 'dl-panel'; document.body.appendChild(p); }
        const L = this._dlActive || []; p.classList.toggle('on', L.length > 0);
        p.innerHTML = L.map(a => `<div class="dl-row"><b>${this.tvE(a.name)}</b><span>${a.pct || 0}%</span><button type="button" class="dl-x" onclick="app.dlCancel('${a.id}')">✕</button></div><div class="dl-bar"><i style="width:${a.pct || 0}%"></i></div>`).join('');
      }
      dlCancel(id) { const x = (this._dlActive || []).find(a => a.id === id); if (x) { x.stop = true; try { x.ac.abort(); } catch (e) { } } }
      enqueueDownload(kind, id) {
        const T = this.tvDlTarget(kind, id), src = T && this.tvPickSrc(T.entry); if (!T || !src || !src.url) { this.toast('ডাউনলোড লিংক নেই', 'danger'); return; }
        const url = String(src.url).trim(); if (/(?:youtu\.be\/|youtube\.com\/)/i.test(url)) { this.toast('YouTube ভিডিও ডাউনলোড করা যায় না', 'danger'); return; }
        this._dlActive = this._dlActive || [];
        const name = 'NexaGHOR - ' + this._dlSafe(T.name);
        if (this._dlActive.some(a => a.url === url && a.name === name)) { this.toast('ভিডিওটি ইতিমধ্যে ডাউনলোড হচ্ছে', 'info'); return; }
        const x = { id: 'dl_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6), url, src, name, pct: 0, ac: new AbortController(), isHls: /\.m3u8(?:\?|$)/i.test(url) };
        this._dlActive.push(x); this._dlUI(); this.toast('ডাউনলোড শুরু হয়েছে', 'success'); this._dlRun(x);
      }
      async _dlRun(x) {
        try {
          /* Android app/WebView থাকলে সরাসরি Download/NexaGHOR ফোল্ডারে পাঠায় */
          const br = window.NexaGHORApp;
          if (!x.isHls && br && typeof br.downloadFile === 'function') { br.downloadFile(x.url, x.name + '.' + this._dlExt(x.url, ''), 'Download/NexaGHOR'); this.toast('Download/NexaGHOR ফোল্ডারে সেভ হচ্ছে', 'success'); return; }
          const blob = x.isHls ? await this._dlHls(x) : await this._dlPlain(x);
          this.dlSave(blob, x.name + '.' + x.ext);
          this.toast('ডাউনলোড সম্পন্ন — ফোনের Downloads ফোল্ডারে সেভ হয়েছে', 'success');
        } catch (e) { if (!x.stop) this.toast('ডাউনলোড ব্যর্থ: ' + ((e && e.message) || ''), 'danger'); }
        finally { this._dlActive = (this._dlActive || []).filter(a => a !== x); this._dlUI(); }
      }
      async _dlPlain(x) {
        const r = await fetch(x.url, { signal: x.ac.signal }); if (!r.ok) throw new Error('HTTP ' + r.status);
        const ct = r.headers.get('content-type') || ''; if (/text\/html/i.test(ct)) throw new Error('এটি সরাসরি ভিডিও ফাইল নয়');
        x.ext = this._dlExt(x.url, ct); const total = Number(r.headers.get('content-length')) || 0, mime = /^video\//i.test(ct) ? ct.split(';')[0] : 'video/mp4';
        if (!r.body || !r.body.getReader) return new Blob([await r.arrayBuffer()], { type: mime });
        const rd = r.body.getReader(), buf = []; let got = 0, t = 0;
        for (;;) { const z = await rd.read(); if (z.done) break; buf.push(z.value); got += z.value.length; x.pct = total ? Math.min(99, Math.floor(got / total * 100)) : 0; if (Date.now() - t > 300) { t = Date.now(); this._dlUI(); } }
        return new Blob(buf, { type: mime });
      }
      async _dlHls(x) {
        const ac = x.ac, fatal = m => { const e = new Error(m); e.fatal = true; return e; }, abs = (u, b) => new URL(u, b).href;
        const get = async u => { const r = await fetch(u, { signal: ac.signal }); if (!r.ok) { const e = new Error('HTTP ' + r.status); if (r.status >= 400 && r.status < 500) e.fatal = true; throw e; } return r; };
        let pl = await (await get(x.url)).text(), base = x.url;
        if (/#EXT-X-STREAM-INF/.test(pl)) {
          const L = pl.split(/\r?\n/), vs = [];
          for (let i = 0; i < L.length; i++) if (L[i].startsWith('#EXT-X-STREAM-INF')) {
            const bw = +(/BANDWIDTH=(\d+)/.exec(L[i]) || [0, 0])[1], h = +(/RESOLUTION=\d+x(\d+)/.exec(L[i]) || [0, 0])[1]; let j = i + 1;
            while (L[j] != null && (L[j].trim() === '' || L[j].startsWith('#'))) j++;
            if (L[j]) vs.push({ bw, h, inf: L[i], u: abs(L[j].trim(), base) });
          }
          if (!vs.length) throw fatal('Playlist পড়া যায়নি');
          const want = this.tvQNum(x.src && x.src.q);
          vs.sort((a, b) => want ? (Math.abs(a.h - want) - Math.abs(b.h - want)) || (b.bw - a.bw) : b.bw - a.bw);
          if (/AUDIO="/.test(vs[0].inf) && /#EXT-X-MEDIA:[^\n]*TYPE=AUDIO[^\n]*URI=/.test(pl)) throw fatal('অডিও আলাদা ট্র্যাকে আছে — সমর্থিত নয়');
          base = vs[0].u; pl = await (await get(base)).text();
        }
        if (/#EXT-X-BYTERANGE/.test(pl)) throw fatal('Byte-range playlist সমর্থিত নয়');
        const segs = []; let map = null, key = null, seq = +(/#EXT-X-MEDIA-SEQUENCE:(\d+)/.exec(pl) || [0, 0])[1];
        for (const raw of pl.split(/\r?\n/)) {
          const t = raw.trim();
          if (t.startsWith('#EXT-X-KEY')) { const m = /METHOD=([A-Z0-9-]+)/.exec(t); if (!m || m[1] === 'NONE') key = null; else if (m[1] === 'AES-128') { const u = /URI="([^"]+)"/.exec(t), iv = /IV=0x([0-9a-fA-F]+)/.exec(t); if (!u) throw fatal('Key URL নেই'); key = { u: abs(u[1], base), iv: iv ? iv[1] : null }; } else throw fatal('এই এনক্রিপশন (' + m[1] + ') সমর্থিত নয়'); }
          else if (t.startsWith('#EXT-X-MAP')) { const m = /URI="([^"]+)"/.exec(t); if (m) map = abs(m[1], base); }
          else if (t && !t.startsWith('#')) segs.push({ u: abs(t, base), key, seq: seq++ });
        }
        if (!segs.length) throw fatal('সেগমেন্ট পাওয়া যায়নি');
        x.ext = map ? 'mp4' : 'ts'; const mime = map ? 'video/mp4' : 'video/mp2t', off = map ? 1 : 0, out = new Array(segs.length + off);
        const keys = {}, getKey = k => keys[k.u] || (keys[k.u] = (async () => crypto.subtle.importKey('raw', await (await get(k.u)).arrayBuffer(), 'AES-CBC', false, ['decrypt']))());
        const dec = async (buf, s) => { const ck = await getKey(s.key), iv = new Uint8Array(16); if (s.key.iv) { const h = s.key.iv.padStart(32, '0'); for (let i = 0; i < 16; i++) iv[i] = parseInt(h.substr(i * 2, 2), 16); } else { let n = s.seq; for (let i = 15; i >= 8 && n > 0; i--) { iv[i] = n % 256; n = Math.floor(n / 256); } } return crypto.subtle.decrypt({ name: 'AES-CBC', iv }, ck, buf); };
        if (map) out[0] = await (await get(map)).arrayBuffer();
        let next = 0, done = 0;
        const worker = async () => {
          for (;;) {
            if (x.stop) return; const k = next++; if (k >= segs.length) return;
            for (let t = 0; ; t++) {
              try { let buf = await (await get(segs[k].u)).arrayBuffer(); if (segs[k].key) buf = await dec(buf, segs[k]); out[k + off] = buf; done++; x.pct = Math.min(99, Math.floor(done / segs.length * 100)); this._dlUI(); break; }
              catch (e) { if (x.stop || e.fatal || t >= 3) throw e; await new Promise(r => setTimeout(r, 700 * (t + 1))); }
            }
          }
        };
        await Promise.all([worker(), worker(), worker()]);
        if (x.stop) throw new Error('stopped');
        return new Blob(out, { type: mime });
      }
      tvPickSrc(entry) {
        const S = this.tvSources(entry); if (!S.length) return null;
        const langs = [...new Set(S.map(s => s.lang || 'Original'))], lang = langs.includes(this._tvLang) ? this._tvLang : langs[0];
        const L = S.filter(s => (s.lang || 'Original') === lang), qs = L.map(s => s.q || 'Auto');
        const q = qs.includes(this._tvQ) ? this._tvQ : (qs.find(x => this.tvQNum(x) === 720) || qs.find(x => this.tvQNum(x) === 480) || qs[0]);
        return L.find(s => (s.q || 'Auto') === q) || L[0];
      }
      tvDlTarget(kind, id) {
        const it = (this._tvI || []).find(x => x.id === this._tvCur); if (!it) return null;
        if (kind === 'cur') { if (!this._tvEpId) return null; kind = this._tvEpId === 'main' ? 'main' : 'ep'; id = this._tvEpId; }
        if (kind === 'main') return { entry: it, name: it.title, it };
        const e = (this._tvE || []).find(x => x.id === id); if (!e) return null;
        const se = (this._tvSe || []).find(x => x.id === e.seasonId);
        return { entry: e, name: [it.title, se && se.title, e.title].filter(Boolean).join(' - '), it };
      }
      tvDlRender() {
        try { this.tvHeroBtns(); } catch (e) { }
        const el = document.getElementById('tvDl'); if (!el) return;
        const T = this.tvDlTarget('cur'), src = T && this.tvPickSrc(T.entry);
        if (!src) { el.innerHTML = ''; return; }
        const q = src.q && src.q !== 'Auto' ? src.q : '';
        el.innerHTML = `<button type="button" class="tv-dl-btn" onclick="app.tvDownload('cur')"><i data-lucide="download"></i>${this._tvEpId === 'main' ? 'Movie Download' : 'Episode Download'}${q ? ' · ' + this.tvE(q) : ''}</button>`;
        lucide.createIcons();
      }
      tvHeroBtns() {
        const el = document.getElementById('tvHeroBtns'); if (!el) return;
        const cid = this._tvCur, sv = cid && this.isWatchLater(cid), n = this.currentUser ? (this._watchLater || []).length : 0;
        el.innerHTML = `<button type="button" class="tvh-btn ${sv ? 'saved' : ''}" onclick="app.toggleWatchLater('${cid}')"><i data-lucide="${sv ? 'check' : 'plus'}"></i>Watching Later</button>`
          + `<button type="button" class="tvh-btn" onclick="app.tvOpenWatchLater()"><i data-lucide="star"></i>Watching Later <span class="tvh-cnt">${n}</span></button>`;
        lucide.createIcons();
      }
      tvOpenWatchLater() {
        if (!this.currentUser) { this.toast('Watching Later ব্যবহার করতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        this.navigate('account'); setTimeout(() => { const b = document.getElementById('watchLaterBox'); if (b) b.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 250);
      }
      tvHeroRender(it, se, ss, rows, mv) {
        const box = document.getElementById('tvHero'); if (!box || !it) return;
        const E = x => this.tvE(x == null ? '' : String(x));
        const meta = (this._tvMeta && this._tvMeta[it.id]) || {};
        const bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
        const srcs = [...this.tvSources(it), ...(this._tvEpsCur || []).flatMap(e => this.tvSources(e))];
        let langs = [...new Set(srcs.map(x => String(x.lang || '').trim()).filter(x => x && x !== 'Original'))];
        const lang = (it.language || it.lang) ? String(it.language || it.lang) : (langs.length > 1 ? 'Multi' : (langs[0] || ''));
        const qs = [...new Set(srcs.map(x => String(x.q || '').trim()).filter(x => x && x !== 'Auto'))].sort((a, b) => this.tvQNum(b) - this.tvQNum(a));
        const quality = String(it.quality || it.printQuality || qs[0] || '');
        const isSeries = !mv && (ss.length > 0 || rows.length > 1);
        const type = isSeries ? 'Series' : 'Movie';
        let yr = String(it.year || '').match(/\d{4}/); yr = yr ? yr[0] : ((String(meta.date || it.released || it.releaseDate || '').match(/\d{4}/) || [''])[0]);
        const title = String(it.title || ''), hasYr = /\(\s*\d{4}\s*\)/.test(title);
        const nos = rows.map(r => r.no).filter(n => n > 0), mn = nos.length ? Math.min(...nos) : 0, mx = nos.length ? Math.max(...nos) : 0;
        let epLine = '';
        if (se) { const sl = this.tvSeLabel(se, ss.indexOf(se)); epLine = sl + (mx ? ` [Ep ${mn}${mx > mn ? '-' + mx : ''} Added]` : ''); }
        else if (isSeries && mx) epLine = `[Ep ${mn}${mx > mn ? '-' + mx : ''} Added]`;
        const st = String(it.status || meta.status || '').trim();
        const ongoing = /ongoing|running|returning|in production|airing/i.test(st);
        const sched = String(it.schedule || it.airTime || it.airtime || it.time || '').trim();
        const stParts = [];
        if (st) stParts.push(`<span><span class="dot" style="${ongoing ? '' : 'background:#94a3b8'}"></span>${E(ongoing ? 'Ongoing' : st)}</span>`);
        if (st && ongoing && mx) stParts.push(`<span>নতুন পর্ব ${bn(mx)}</span>`);
        if (st && sched) stParts.push(`<span>${E(sched)}</span>`);
        const statusHtml = stParts.length ? `<div class="tvh-status">${stParts.join('<i class="sep">·</i>')}</div>` : '';
        const th = it.thumb || it.poster || '';
        box.innerHTML = `<div class="tvh-poster">${th ? `<img src="${E(th)}" alt="" onerror="this.remove()">` : ''}${quality ? `<span class="tvh-b q">${E(quality)}</span>` : ''}${lang ? `<span class="tvh-b lang">${E(lang).toUpperCase()}</span>` : ''}<span class="tvh-b type">${type}</span></div>`
          + `<div class="tvh-card"><h1 class="tvh-title">${E(title)}${yr && !hasYr ? ` (${yr})` : ''}</h1>${epLine ? `<div class="tvh-ep">${E(epLine)}</div>` : ''}${statusHtml}`
          + `<div class="tvh-meta"><div class="t"><span>Type</span><b>${type}</b></div><div class="l"><span>Language</span><b>${E(lang || '—')}</b></div><div class="qq"><span>Quality</span><b>${E(quality || '—')}</b></div></div>`
          + `<div class="tvh-btns" id="tvHeroBtns"></div></div>`;
        this.tvHeroBtns();
      }
      tvEpMore() { this._tvEpMore = !this._tvEpMore; this.tvOpen(this._tvCur, true); }
      dlSave(blob, name) {
        const url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = name; a.rel = 'noopener'; a.style.position = 'fixed'; a.style.left = '-9999px';
        document.body.appendChild(a);
        /* Android Chrome-এর download manager trigger করার জন্য real DOM click */
        try { a.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); } catch (e) { a.click(); }
        setTimeout(() => { try { URL.revokeObjectURL(url); a.remove(); } catch (e) { } }, 300000);
      }
      async tvDownload(kind, id) {
        this.enqueueDownload(kind, id);
      }
      /* ===== v23: Watching History ===== */
      tvHistAdd(epId) {
        if (!this.currentUser || !this._tvCur) return;
        const itemId = this._tvCur, ep = (!epId || epId === 'main') ? '' : epId, key = itemId + '_' + (ep || 'movie'), now = Date.now();
        this._histLast = this._histLast || {}; if (this._histLast[key] && now - this._histLast[key] < 20000) return; this._histLast[key] = now;
        const uid = this.currentUser.uid, H = this._hist || [];
        setDoc(doc(db, 'users', uid, 'history', key), { itemId, epId: ep, ts: now }, { merge: true }).catch(e => console.warn('history', e));
        if (H.length >= 100 && !H.some(h => h.id === key)) { const old = H[H.length - 1]; if (old) deleteDoc(doc(db, 'users', uid, 'history', old.id)).catch(() => { }); }
      }
      histInfo(h) {
        const it = (this._tvI || []).find(x => x.id === h.itemId); if (!it) return null;
        const ep = h.epId ? (this._tvE || []).find(x => x.id === h.epId) : null; if (h.epId && !ep) return null;
        const se = ep ? (this._tvSe || []).find(x => x.id === ep.seasonId) : null, K = it.ak ? ((this.anKinds()[it.ak] || {}).label) : 'Movies & TV';
        return { it, ep, title: ep ? ep.title : it.title, sub: ep ? [it.title, se && se.title].filter(Boolean).join(' • ') : (K || 'Movie'), thumb: it.thumb || '' };
      }
      histThumb(i) { return `<div class="hth${i.adult ? ' blur' : ''}">${i.thumb ? `<img src="${this.tvE(i.thumb)}" loading="lazy" alt="">` : ''}</div>`; }
      histRefresh() { if (this.currentView === 'account') this.histBox(); else if (this.currentView === 'history') this.renderHistory(); }
      histBox() {
        const el = document.getElementById('histBox'); if (!el) return;
        if (!this.currentUser) { el.innerHTML = ''; return; }
        const L = (this._hist || []).map(h => ({ h, i: this.histInfo(h) })).filter(x => x.i), E = x => this.tvE(x);
        el.innerHTML = `<div class="hist-sec"><div class="hist-head"><b>🕘 Watching History</b>${L.length ? `<button type="button" onclick="app.navigate('history')">সব দেখুন ›</button>` : ''}</div>`
          + (L.length ? `<div class="hist-strip">${L.slice(0, 12).map(x => `<div class="hist-card" onclick="app.histOpen('${x.h.id}')">${this.histThumb(x.i)}<b>${E(x.i.title)}</b><small>${E(x.i.sub)}</small></div>`).join('')}</div>` : '<div style="color:var(--text-dim);font-size:.82rem">এখনো কিছু দেখেননি</div>') + '</div>';
        lucide.createIcons();
      }
      renderHistory() {
        const box = document.getElementById('histList'); if (!box) return;
        const q = (this._histQ || '').trim().toLowerCase(), E = x => this.tvE(x), today = new Date(); today.setHours(0, 0, 0, 0);
        const L = (this._hist || []).map(h => ({ h, i: this.histInfo(h) })).filter(x => x.i && (!q || (x.i.title + ' ' + x.i.sub).toLowerCase().includes(q)));
        const dayLabel = ts => { const d = new Date(ts); d.setHours(0, 0, 0, 0); const diff = Math.round((today - d) / 86400000); return diff <= 0 ? 'আজ' : diff === 1 ? 'গতকাল' : d.toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }); };
        let last = '', html = '';
        L.forEach(({ h, i }) => {
          const dl = dayLabel(h.ts); if (dl !== last) { last = dl; html += `<div class="hist-day">${dl}</div>`; }
          html += `<div class="hist-row" onclick="app.histOpen('${h.id}')">${this.histThumb(i)}<div class="hmeta"><b>${E(i.title)}</b><small>${E(i.sub)}</small><small>${new Date(h.ts).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}</small></div><button type="button" class="hist-x" aria-label="Remove" onclick="event.stopPropagation();app.histDel('${h.id}')"><i data-lucide="x"></i></button></div>`;
        });
        box.innerHTML = html || '<div style="text-align:center;padding:40px;color:var(--text-dim)">কোনো ইতিহাস নেই</div>';
        lucide.createIcons();
      }
      histSearch(v) { this._histQ = v; this.renderHistory(); }
      histDel(id) { if (!this.currentUser) return; deleteDoc(doc(db, 'users', this.currentUser.uid, 'history', id)).catch(() => this.toast('মুছতে ব্যর্থ হয়েছে', 'danger')); }
      async histClear() {
        if (!this.currentUser || !(this._hist || []).length) return; if (!confirm('সব Watching History মুছে ফেলবেন?')) return;
        try { const b = writeBatch(db); this._hist.forEach(h => b.delete(doc(db, 'users', this.currentUser.uid, 'history', h.id))); await b.commit(); this.toast('ইতিহাস মুছে ফেলা হয়েছে', 'success'); } catch (e) { this.toast('মুছতে ব্যর্থ হয়েছে', 'danger'); }
      }
      histOpen(id) {
        const h = (this._hist || []).find(x => x.id === id); if (!h) return;
        const inf = this.histInfo(h); if (!inf) { this.toast('এই কনটেন্ট আর নেই', 'danger'); return; }
        const it = inf.it;
        this._tvCur = it.id; this._tvFrom = 'history'; this._tvStarted = true;
        this._tvSeason = inf.ep ? inf.ep.seasonId : (this.tvSeasonsOf(it.id).length ? '__movie' : null);
        this.tvRecord(it.id); this.tvStart(inf.ep || it, inf.ep ? inf.ep.id : 'main'); this.tvOpen(it.id, true);
      }
      tvMerge() {
        const o = (a, b) => (a.order || 0) - (b.order || 0);
        this._tvI = [...(this._tvIr || []), ...(this._anIr || [])].sort(o);
        this._tvSe = [...(this._tvSer || []), ...(this._anSer || [])].sort(o);
        this._tvE = [...(this._tvEr || []), ...(this._anEr || [])].sort(o);
        if (this.currentView === 'account' || this.currentView === 'history') this.histRefresh();
      }
      anKinds() {
        return this._anKinds || (this._anKinds = {
          anime: { label: 'Anime & Cartoon', icon: 'sparkles', folders: 'anime_folders', cats: 'anime_cats', items: 'anime_items', seasons: 'anime_seasons', eps: 'anime_episodes' },
          drama: { label: 'K/J/C Drama', icon: 'heart', folders: 'drama_folders', cats: 'drama_cats', items: 'drama_items', seasons: 'drama_season', eps: 'drama_episode' },
          series: { label: 'Hindi/English Series', icon: 'tv', folders: 'series_folders', cats: 'series_cats', items: 'series_items', seasons: 'series_season', eps: 'series_episode' },
          bd: { label: 'Bangladesh Movies', icon: 'film', folders: 'bd_folders', cats: 'bd_cats', items: 'bd_items', seasons: 'bd_season', eps: 'bd_episode' },
          movie: { label: 'Movies & TV', icon: 'film', folders: 'movie_folders', cats: 'movie_cats', items: 'movie_items', seasons: 'movie_season', eps: 'movie_episode' },
          sport: { label: 'Sports', icon: 'trophy', folders: 'sport_folders', cats: 'sport_cats', items: 'sport_items', seasons: 'sport_season', eps: 'sport_episode' }
        });
      }
      anLabel() { return (this.anKinds()[this._anK || 'anime'] || {}).label || 'Anime & Cartoon'; }
      anMergeAll() {
        const ks = Object.keys(this.anKinds()), D = this._ANK;
        this._anIr = ks.flatMap(k => D[k].Ir || []); this._anSer = ks.flatMap(k => D[k].Se || []); this._anEr = ks.flatMap(k => D[k].E || []);
        this.tvMerge();
      }
      anAllCats(incl) { const D = this._ANK || {}; return Object.keys(D).flatMap(k => D[k].C || []); }
      ensureAnimeData() {
        if (this._anOn) return; this._anOn = 1;
        const o = (a, b) => (a.order || 0) - (b.order || 0), K = this.anKinds(); this._ANK = {};
        Object.keys(K).forEach(k => {
          const D = this._ANK[k] = { C: [], Ir: [], Se: [], E: [] }, c = K[k];
          const AN = (col, fn) => onSnapshot(collection(db, col), sn => fn(sn.docs.map(d => ({ id: d.id, ...d.data(), an: true, ak: k })).sort(o)), e => console.warn(col, e));
          AN(c.cats, L => { D.C = L; this.tvRefresh(); });
          AN(c.items, L => { D.Ir = L.filter(x => x.active !== false); this.anMergeAll(); this.tvRefresh(); });
          AN(c.seasons, L => { D.Se = L; this.anMergeAll(); if (this.currentView === 'tvitem') this.tvOpen(this._tvCur, true); });
          AN(c.eps, L => { D.E = L; this.anMergeAll(); if (this.currentView === 'tvitem') this.tvOpen(this._tvCur, true); });
        });
      }
      anEnter(k) { k = k || 'anime'; this._anK = k; this._anFid = null; this._anCid = ''; this._anQ = ''; const i = document.getElementById('anQ'); if (i) i.value = ''; this.navigate('anime'); }
      anBack() { this.navigate('tv'); }
      anSetCat(id) { this._anCid = id || ''; this.renderAnime(); }
      anSearch(v) { this._anQ = v; this.renderAnime(); }
      renderAnime() {
        this.ensureTvData(); this.ensureAnimeData();
        const k = this._anK || 'anime', D = (this._ANK || {})[k] || { C: [] };
        
        const C = D.C || [], I = (this._tvI || []).filter(i => i.an && i.ak === k), E = x => this.tvE(x);
        const body = document.getElementById('anBody'), cats = document.getElementById('anCats'), sw = document.getElementById('anSearchWrap'); if (!body) return;
        document.getElementById('anBackTxt').textContent = 'Back to Entertainment';
        document.getElementById('anTitle').textContent = this.anLabel();
        const empty = '<div style="text-align:center;padding:40px;color:var(--text-dim)">কোনো কনটেন্ট নেই</div>';
        sw.style.display = 'block';
        { const ap = document.getElementById('anPlat'); if (ap) { const h = ['anime', 'drama', 'series', 'bd'].includes(k) ? this.tvKindPlatStrip(k) : ''; if (ap._sig !== h) { ap._sig = h; ap.innerHTML = h; } } }
        const fc = C.filter(c => I.some(i => i.cat === c.id)); if (this._anCid && !fc.some(c => c.id === this._anCid)) this._anCid = '';
        const q = (this._anQ || '').trim().toLowerCase();
        cats.innerHTML = `<button class="tv-cat ${!this._anCid ? 'active' : ''}" onclick="app.anSetCat('')">সব</button>` + fc.map(c => `<button class="tv-cat ${this._anCid === c.id ? 'active' : ''}" onclick="app.anSetCat('${c.id}')">${E(c.name)}</button>`).join('');
        if (q || this._anCid) {
          const R = I.filter(i => (!this._anCid || i.cat === this._anCid) && (!q || (i.title || '').toLowerCase().includes(q))).sort((x, y) => this._newFirst(x, y));
          body.innerHTML = R.length ? `<div class="tv-grid">${R.map(i => this.tvCard(i, fc)).join('')}</div>` : empty;
        } else {
          const sec = (name, R, cid) => `<div class="tv-sec"><div class="tv-sec-head"><b>${E(name)}</b>${cid && R.length > 4 ? `<button type="button" class="tv-more" onclick="app.anSetCat('${cid}')">আরও দেখুন ›</button>` : ''}</div><div class="tv-row">${R.slice(0, 4).map(i => this.tvCard(i, fc)).join('')}</div></div>`;
          let h = fc.map(c => sec(c.name, I.filter(i => i.cat === c.id).sort((x, y) => this._newFirst(x, y)), c.id)).join('');
          const oth = I.filter(i => !fc.some(c => c.id === i.cat)); if (oth.length) h += sec('অন্যান্য', oth, null);
          body.innerHTML = h || empty;
        }
        lucide.createIcons();
      }
      tvCats() { const D = [{ id: 'live', name: 'Live TV' }, { id: 'movie', name: 'Movies' }, { id: 'sport', name: 'Sports' }, { id: 'music', name: 'Music' }, { id: 'drama', name: 'Drama' }]; return (this._tvC && this._tvC.length) ? this._tvC : D; }
      /* ===== NEW badge: item-এর জন্য ৭ দিন, Episode-এর জন্য ৩ দিন ===== */
      _NEW_MS() { return 7 * 86400000; }
      _EP_NEW_MS() { return 3 * 86400000; }
      _tsMs(v) { if (!v) return 0; if (typeof v.toMillis === 'function') return v.toMillis(); if (typeof v === 'number') return v < 1e12 ? v * 1000 : v; const t = Date.parse(v); return isNaN(t) ? 0 : t; }
      _lastAdd(i) { return i ? Math.max(this._tsMs(i.lastAddedAt), this._tsMs(i.createdAt)) : 0; }
      _isNew(i) { const t = this._lastAdd(i); return t > 0 && (Date.now() - t) < this._NEW_MS(); }
      _isEpisodeNew(i) { const t = this._lastAdd(i); return t > 0 && (Date.now() - t) < this._EP_NEW_MS(); }
      _newBadge(i) { return this._isNew(i) ? '<span class="new-badge">NEW</span>' : ''; }
      /* Episode-এর NEW badge ৩ দিন পার হলে app খোলা থাকলেও নিজে থেকে সরে যাবে */
      _newSig() { const ids = []; [this.books, this._tvI].forEach(L => (L || []).forEach(i => { if (this._isNew(i)) ids.push('i:' + i.id); })); (this._tvE || []).forEach(i => { if (this._isEpisodeNew(i)) ids.push('e:' + i.id); }); return ids.sort().join(','); }
      _newExpiryCheck() {
        const s = this._newSig(); if (s === this._newSigV) return; this._newSigV = s;
        this.renderMagazine(); this.tvRefresh();
        if (this.currentView === 'tvitem' && this._tvCur) this.tvOpen(this._tvCur, true);
      }
      newExpiryWatch() {
        if (this._newWatchOn) return; this._newWatchOn = true; this._newSigV = this._newSig();
        setInterval(() => this._newExpiryCheck(), 60000);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) this._newExpiryCheck(); });
      }
      /* নতুন যুক্ত আইটেম আগে (সর্বশেষ যুক্ত সবার উপরে), বাকিগুলো আগের ক্রমেই */
      _newFirst(a, b) { const pa = a.pinned ? 1 : 0, pb = b.pinned ? 1 : 0; if (pa !== pb) return pb - pa; if (pa) return (Number(b.pinnedAt) || 0) - (Number(a.pinnedAt) || 0); const na = this._isNew(a) ? 1 : 0, nb = this._isNew(b) ? 1 : 0; if (na !== nb) return nb - na; return na ? (this._lastAdd(b) - this._lastAdd(a)) : 0; }
      tvTs(i) { const c = i.createdAt; return c && c.toMillis ? c.toMillis() : (Number(c) || 0); }
      /* নতুন ৭টি আইটেম — Latest Upload-এ auto slide, অন্য rail-এ manual swipe */
      tvNewFill(elId, items, cats, show) {
        const el = document.getElementById(elId); if (!el) return;
        let h = '';
        if (show) {
          const L = items.map((x, k) => ({ x, k })).sort((a, b) => (this._lastAdd(b.x) - this._lastAdd(a.x)) || (b.k - a.k)).slice(0, 7).map(o => o.x);
          if (L.length) {
            let seq = L.slice();
            const cards = seq.concat(seq).map(i => this.tvCard(i, cats, 'tv-new-card')).join('');
            h = `<div class="tv-new tv-manual-rail"><div class="tv-sec-head"><b>🆕 নতুন যুক্ত</b></div><div class="tv-new-vp"><div class="tv-new-track">${cards}</div></div></div>`;
          }
        }
        if (el._sig !== h) { el._sig = h; el.innerHTML = h; }
      }
      tvCard(i, cats, cls, rank) {
        const n = this._fmtCount((this._tvR || {})[i.id] || 0), saved = this.isWatchLater(i.id);
        const age = this.tvAge(i), meta = this.tvCardMeta(i), lang = i.language || i.lang || '';
        return `<div class="tv-card ${cls || ''}" onclick="app.tvOpenItem('${i.id}')"><div class="tv-th"><img src="${this.tvE(i.thumb)}" alt="" loading="lazy"><span class="bk-count">${this._eyeSvg()}${n}</span>${rank ? `<span class="rank-no r${rank <= 3 ? rank : 'x'}"><i>#</i>${rank}</span>` : ''}${i.pinned ? '<span class="pin-badge">📌</span>' : ''}${this._newBadge(i)}${lang ? `<span class="lang-badge">${this.tvE(lang)}</span>` : ''}</div>${meta ? `<span class="tv-card-meta">${this.tvE(meta)}</span>` : ''}${age ? `<span class="tv-card-age">${this.tvE(age)}</span>` : ''}<b>${this.tvE(i.title)}</b><small>${this.tvE((cats.find(c => c.id === i.cat) || {}).name || '')}</small></div>`;
      }
      _tvDateMs(v) { return this._tsMs(v); }
      tvAge(i) { const t = this._lastAdd(i); if (!t) return ''; const d = Math.max(0, Date.now() - t); const m = Math.floor(d / 60000); if (m < 60) return m <= 1 ? 'এইমাত্র আপলোড' : m + ' মিনিট আগে'; const h = Math.floor(m / 60); if (h < 24) return h + ' ঘণ্টা আগে'; const days = Math.floor(h / 24); return days < 30 ? days + ' দিন আগে' : new Date(t).toLocaleDateString('bn-BD'); }
      tvCardMeta(i) {
        const ss = this.tvSeasonsOf(i.id), eps = (this._tvE || []).filter(e => e.itemId === i.id), p = [];
        if (ss.length) { const nums = ss.map(s => String(s.title || '').match(/\d+/)?.[0]).filter(Boolean); p.push(nums.length ? `Season ${nums.length > 1 ? nums[0] + '-' + nums[nums.length - 1] : nums[0]}` : `${ss.length} Season`); }
        if (eps.length) p.push(`Ep 1-${eps.length}`);
        return p.length ? `[${p.join(' | ')}]` : '';
      }
      isWatchLater(id) { return !!(this._watchLater || []).some(x => x.itemId === id); }
      async toggleWatchLater(id) {
        if (!this.currentUser) { this.toast('Watch later ব্যবহার করতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        const ref = doc(db, 'users', this.currentUser.uid, 'watch_later', id);
        try { if (this.isWatchLater(id)) { await deleteDoc(ref); this.toast('Watch later থেকে সরানো হয়েছে', 'info'); } else { await setDoc(ref, { itemId:id, ts:Date.now() }); this.toast('Watch later-এ রাখা হয়েছে', 'success'); } } catch(e) { this.toast('Watch later আপডেট করা যায়নি', 'danger'); }
      }
      watchLaterInfo(x) { const it = (this._tvI || []).find(i => i.id === x.itemId); return it ? { it, ts:x.ts || 0 } : null; }
      renderWatchLater() {
        try { this.tvDlRender(); } catch (e) {}
        const el = document.getElementById('watchLaterBox'); if (!el) return;
        if (!this.currentUser) { el.innerHTML=''; return; }
        const L = (this._watchLater || []).map(x => this.watchLaterInfo(x)).filter(Boolean).sort((a,b)=>b.ts-a.ts), cats=this.tvCats().concat(this.anAllCats(true));
        el.innerHTML = `<div class="tv-later-sec"><div class="tv-later-head"><b>🔖 Watch later</b><small>${L.length} টি</small></div>${L.length ? `<div class="tv-later-grid">${L.map(x=>this.tvCard(x.it,cats)).join('')}</div>` : '<div style="color:var(--text-dim);font-size:.82rem">এখনো কোনো ভিডিও রাখা হয়নি</div>'}</div>`;
        lucide.createIcons();
      }
      renderTv() {
        this.ensureTvData();
        const IC = { live: 'tv', movie: 'film', sport: 'trophy', music: 'music', drama: 'video' };
        this.ensureAnimeData();
        const cats = this.tvCats(), items = (this._tvI || []).filter(i => !i.an);
        const ae = document.getElementById('tvAnimeEntry'); if (ae) { ae._sig = ''; ae.innerHTML = ''; ae.style.display = 'none'; }
        if (ae) { const K = this.anKinds(), D = this._ANK || {}; const h = Object.keys(K).filter(k => D[k] && (D[k].Ir || []).length).map(k => `<button type="button" class="an-entry" onclick="app.anEnter('${k}')"><span class="an-entry-ic"><i data-lucide="${K[k].icon}"></i></span><span><b>${this.tvE(K[k].label)}</b><small>${D[k].Ir.length} টি ভিডিও</small></span><i data-lucide="chevron-right"></i></button>`).join(''); if (ae._sig !== h) { ae._sig = h; ae.innerHTML = h; } }
        const q = (this._tvSq || '').trim().toLowerCase(), g = document.getElementById('tvGrid');
        const all = this._tvI || [], R = this._tvR || {}, ac = cats.concat(this.anAllCats(true));
        const latest = [...all].sort((x, y) => this._lastAdd(y) - this._lastAdd(x)).slice(0, 12);
        const trend = all.filter(i => (R[i.id] || 0) > 0).sort((x, y) => (R[y.id] - R[x.id]) || (this.tvTs(y) - this.tvTs(x))).slice(0, 12);
        this.tvPlatStrip(!q);
        this.tvStrip('tvTrend', '🔥 Most Trending', trend, ac, !q);
        this.tvStrip('tvNew', '🆕 Latest Upload', latest, ac, !q);
        const empty = '<div style="text-align:center;padding:40px;color:var(--text-dim)">কোনো কনটেন্ট নেই</div>';
        if (q) {
          const L = all.filter(i => (i.title || '').toLowerCase().includes(q) || ((ac.find(c => c.id === i.cat) || {}).name || '').toLowerCase().includes(q));
          g.innerHTML = L.length ? `<div class="tv-grid">${L.sort((x, y) => this._newFirst(x, y)).map(i => this.tvCard(i, ac)).join('')}</div>` : empty;
        } else {
          const h = this.tvSecs().map(S => {
            const L = this.tvSecList(S); if (!L.length) return '';
            return `<div class="tv-sec"><div class="tv-sec-head"><b>${this.tvE(S.label)}</b></div>${S.key === 'sport' ? this.tvSportStrip(L) : ''}${['anime', 'drama', 'series', 'bd'].includes(S.key) ? this.tvKindPlatStrip(S.key) : ''}<div class="tv-grid">${L.slice(0, S.n).map(i => this.tvCard(i, ac)).join('')}</div>${L.length > S.n ? `<button type="button" class="tv-sec-more" onclick="app.tvMoreOpen('${S.key}')">আরও দেখুন (${L.length - S.n}) ›</button>` : ''}</div>`;
          }).join('');
          g.innerHTML = h || empty;
        }
        lucide.createIcons();
      }
      /* ===== v21: Entertainment হোম সেকশন, স্ট্রিপ, More পেজ ===== */
      tvSecs() {
        return [
          { key: 'tv', label: 'Movies & TV', n: 20, pick: i => !i.an || i.ak === 'movie' },
          { key: 'bd', label: 'Bangladesh Movies', n: 16, pick: i => i.ak === 'bd' },
          { key: 'anime', label: 'Anime & Cartoon', n: 24, pick: i => i.ak === 'anime' },
          { key: 'series', label: 'Hindi/English Series', n: 20, pick: i => i.ak === 'series' },
          { key: 'drama', label: 'K/J/C Drama', n: 24, pick: i => i.ak === 'drama' },
          { key: 'sport', label: 'Sports', n: 20, pick: i => i.ak === 'sport' }
        ];
      }
      tvSecList(S) { return (this._tvI || []).filter(S.pick).sort((x, y) => this._newFirst(x, y) || ((x.order || 0) - (y.order || 0)) || (this.tvTs(y) - this.tvTs(x))); }
      tvStrip(elId, title, list, cats, show) {
        const el = document.getElementById(elId); if (!el) return;
        let h = '';
        if (show && list.length) {
          let seq = list.slice(), auto = elId === 'tvNew';
          const source = auto ? seq.concat(seq) : seq;
          const cards = source.map((i, n) => this.tvCard(i, cats, 'tv-new-card', elId === 'tvTrend' ? (n % seq.length) + 1 : 0)).join('');
          h = `<div class="tv-new ${auto ? 'tv-latest-auto' : 'tv-manual-rail'}"><div class="tv-sec-head"><b>${title}</b></div><div class="tv-new-vp"><div class="tv-new-track">${cards}</div></div></div>`;
        }
        if (el._sig !== h) { el._sig = h; el.innerHTML = h; }
        if (elId === 'tvNew') {
          const vp = el.querySelector('.tv-latest-auto .tv-new-vp');
          if (vp && !vp._touchPauseBound) {
            let resumeTimer = 0;
            const pause = () => { clearTimeout(resumeTimer); vp.classList.add('touch-paused'); };
            const resume = () => { clearTimeout(resumeTimer); resumeTimer = setTimeout(() => vp.classList.remove('touch-paused'), 2500); };
            vp.addEventListener('touchstart', pause, { passive: true });
            vp.addEventListener('touchend', resume, { passive: true });
            vp.addEventListener('touchcancel', resume, { passive: true });
            vp._touchPauseBound = true;
          }
        }
      }
      /* ===== Sports Category (ছবি সহ) স্লাইডার + Category পেজ ===== */
      /* Admin-এর pinned Sports category আগে, একই pin হলে সর্বশেষ pinned আগে, তারপর manual order */
      tvSportCats() {
        return (((this._ANK || {}).sport || {}).C || []).slice().sort((a, b) => {
          const pa = a.pinned ? 1 : 0, pb = b.pinned ? 1 : 0;
          if (pa !== pb) return pb - pa;
          if (pa) return (Number(b.pinnedAt) || 0) - (Number(a.pinnedAt) || 0);
          return (a.order || 0) - (b.order || 0);
        });
      }
      tvSportStrip(L) {
        const C = this.tvSportCats().filter(c => L.some(i => i.cat === c.id)); if (!C.length) return '';
        return `<div class="plat-strip sp-strip">${C.map(c => `<button type="button" class="plat-item" onclick="app.tvScOpen('${c.id}')"><span class="plat-ring">${c.thumb ? `<img src="${this.tvE(c.thumb)}" alt="" loading="lazy">` : `<span class="plat-ph">${this.tvE((c.name || '?').trim().charAt(0).toUpperCase())}</span>`}${c.pinned ? '<span class="pin-badge plat-pin">📌</span>' : ''}<span class="plat-badge">${L.filter(i => i.cat === c.id).length}</span></span><b>${this.tvE(c.name)}</b></button>`).join('')}</div>`;
      }
      tvScOpen(id) { this._scCat = id; this._scQ = ''; this._scYear = ''; const q = document.getElementById('tvScQ'); if (q) q.value = ''; this.navigate('tvsc'); }
      tvScSearch(v) { this._scQ = v; this.renderTvSc(); }
      tvScYear(v) { this._scYear = v || ''; this.renderTvSc(); }
      renderTvSc() {
        this.ensureTvData(); this.ensureAnimeData();
        const c = this.tvSportCats().find(x => x.id === this._scCat);
        if (!c) { if (this._ANK) this.navigate('tv'); return; }
        const ac = this.tvCats().concat(this.anAllCats(true));
        const pool = (this._tvI || []).filter(i => i.ak === 'sport' && i.cat === c.id).sort((x, y) => this._newFirst(x, y) || ((x.order || 0) - (y.order || 0)) || (this.tvTs(y) - this.tvTs(x)));
        const years = [...new Set(pool.map(i => this._itemYear(i)).filter(Boolean))].sort((a, b) => (parseInt(b) - parseInt(a)) || (b < a ? -1 : 1));
        if (this._scYear && !years.includes(this._scYear)) this._scYear = '';
        const q = (this._scQ || '').trim().toLowerCase();
        const L = pool.filter(i => (!this._scYear || this._itemYear(i) === this._scYear) && (!q || (i.title || '').toLowerCase().includes(q)));
        document.getElementById('tvScHead').innerHTML = `<span class="plat-ring">${c.thumb ? `<img src="${this.tvE(c.thumb)}" alt="">` : `<span class="plat-ph">${this.tvE((c.name || '?').trim().charAt(0).toUpperCase())}</span>`}</span><div><b style="font-size:1.1rem">${this.tvE(c.name)}</b><div style="font-size:.78rem;color:var(--text-dim)">${pool.length} টি আইটেম</div></div>`;
        document.getElementById('tvScFilter').innerHTML = `<div class="tvf-wrap" id="tvf-scy" style="flex:1 1 100%"><button type="button" class="tvf-btn" onclick="app.tvfToggle('scy',event)"><span>${this.tvE(this._scYear || 'সব বছর')}</span><i data-lucide="chevron-down"></i></button><div class="tvf-menu"><button type="button" class="${!this._scYear ? 'on' : ''}" onclick="app.tvScYear('')">সব বছর</button>${years.map(y => `<button type="button" class="${this._scYear === y ? 'on' : ''}" onclick="app.tvScYear('${y}')">${this.tvE(y)}</button>`).join('')}</div></div>`;
        document.getElementById('tvScGrid').innerHTML = L.map(i => this.tvCard(i, ac)).join('') || '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-dim)">কোনো কনটেন্ট নেই</div>';
        lucide.createIcons();
      }
      /* ===== Platform স্লাইডার + Platform পেজ ===== */
      tvPlatItems(id, kind) { return (this._tvI || []).filter(i => i.platform === id && (!kind || i.ak === kind)); }
      tvKindPlatStrip(kind) {
        const L = (this._tvI || []).filter(i => i.ak === kind && i.plLink).sort((x, y) => this._newFirst(x, y) || ((x.order || 0) - (y.order || 0))); if (!L.length) return '';
        return `<div class="plat-strip">${L.map(i => `<button type="button" class="plat-item" onclick="app.tvOpenItem('${i.id}')"><span class="plat-ring"><img src="${this.tvE(i.thumb)}" alt="" loading="lazy"></span><b>${this.tvE(i.title)}</b></button>`).join('')}</div>`;
      }
      tvPlatName() { const p = (this._tvP || []).find(x => x.id === this._tvPlatId); return p ? p.name : 'Platform'; }
      tvPlatStrip(show) {
        const el = document.getElementById('tvPlat'); if (!el) return;
        const P = this._tvP || [];
        const h = (show && P.length) ? `<div class="plat-strip">${P.map(p => `<button type="button" class="plat-item" onclick="app.tvPlatOpen('${p.id}')"><span class="plat-ring"><img src="${this.tvE(p.thumb)}" alt="" loading="lazy"><span class="plat-badge">${this.tvPlatItems(p.id).length}</span></span><b>${this.tvE(p.name)}</b></button>`).join('')}</div>` : '';
        if (el._sig !== h) { el._sig = h; el.innerHTML = h; }
      }
      tvPlatOpen(id, kind) {
        this._tvPlatKind = kind || ''; this._tvPlatId = id; this._tvPlatQ = ''; const q = document.getElementById('tvPlatQ'); if (q) q.value = '';
        this.navigate('tvplat');
      }
      tvPlatSearch(v) { this._tvPlatQ = v; this.renderTvPlat(); }
      renderTvPlat() {
        this.ensureTvData(); this.ensureAnimeData();
        const p = (this._tvP || []).find(x => x.id === this._tvPlatId);
        if (!p) { if (this._tvP) this.navigate('tv'); return; }
        document.getElementById('tvPlatHead').innerHTML = `<span class="plat-ring"><img src="${this.tvE(p.thumb)}" alt=""></span><div><b style="font-size:1.1rem">${this.tvE(p.name)}</b><div style="font-size:.78rem;color:var(--text-dim)">${this.tvPlatItems(p.id, this._tvPlatKind).length} টি আইটেম</div></div>`;
        const ac = this.tvCats().concat(this.anAllCats(true)), q = (this._tvPlatQ || '').trim().toLowerCase();
        const L = this.tvPlatItems(p.id, this._tvPlatKind).filter(i => !q || (i.title || '').toLowerCase().includes(q) || ((ac.find(c => c.id === i.cat) || {}).name || '').toLowerCase().includes(q)).sort((x, y) => this._newFirst(x, y) || ((x.order || 0) - (y.order || 0)));
        document.getElementById('tvPlatGrid').innerHTML = L.map(i => this.tvCard(i, ac)).join('') || '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-dim)">কোনো কনটেন্ট নেই</div>';
        lucide.createIcons();
      }
      tvMoreOpen(key) {
        this._tvMoreKey = key; this._tvMoreQ = ''; const q = document.getElementById('tvMoreQ'); if (q) q.value = '';
        if (key === 'sport') { this._spCat = ''; this._spYear = ''; } /* ডিফল্ট: All Competition + সব বছর */
        this.navigate('tvmore');
      }
      tvMoreSearch(v) { this._tvMoreQ = v; this.renderTvMore(); }
      /* Item এর Match Year: "2026" বা "2025/26" — Admin এ না দিলে যুক্ত করার সাল */
      _itemYear(i) {
        let y = String((i && i.year) == null ? '' : i.year).trim().replace(/\s+/g, '').replace(/[-–]/g, '/');
        if (/^\d{4}(\/\d{2,4})?$/.test(y)) return y;
        const t = this.tvTs(i); return t ? String(new Date(t).getFullYear()) : '';
      }
      _catImg(c) { if (!c) return ''; return c.thumb ? `<img class="cat-ph" src="${this.tvE(c.thumb)}" alt="">` : `<span class="cat-ph cat-ph-l">${this.tvE((c.name || '?').trim().charAt(0).toUpperCase())}</span>`; }
      tvfToggle(w, ev) {
        if (ev) ev.stopPropagation();
        if (!this._tvfOn) { this._tvfOn = 1; document.addEventListener('click', () => document.querySelectorAll('.tvf-wrap.open').forEach(e => e.classList.remove('open'))); }
        document.querySelectorAll('.tvf-wrap').forEach(e => { if (e.id !== 'tvf-' + w) e.classList.remove('open'); });
        const el = document.getElementById('tvf-' + w); if (el) el.classList.toggle('open');
      }
      tvfPick(w, v) { if (w === 'cat') this._spCat = v || ''; else this._spYear = v || ''; this.renderTvMore(); }
      renderTvMore() {
        const S = this.tvSecs().find(x => x.key === this._tvMoreKey); if (!S) { this.navigate('tv'); return; }
        const ac = this.tvCats().concat(this.anAllCats(true)), bar = document.getElementById('tvMoreFilter');
        const q = (this._tvMoreQ || '').trim().toLowerCase();
        const hit = i => !q || (i.title || '').toLowerCase().includes(q) || ((ac.find(c => c.id === i.cat) || {}).name || '').toLowerCase().includes(q);
        let L, title = S.label + ' — আরও', emptyMsg = 'কোনো কনটেন্ট নেই';
        if (S.key === 'sport') {
          const all = this.tvSecList(S);
          const sc = ((this._ANK || {}).sport || {}).C || [];
          const cats = this.tvSportCats().filter(c => all.some(i => i.cat === c.id));
          if (this._spCat && !cats.some(c => c.id === this._spCat)) this._spCat = '';
          /* Year তালিকা: শুধু সিলেক্ট করা Competition এর item এর Year (All হলে সব) */
          const pool = all.filter(i => !this._spCat || i.cat === this._spCat);
          const years = [...new Set(pool.map(i => this._itemYear(i)).filter(Boolean))].sort((a, b) => (parseInt(b) - parseInt(a)) || (b < a ? -1 : 1));
          if (this._spYear && !years.includes(this._spYear)) this._spYear = '';
          L = pool.filter(i => (!this._spYear || this._itemYear(i) === this._spYear) && hit(i));
          title = S.label; emptyMsg = 'এই Competition ও Year-এ কোনো কনটেন্ট নেই';
          const cName = this._spCat ? ((cats.find(c => c.id === this._spCat) || {}).name || 'All Competition') : 'All Competition';
          const yName = this._spYear || 'সব বছর';
          bar.innerHTML =
            `<div class="tvf-wrap" id="tvf-cat"><button type="button" class="tvf-btn" onclick="app.tvfToggle('cat',event)"><span>${this._spCat ? this._catImg(cats.find(c => c.id === this._spCat)) : ''}${this.tvE(cName)}</span><i data-lucide="chevron-down"></i></button><div class="tvf-menu"><button type="button" class="${!this._spCat ? 'on' : ''}" onclick="app.tvfPick('cat','')">All Competition</button>${cats.map(c => `<button type="button" class="${this._spCat === c.id ? 'on' : ''}" onclick="app.tvfPick('cat','${c.id}')">${c.pinned ? '📌 ' : ''}${this._catImg(c)}${this.tvE(c.name)}</button>`).join('')}</div></div>` +
            `<div class="tvf-wrap" id="tvf-year"><button type="button" class="tvf-btn" onclick="app.tvfToggle('year',event)"><span>${this.tvE(yName)}</span><i data-lucide="chevron-down"></i></button><div class="tvf-menu"><button type="button" class="${!this._spYear ? 'on' : ''}" onclick="app.tvfPick('year','')">সব বছর</button>${years.map(y => `<button type="button" class="${this._spYear === y ? 'on' : ''}" onclick="app.tvfPick('year','${y}')">${this.tvE(y)}</button>`).join('')}</div></div>`;
          bar.style.display = 'flex';
        } else {
          L = q ? this.tvSecList(S).filter(hit) : this.tvSecList(S).slice(S.n); /* সার্চ করলে পুরো সেকশনে খুঁজবে */
          bar.style.display = 'none'; bar.innerHTML = '';
        }
        const mc = document.getElementById('tvMoreCats');
        if (mc) {
          if (S.key === 'tv') {
            const IC = { live: 'tv', movie: 'film', sport: 'trophy', music: 'music', drama: 'video' };
            mc.innerHTML = this.tvCats().map(c => `<button class="tv-cat" onclick="app.tvOpenCat('${c.id}')"><i data-lucide="${IC[c.id] || 'play-circle'}"></i>${this.tvE(c.name)}</button>`).join('');
            mc.style.display = 'flex';
          } else { mc.innerHTML = ''; mc.style.display = 'none'; }
        }
        document.getElementById('tvMoreTitle').textContent = title;
        document.getElementById('tvMoreGrid').innerHTML = L.map(i => this.tvCard(i, ac)).join('') || `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-dim)">${emptyMsg}</div>`;
        lucide.createIcons();
      }
      tvSearch(v) { this._tvSq = v; this.renderTv(); }
      tvOpenCat(id, keepQ) {
        this._tvCatId = id; if (!keepQ) { this._tvCq = ''; const i = document.getElementById('tvCatQ'); if (i) i.value = ''; }
        this.renderTvCat(); if (this.currentView !== 'tvcat') this.navigate('tvcat');
      }
      renderTvCat() {
        const cats = this.tvCats(), c = cats.find(x => x.id === this._tvCatId); if (!c) return;
        document.getElementById('tvCatTitle').textContent = c.name;
        const q = (this._tvCq || '').trim().toLowerCase();
        this.tvNewFill('tvCatNew', (this._tvI || []).filter(i => i.cat === c.id), cats, !q);
        const L = (this._tvI || []).filter(i => i.cat === c.id && (!q || (i.title || '').toLowerCase().includes(q))).sort((x, y) => this._newFirst(x, y));
        document.getElementById('tvCatGrid').innerHTML = L.map(i => this.tvCard(i, cats)).join('') || '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-dim)">কোনো কনটেন্ট নেই</div>';
        lucide.createIcons();
      }
      tvCatSearch(v) { this._tvCq = v; this.renderTvCat(); }
      tvBackWord() { return this._tvFrom === 'history' ? 'Back to Watching History' : this._tvFrom === 'tvplat' ? ('Back to ' + this.tvPlatName()) : this._tvFrom === 'tvsc' ? ('Back to ' + ((this.tvSportCats().find(c => c.id === this._scCat) || {}).name || 'Sports')) : (this._tvFrom === 'anime' ? ('Back to ' + this.anLabel()) : 'Back to Entertainment'); }
      tvGoBack() { if (this._tvFrom === 'history') { this.navigate('history'); return; } if (this._tvFrom === 'tvmore') { this.navigate('tvmore'); return; } if (this._tvFrom === 'tvplat') { this.navigate('tvplat'); return; } if (this._tvFrom === 'tvsc') { this.navigate('tvsc'); return; } if (this._tvFrom === 'anime') { this.navigate('anime'); return; } if (this._tvFrom === 'tvcat' && this._tvCatId) this.tvOpenCat(this._tvCatId, true); else this.navigate('tv'); }
      /* প্রতিবার কোনো Entertainment item/card click হলে Watch Count একবার বাড়ে */
      tvRecord(id) {
        if (!id) return;
        setDoc(doc(db, 'tv_reads', id), { bookId: id, count: increment(1) }, { merge: true }).catch(e => console.warn('tv read', e));
      }
      /* সোর্স = { lang, q, url } — পুরোনো আইটেমের শুধু url থাকলে Original/Auto ধরা হয় */
      tvSources(o) { return (o.sources && o.sources.length) ? o.sources : (o.url ? [{ lang: 'Original', q: 'Auto', url: o.url }] : []); }
      tvQNum(q) { return q === '4K' ? 2160 : (parseInt(q) || 0); }
      tvQs() { return [...new Set(this._tvS.filter(s => (s.lang || 'Original') === this._tvLang).map(s => s.q || 'Auto'))].sort((a, b) => this.tvQNum(b) - this.tvQNum(a)); }
      tvStart(entry, epId) {
        this._tvS = this.tvSources(entry); this._tvEpId = epId || 'main'; this.tvHistAdd(this._tvEpId);
        const langs = [...new Set(this._tvS.map(s => s.lang || 'Original'))];
        if (!langs.includes(this._tvLang)) this._tvLang = langs[0];
        const qs = this.tvQs();
        if (!qs.includes(this._tvQ)) this._tvQ = qs.find(q => this.tvQNum(q) === 720) || qs.find(q => this.tvQNum(q) === 480) || qs[0];
        this.tvApply(0);
      }
      tvApply(t) {
        const s = this._tvS.find(x => (x.lang || 'Original') === this._tvLang && (x.q || 'Auto') === this._tvQ) || this._tvS[0];
        this.tvPlay(s ? s.url : '', t); this.tvRenderOpts(); this.tvDlRender();
      }
      /* ===== একই ভিডিওর ভেতরে একাধিক ভাষার অডিও ট্র্যাক ===== */
      tvAudioName(t) {
        const M = { bn: 'বাংলা', ben: 'বাংলা', hi: 'Hindi', hin: 'Hindi', en: 'English', eng: 'English', ta: 'Tamil', te: 'Telugu', ur: 'Urdu', ar: 'Arabic', ml: 'Malayalam', kn: 'Kannada', ja: 'Japanese', ko: 'Korean' };
        const code = String(t.lang || t.language || '').toLowerCase().split('-')[0];
        return t.name || t.label || M[code] || t.lang || t.language || 'Audio';
      }
      tvAudioList() {
        const v = document.querySelector('#tvPlayer video');
        try {
          if (this._hls && this._hls.audioTracks && this._hls.audioTracks.length > 1)
            return this._hls.audioTracks.map((t, i) => ({ name: this.tvAudioName(t), on: i === this._hls.audioTrack }));
          if (v && v.audioTracks && v.audioTracks.length > 1)
            return Array.from(v.audioTracks).map(t => ({ name: this.tvAudioName(t), on: !!t.enabled }));
        } catch (e) { }
        return [];
      }
      tvSetAudio(i) {
        const v = document.querySelector('#tvPlayer video'), L = this.tvAudioList(); if (!L[i]) return;
        this._tvAudioPref = L[i].name;
        try {
          if (this._hls && this._hls.audioTracks && this._hls.audioTracks.length > 1) this._hls.audioTrack = i;
          else if (v && v.audioTracks) Array.from(v.audioTracks).forEach((t, k) => { t.enabled = (k === i); });
        } catch (e) { }
        const menu = document.getElementById('tvAudioMenu'); if (menu) menu.classList.remove('open');
        const ab = document.querySelector('.tv-audio-btn'); if (ab) ab.setAttribute('aria-expanded', 'false');
        this.tvRenderOpts();
      }
      tvAudioSync() {
        /* আগে বেছে নেওয়া ভাষা থাকলে (কোয়ালিটি/সোর্স বদলের পর) সেটিই আবার চালু করি */
        const L = this.tvAudioList();
        if (this._tvAudioPref && L.length > 1) { const k = L.findIndex(a => a.name === this._tvAudioPref); if (k >= 0 && !L[k].on) { this.tvSetAudio(k); return; } }
        this.tvRenderOpts();
      }
      tvBindAudio(v) {
        v.addEventListener('loadedmetadata', () => this.tvAudioSync());
        v.addEventListener('click', () => { const w = document.getElementById('tvWrap'); if (!w || w._gpxSkipClick) { if (w) w._gpxSkipClick = false; return; } w.classList.toggle('tv-controls-hidden'); });
        if (v.audioTracks && v.audioTracks.addEventListener) ['addtrack', 'removetrack', 'change'].forEach(e => v.audioTracks.addEventListener(e, () => this.tvRenderOpts()));
      }
      tvTime() { const v = document.querySelector('#tvPlayer video'); return v ? v.currentTime : 0; }
      tvSetLang(i) { const t = this.tvTime(); this._tvLang = this._tvLangs[i]; const qs = this.tvQs(); if (!qs.includes(this._tvQ)) this._tvQ = qs.find(q => this.tvQNum(q) === 720) || qs[0]; this.tvApply(t); }
      tvSetQ(i) { const t = this.tvTime(); this._tvQ = this._tvQsList[i]; this.tvApply(t); }
      tvRenderOpts() {
        const el = document.getElementById('tvOpts'); if (!el) return;
        this._tvLangs = [...new Set(this._tvS.map(s => s.lang || 'Original'))]; this._tvQsList = this.tvQs(); const au = this.tvAudioList();
        const chip = (fn, i, label, on) => `<button class="tv-chip ${on ? 'active' : ''}" onclick="app.${fn}(${i})">${this.tvE(label)}</button>`;
        el.innerHTML = (this._tvLangs.length > 1 ? `<div class="tv-opt"><b>ভাষা</b>${this._tvLangs.map((l, i) => chip('tvSetLang', i, l, l === this._tvLang)).join('')}</div>` : '')
          + (this._tvQsList.length > 1 ? `<div class="tv-opt"><b>Quality</b>${this._tvQsList.map((q, i) => chip('tvSetQ', i, q, q === this._tvQ)).join('')}</div>` : '')
          + `<div class="tv-opt tv-audio-opt"><b>অডিও</b>${au.length > 1 ? au.map((a, i) => chip('tvSetAudio', i, a.name, a.on)).join('') : '<button type="button" class="tv-chip active" disabled>Audio</button>'}</div>`;
      }
      tvSeasonsOf(id) { return (this._tvSe || []).filter(s => s.itemId === id); }
      /* গ্রিড থেকে ক্লিক: Season থাকলে Season Page, না থাকলে সরাসরি ভিডিও পেজ */
      tvOpenItem(id) {
        const it = (this._tvI || []).find(x => x.id === id); if (!it) return;
        this.tvRecord(id);
        this._tvCur = id; this._tvSeason = null; this._tvStarted = false; this._tvFrom = this.currentView === 'tvcat' ? 'tvcat' : (this.currentView === 'anime' ? 'anime' : (this.currentView === 'tvmore' ? 'tvmore' : (this.currentView === 'tvplat' ? 'tvplat' : (this.currentView === 'tvsc' ? 'tvsc' : 'tv'))));
        this.tvOpen(id);
      }
      tvEpNo(e, i) {
        const n = Number(e.number != null ? e.number : e.ep); if (n > 0) return n;
        const m = String(e.title || '').match(/(?:ep(?:isode)?\.?|e|পর্ব)\s*0*(\d+)/i) || String(e.title || '').match(/(\d+)/);
        return m ? Number(m[1]) : i + 1;
      }
      tvSeLabel(s, i) { const m = String(s.title || '').match(/(\d+)/); return m ? 'S' + String(m[1]).padStart(2, '0') : (s.title || 'S' + String(i + 1).padStart(2, '0')); }
      tvOpenSeason(sid) { this._tvSeason = sid; this._tvStarted = false; this.tvOpen(this._tvCur); }
      tvSortToggle() { this._tvSortNew = this._tvSortNew === false; this.tvOpen(this._tvCur, true); }
      tvVoteOptions() {
        return [
          { id: 'must-watch', emoji: '🔥', title: 'Must Watch', sub: 'অবশ্যই দেখুন' },
          { id: 'good', emoji: '👍', title: 'Good', sub: 'ভালো লেগেছে' },
          { id: 'average', emoji: '😐', title: 'Average', sub: 'মোটামুটি' },
          { id: 'bad', emoji: '👎', title: 'Bad', sub: 'ভালো লাগেনি' },
          { id: 'very-bad', emoji: '😞', title: 'Very Bad', sub: 'একদম ভালো লাগেনি' }
        ];
      }
      tvVoteOpen(itemId) {
        if (this._tvVoteUnsub) { try { this._tvVoteUnsub(); } catch (e) {} this._tvVoteUnsub = null; }
        this._tvVoteItem = itemId; this._tvVoteRows = []; this._tvVoteMine = ''; this.tvVoteRender();
        try {
          const ref = collection(db, 'itemVotes', itemId, 'users');
          this._tvVoteUnsub = onSnapshot(ref, snap => {
            this._tvVoteRows = snap.docs.map(d => ({ id: d.id, ...(d.data() || {}) }));
            this._tvVoteMine = this.currentUser ? ((this._tvVoteRows.find(x => x.id === this.currentUser.uid) || {}).option || '') : '';
            this.tvVoteRender();
          }, err => { console.warn('item vote listener', err); this.tvVoteRender('ভোটের ফলাফল লোড করা যায়নি'); });
        } catch (e) { console.warn('item vote setup', e); this.tvVoteRender('ভোটের ফলাফল লোড করা যায়নি'); }
      }
      tvVoteRender(note) {
        const box = document.getElementById('tvVoteWrap'); if (!box) return;
        const opts = this.tvVoteOptions(), rows = this._tvVoteRows || [], counts = {}; opts.forEach(o => counts[o.id] = 0);
        rows.forEach(r => { if (counts[r.option] != null) counts[r.option]++; });
        const total = opts.reduce((n, o) => n + counts[o.id], 0), rec = total ? Math.round(((counts['must-watch'] + counts.good) / total) * 100) : 0;
        box.style.display = 'block';
        box.innerHTML = `<div class="item-vote-head"><div><div class="item-vote-kicker">Community Verdict</div><div class="item-vote-title">এই কনটেন্টটি কেমন?</div><div class="item-vote-sub">একটি option টিক দিয়ে আপনার মতামত জানান।</div></div><div class="item-vote-score"><b>${rec}%</b><span>Highly<br>Recommended</span></div></div><div class="item-vote-bar"><i style="width:${rec}%"></i></div><div class="item-vote-summary">${rec}% দর্শক এটি দেখার পরামর্শ দিয়েছেন</div><div class="item-vote-total">${total.toLocaleString('en-US')} votes</div><div class="item-vote-options">${opts.map(o => `<button type="button" class="item-vote-option ${this._tvVoteMine === o.id ? 'selected' : ''}" onclick="app.tvVotePick('${o.id}')"><span class="item-vote-check">✓</span><span class="item-vote-emoji">${o.emoji}</span><span class="item-vote-label"><b>${o.title}</b><small>${o.sub}</small></span><span class="item-vote-count">${counts[o.id].toLocaleString('en-US')}</span></button>`).join('')}</div><div class="item-vote-note">${note || (this._tvVoteMine ? 'আপনার vote পরিবর্তন করতে অন্য option নির্বাচন করুন।' : 'ভোট দিতে লগইন করুন।')}</div>`;
      }
      async tvVotePick(option) {
        if (!this.currentUser) { this.toast('ভোট দিতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        if (!this._tvVoteItem || !this.tvVoteOptions().some(o => o.id === option)) return;
        try {
          await setDoc(doc(db, 'itemVotes', this._tvVoteItem, 'users', this.currentUser.uid), { uid: this.currentUser.uid, option, updatedAt: serverTimestamp() });
          this._tvVoteMine = option; this.tvVoteRender();
          this.toast('আপনার vote সংরক্ষণ হয়েছে', 'success');
        } catch (e) { console.error('item vote save', e); this.toast('ভোট সংরক্ষণ করা যায়নি — Firestore rules যাচাই করুন', 'danger'); }
      }
      tvOpen(id, keep) {
        const it = (this._tvI || []).find(x => x.id === id); if (!it) return;
        this._tvCur = id; this.tvVoteOpen(id);
        const newest = this._tvSortNew !== false;
        const ss = this.tvSeasonsOf(id), hasMv = !!(it.an && this.tvSources(it).length);
        const mv = this._tvSeason === '__movie' && hasMv; let se = null;
        if (ss.length && !mv) { se = ss.find(s => s.id === this._tvSeason) || ss[ss.length - 1]; this._tvSeason = se.id; }
        else if (!ss.length) this._tvSeason = null;
        const raw = mv ? [] : (this._tvE || []).filter(e => e.itemId === id && (!se || e.seasonId === se.id));
        const rows = raw.map((e, i) => ({ e, i, no: this.tvEpNo(e, i) })).sort((a, b) => ((newest ? b.no - a.no : a.no - b.no) || (newest ? b.i - a.i : a.i - b.i)));
        const eps = rows.map(r => r.e);
        document.getElementById('tvTitle').textContent = it.title + (se ? ' — ' + se.title : ''); document.getElementById('tvDesc').textContent = it.desc || ''; this.tvCastRender(it);
        document.getElementById('tvBackTxt').textContent = this.tvBackWord();
        if (!keep || !this._tvStarted) {
          this._tvStarted = true;
          if (eps.length) this.tvStart(eps[0], eps[0].id);
          else if (ss.length && !mv) { this._tvS = []; this._tvEpId = null; this.tvPlay('', 0); this.tvRenderOpts(); }
          else this.tvStart(it, 'main');
        }
        this._tvEpsCur = eps;
        this.tvInfoRender(it);
        this.tvHeroRender(it, se, ss, rows, mv);
        const wrap = document.getElementById('tvEpWrap'), box = document.getElementById('tvEps');
        wrap.style.display = (eps.length || ss.length) ? 'block' : 'none';
        let chips = '';
        if (ss.length) {
          const list = ss.map((s, i) => `<button type="button" class="tv-epp-chip ${se && s.id === se.id ? 'active' : ''}" onclick="app.tvOpenSeason('${s.id}')">${this.tvE(this.tvSeLabel(s, i))}</button>`);
          if (newest) list.reverse();
          if (hasMv) list.push(`<button type="button" class="tv-epp-chip ${mv ? 'active' : ''}" onclick="app.tvOpenSeason('__movie')">Movie</button>`);
          chips = `<div class="tv-epp-se">${list.join('')}</div>`;
        }
        const mkey = id + '|' + (se ? se.id : '') + '|' + (mv ? 'm' : ''); if (this._tvEpMoreKey !== mkey) { this._tvEpMoreKey = mkey; this._tvEpMore = false; }
        const LIM = 12, showAll = !!this._tvEpMore, vis = (showAll || rows.length <= LIM) ? rows : rows.slice(0, LIM);
        const moreBtn = rows.length > LIM ? `<button type="button" class="tv-epp-more" onclick="app.tvEpMore()">${showAll ? '▲ Show less' : `▼ More Episodes (${rows.length - LIM})`}</button>` : '';
        const tiles = vis.map(r => `<button type="button" class="tv-epp-ep ${r.e.id === this._tvEpId ? 'active' : ''}" title="${this.tvE(r.e.title)}" onclick="app.tvPlayEp('${r.e.id}')">${this._isEpisodeNew(r.e) ? '<span class="tv-epp-new">NEW</span>' : ''}EP ${r.no}</button>`).join('');
        box.innerHTML = `<div class="tv-epp"><div class="tv-epp-head"><div><span class="tv-epp-kick">Resources</span><h3>${mv ? 'Movie' : eps.length + (eps.length === 1 ? ' Episode' : ' Episodes')}</h3></div>${eps.length > 1 ? `<button type="button" class="tv-epp-sort" onclick="app.tvSortToggle()">${newest ? '▲ Newest first' : '▼ Oldest first'}</button>` : ''}</div>${chips}${eps.length ? `<div class="tv-epp-grid">${tiles}</div>${moreBtn}<div class="tv-ep-tools"><button type="button" class="btn btn-primary btn-sm tv-ep-dl-all" onclick="app.tvDlPopOpen()"><i data-lucide="download-cloud"></i> Select All / Multi Download</button></div>` : ''}</div>`;
        this.tvDlRender();
        if (this.currentView !== 'tvitem') this.navigate('tvitem'); lucide.createIcons();
      }
      /* ---- Cast: item.cast (Firestore) অথবা auto TMDB ---- */
      tvCastNorm(c) {
        if (typeof c === 'string') { try { c = JSON.parse(c); } catch (e) { c = c.split(/\n|,/).map(x => x.trim()).filter(Boolean).map(n => ({ name: n })); } }
        if (c && !Array.isArray(c) && typeof c === 'object') c = Object.values(c);
        return (Array.isArray(c) ? c : []).map(x => typeof x === 'string' ? { name: x } : { name: x.name || x.actor || x.title || '', role: x.role || x.character || x.as || '', photo: x.photo || x.image || x.img || x.photoUrl || x.profile || '' }).filter(x => x.name);
      }
      tvCleanTitle(it) {
        const raw = String(it.title || ''), ym = raw.match(/\b(19|20)\d{2}\b/);
        const q = raw.replace(/[\[\(][^\]\)]*[\]\)]/g, ' ').replace(/\b(19|20)\d{2}\b/g, ' ').replace(/\b(480p|720p|1080p|2160p|4k|hevc|x26[45]|hdtc|hdrip|web-?dl|webrip|blu-?ray|hindi|tamil|telugu|dubbed|season\s*\d+|s\d+)\b/gi, ' ').replace(/\s+/g, ' ').trim();
        return { q, year: ym ? ym[0] : '' };
      }
      tvCastRender(it) {
        const id = it.id, own = this.tvCastNorm(it.cast || it.casts || it.casting);
        this._tvMeta = this._tvMeta || {}; this._tvBusy = this._tvBusy || {};
        const box = document.getElementById('tvCast');
        if (own.length) this.tvCastDraw(own);
        else if (this._tvMeta[id] && this._tvMeta[id].cast.length) this.tvCastDraw(this._tvMeta[id].cast);
        else if (box) { box.style.display = 'none'; box.innerHTML = ''; }
        if (this._tvMeta[id] || this._tvBusy[id]) return;
        const key = window.NEXA_TMDB_KEY, okey = window.NEXA_OMDB_KEY;
        if (!key && !okey) return;
        this._tvBusy[id] = 1;
        const needCast = !own.length;
        (async () => {
          let d = null; try { d = key ? await this.tvCastFetch(it, key) : null; } catch (e) { }
          const meta = d || { cast: [], genres: [], date: '', rating: 0, votes: 0, overview: '' };
          if (okey) { try { const o = await this.tvOmdbFetch(it, meta, okey); if (o) { meta.omdb = o; if (!meta.imdbId && o.imdbID) meta.imdbId = o.imdbID; if (!meta.cast.length && o.Actors && o.Actors !== 'N/A') meta.cast = o.Actors.split(',').map(n => ({ name: n.trim(), role: '', photo: '' })); } } catch (e) { } }
          this._tvMeta[id] = meta; delete this._tvBusy[id];
          if (this._tvCur !== id) return;
          if (needCast) this.tvCastDraw(meta.cast);
          this.tvInfoRender(it);
        })();
      }
      /* IMDb তথ্য: OMDb (IMDb ডেটা) — window.NEXA_OMDB_KEY লাগবে */
      async tvOmdbFetch(it, meta, okey) {
        const own = String(it.imdbId || it.imdb || '').match(/tt\d{6,}/), id = own ? own[0] : (meta && meta.imdbId) || '';
        let u = 'https://www.omdbapi.com/?plot=full&apikey=' + encodeURIComponent(okey);
        if (id) u += '&i=' + id; else { const c = this.tvCleanTitle(it); if (!c.q) return null; u += '&t=' + encodeURIComponent(c.q) + (c.year ? '&y=' + c.year : ''); }
        const r = await fetch(u).then(x => x.ok ? x.json() : null);
        return r && r.Response === 'True' ? r : null;
      }
      async tvCastFetch(it, key) {
        const c = this.tvCleanTitle(it), q = c.q, year = c.year;
        if (!q || !key) return null;
        const bearer = String(key).indexOf('eyJ') === 0;
        const api = (p, o) => fetch('https://api.themoviedb.org/3' + p + (o || '') + (bearer ? '' : (p.includes('?') ? '&' : '?') + 'api_key=' + encodeURIComponent(key)), bearer ? { headers: { Authorization: 'Bearer ' + key, accept: 'application/json' } } : undefined).then(r => r.ok ? r.json() : Promise.reject());
        const isTv = !!(this.tvSeasonsOf && this.tvSeasonsOf(it.id).length);
        for (const kind of (isTv ? ['tv', 'movie'] : ['movie', 'tv'])) {
          const r = await api('/search/' + kind + '?query=' + encodeURIComponent(q), year ? '&' + (kind === 'tv' ? 'first_air_date_year=' : 'year=') + year : '');
          const hit = (r.results || [])[0]; if (!hit) continue;
          const d = await api('/' + kind + '/' + hit.id + '?append_to_response=credits,external_ids,' + (kind === 'tv' ? 'content_ratings' : 'release_dates'));
          const crew = (d.credits && d.credits.crew) || [], names = a => [...new Set(a.map(p => p.name).filter(Boolean))].slice(0, 6);
          let cert = '';
          if (kind === 'movie') { const rs = (d.release_dates && d.release_dates.results) || [], pk = rs.find(x => x.iso_3166_1 === 'US') || rs.find(x => (x.release_dates || []).some(y => y.certification)); cert = pk ? ((pk.release_dates || []).find(y => y.certification) || {}).certification || '' : ''; }
          else { const rs = (d.content_ratings && d.content_ratings.results) || [], pk = rs.find(x => x.iso_3166_1 === 'US') || rs[0]; cert = pk ? pk.rating || '' : ''; }
          return {
            kind,
            cast: ((d.credits && d.credits.cast) || []).slice(0, 15).map(p => ({ name: p.name, role: p.character || '', photo: p.profile_path ? 'https://image.tmdb.org/t/p/w185' + p.profile_path : '' })),
            genres: (d.genres || []).map(g => g.name),
            date: d.release_date || d.first_air_date || '',
            rating: Number(d.vote_average) || 0, votes: Number(d.vote_count) || 0, overview: d.overview || '',
            imdbId: (d.external_ids && d.external_ids.imdb_id) || d.imdb_id || '',
            runtime: d.runtime || (d.episode_run_time || [])[0] || 0,
            status: d.status || '', cert,
            langs: (d.spoken_languages || []).map(l => l.english_name || l.name).filter(Boolean),
            countries: (d.production_countries || []).map(x => x.name).filter(Boolean),
            companies: (d.production_companies || []).map(x => x.name).slice(0, 4),
            directors: kind === 'tv' ? [] : names(crew.filter(p => p.job === 'Director')),
            creators: kind === 'tv' ? names(d.created_by || []) : [],
            writers: names(crew.filter(p => ['Writer', 'Screenplay', 'Story', 'Novel'].includes(p.job))),
            seasons: d.number_of_seasons || 0, epCount: d.number_of_episodes || 0,
            budget: d.budget || 0, revenue: d.revenue || 0
          };
        }
        return null;
      }
      tvInfoDate(v) {
        if (!v) return '';
        const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
        const d = m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date(v);
        return isNaN(d) ? String(v) : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      }
      tvInfoRender(it) {
        const box = document.getElementById('tvInfo'); if (!box || !it) return;
        const meta = (this._tvMeta && this._tvMeta[it.id]) || {}, ov = meta.omdb || {};
        const cl = v => { v = v == null ? '' : String(v).trim(); return v && v !== 'N/A' ? v : ''; };
        const srcs = [...this.tvSources(it), ...(this._tvEpsCur || []).flatMap(e => this.tvSources(e))];
        const arr = v => Array.isArray(v) ? v : String(v || '').split(/[,/|]/).map(x => x.trim()).filter(Boolean);
        const genre = arr(it.genre || it.genres).length ? arr(it.genre || it.genres) : (cl(ov.Genre) ? arr(ov.Genre) : (meta.genres || []));
        let langs = [...new Set(srcs.map(x => String(x.lang || '').trim()).filter(x => x && x !== 'Original'))];
        if (!langs.length && (it.language || it.lang)) langs = arr(it.language || it.lang);
        const qs = [...new Set(srcs.map(x => String(x.q || '').trim()).filter(x => x && x !== 'Auto'))].sort((a, b) => this.tvQNum(b) - this.tvQNum(a));
        const date = cl(ov.Released) ? cl(ov.Released) : this.tvInfoDate(it.released || it.releaseDate || it.releasedAt || meta.date);
        const rating = Number(it.rating || meta.rating) > 0 ? Number(it.rating || meta.rating).toFixed(1) : '';
        const row = (ic, k, v) => v ? `<div>${ic} <b>${k}:</b> ${this.tvE(v)}</div>` : '';
        const money = n => n > 0 ? '$' + Number(n).toLocaleString('en-US') : '';
        const iidM = String(it.imdbId || it.imdb || '').match(/tt\d{6,}/), iid = iidM ? iidM[0] : (meta.imdbId || '');
        const rt = ((ov.Ratings || []).find(x => /rotten/i.test(x.Source)) || {}).Value || '';
        const ir = cl(ov.imdbRating), iv = cl(ov.imdbVotes);
        const join = a => (a || []).join(', ');
        const h = (ir ? row('⭐', 'IMDb Rating', ir + ' / 10' + (iv ? ' (' + iv + ' votes)' : '')) : (rating ? row('⭐', 'TMDB Rating', rating + ' / 10' + (meta.votes ? ' (' + meta.votes.toLocaleString('en-US') + ' votes)' : '')) : ''))
          + row('🏷️', 'Rated', cl(ov.Rated) || meta.cert || '')
          + row('⏱️', 'Runtime', cl(ov.Runtime) || (meta.runtime ? meta.runtime + ' min' : ''))
          + row('🎬', 'Genre', genre.join(', '))
          + row('📅', 'Released', date)
          + (cl(ov.Type) === 'series' ? row('🗓️', 'Years', cl(ov.Year)) : '')
          + row('📚', 'Seasons', cl(ov.totalSeasons) || (meta.seasons ? String(meta.seasons) : ''))
          + row('🎞️', 'Total Episodes', meta.epCount ? String(meta.epCount) : '')
          + row('🎥', 'Director', cl(ov.Director) || join(meta.directors))
          + row('🎬', 'Creator', join(meta.creators))
          + row('✍️', 'Writer', cl(ov.Writer) || join(meta.writers))
          + row('🌐', 'IMDb Language', cl(ov.Language) || join(meta.langs))
          + row('🗣️', 'Audio', langs.length > 1 ? 'Multi [' + langs.join('–') + ']' : langs[0])
          + row('🌍', 'Country', cl(ov.Country) || join(meta.countries))
          + row('🏆', 'Awards', cl(ov.Awards))
          + row('📊', 'Metascore', cl(ov.Metascore))
          + row('🍅', 'Rotten Tomatoes', rt)
          + row('💰', 'Box Office', cl(ov.BoxOffice) || money(meta.revenue))
          + row('💵', 'Budget', money(meta.budget))
          + row('🏢', 'Production', cl(ov.Production) || join(meta.companies))
          + row('📌', 'Status', meta.status)
          + row('📺', 'Quality', it.quality || it.printQuality || '')
          + row('🖥️', 'Resolution', qs.join(' | '));
        box.innerHTML = h; box.style.display = h ? 'block' : 'none';
        const sb = document.getElementById('tvStory'); if (!sb) return;
        const st = String(it.storyline || it.overview || cl(ov.Plot) || meta.overview || '').trim();
        if (!st) { sb.style.display = 'none'; sb.innerHTML = ''; return; }
        sb.innerHTML = '<div class="tv-story-title">📖 Storyline</div><div class="tv-story-txt clamp">' + this.tvE(st) + '</div>' + (st.length > 180 ? '<button type="button" class="tv-story-more" onclick="var t=this.previousElementSibling;var c=t.classList.toggle(\'clamp\');this.textContent=c?\'আরও পড়ুন\':\'কম দেখান\'">আরও পড়ুন</button>' : '');
        sb.style.display = 'block';
      }
      tvCastDraw(list) {
        const box = document.getElementById('tvCast'); if (!box) return;
        if (!list || !list.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
        box.innerHTML = '<div class="tv-cast-title">🎭 Cast</div><div class="tv-cast-row">' + list.map(p => {
          const ini = this.tvE((p.name || '?').trim().charAt(0).toUpperCase());
          const ph = p.photo ? `<img src="${this.tvE(p.photo)}" alt="" loading="lazy" onerror="this.parentNode.textContent='${ini}'">` : ini;
          return `<div class="tv-cast-card"><div class="tv-cast-ph">${ph}</div><div class="tv-cast-name" title="${this.tvE(p.name)}">${this.tvE(p.name)}</div><div class="tv-cast-role" title="${this.tvE(p.role)}">${this.tvE(p.role)}</div></div>`;
        }).join('') + '</div>';
        box.style.display = 'block';
      }
      tvDlPopOpen() {
        const eps = this._tvEpsCur || []; if (!eps.length) return;
        this.tvDlPopClose();
        const it = (this._tvI || []).find(x => x.id === this._tvCur);
        const w = document.createElement('div'); w.id = 'tvDlPop'; w.className = 'tv-dlpop';
        w.innerHTML = `<div class="tv-dlpop-head"><b>${this.tvE((it && it.title) || 'Episodes')}</b><button type="button" class="tv-dlpop-x" onclick="app.tvDlPopClose()" aria-label="বন্ধ"><i data-lucide="x"></i></button></div><label class="tv-dlpop-all"><input type="checkbox" class="tv-ep-select" id="tvDlPopAll" onchange="app.tvDlPopAll(this.checked)"> Select All <small id="tvDlPopCnt">0/${eps.length}</small></label><div class="tv-dlpop-list">${eps.map(e => `<label class="tv-dlpop-row"><input type="checkbox" class="tv-ep-select tv-dlpop-check" value="${e.id}" onchange="app.tvDlPopCount()"><span>${this.tvE(e.title)}</span></label>`).join('')}</div><div class="tv-dlpop-foot"><button type="button" class="btn btn-primary" onclick="app.tvDlPopGo()"><i data-lucide="download-cloud"></i> Download Selected</button></div>`;
        document.body.appendChild(w); document.body.style.overflow = 'hidden'; lucide.createIcons();
      }
      tvDlPopClose() { const w = document.getElementById('tvDlPop'); if (w) w.remove(); document.body.style.overflow = ''; }
      tvDlPopAll(on) { document.querySelectorAll('#tvDlPop .tv-dlpop-check').forEach(x => x.checked = !!on); this.tvDlPopCount(); }
      tvDlPopCount() { const c = [...document.querySelectorAll('#tvDlPop .tv-dlpop-check')], n = c.filter(x => x.checked).length, a = document.getElementById('tvDlPopAll'), t = document.getElementById('tvDlPopCnt'); if (a) a.checked = n === c.length && n > 0; if (t) t.textContent = n + '/' + c.length; }
      tvDlPopGo() { const ids = [...document.querySelectorAll('#tvDlPop .tv-dlpop-check:checked')].map(x => x.value); if (!ids.length) { this.toast('আগে Episode নির্বাচন করুন', 'info'); return; } ids.forEach(id => this.tvDownload('ep', id)); this.tvDlPopClose(); this.toast(ids.length + 'টি Episode Download queue-তে যোগ হয়েছে', 'success'); }
      tvToggleAllEpisodes(on) { document.querySelectorAll('#tvEps .tv-ep-check').forEach(x => x.checked = !!on); }
      tvDownloadSelected() { const ids = [...document.querySelectorAll('#tvEps .tv-ep-check:checked')].map(x => x.value); if (!ids.length) { this.toast('আগে Episode নির্বাচন করুন', 'info'); return; } ids.forEach(id => this.tvDownload('ep', id)); this.toast(ids.length + 'টি Episode Download queue-তে যোগ হয়েছে', 'success'); }
      tvPlayEp(id) { const e = (this._tvE || []).find(x => x.id === id); if (!e) return; this.tvStart(e, id); this.tvOpen(this._tvCur, true); }
      tvPlay(u, t) {
        u = (u || '').trim(); const box = document.getElementById('tvPlayer');
        if (u) this.tvPopupClose(); /* Main player চালু হলে Popup বন্ধ */
        this._tvCurrentUrl = u;
        if (this._hls) { try { this._hls.destroy(); } catch (e) { } this._hls = null; }
        const resume = v => { if (t > 1) v.addEventListener('loadedmetadata', () => { try { v.currentTime = t; } catch (e) { } }, { once: true }); };
        const y = u.match(/(?:youtu\.be\/|v=|embed\/|shorts\/|live\/)([\w-]{11})/);
        if (y) { box.innerHTML = `<iframe src="https://www.youtube.com/embed/${y[1]}?rel=0&autoplay=1&enablejsapi=1" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>`; box.firstChild.addEventListener('click', () => box.parentElement.classList.toggle('tv-controls-hidden')); this.tvYtListen(box.firstChild); return; }
        const fail = () => { if (!box.querySelector('.tv-player-error')) box.insertAdjacentHTML('beforeend', '<div class="tv-player-error"><strong>দুঃখিত, ভিডিওটি এখন চালানো যাচ্ছে না</strong><small>লিংকটি পরিবর্তিত, অকার্যকর অথবা এই মুহূর্তে সার্ভার থেকে সাড়া পাওয়া যাচ্ছে না।</small></div>'); };
        if (!u) { box.innerHTML = ''; fail(); return; }
        if (/\.m3u8(\?|$)/i.test(u)) {
          box.innerHTML = '<video controls controlsList="nofullscreen" playsinline webkit-playsinline autoplay></video>'; const v = box.firstChild; resume(v); this.tvCustomUI(box, v);
          v.addEventListener('error', fail); if (v.canPlayType('application/vnd.apple.mpegurl')) { this.tvBindAudio(v); v.src = u; return; }
          const go = () => { if (window.Hls && Hls.isSupported()) { this._hls = new Hls(); this._hls.loadSource(u); this._hls.attachMedia(v); ['hlsManifestParsed', 'hlsAudioTracksUpdated', 'hlsAudioTrackSwitched'].forEach(ev => this._hls.on(ev, () => this.tvAudioSync())); } else this.toast('এই ব্রাউজারে স্ট্রিম চলবে না', 'danger'); };
          if (window.Hls) go(); else { const sc = document.createElement('script'); sc.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.8/dist/hls.min.js'; sc.onload = go; sc.onerror = () => this.toast('প্লেয়ার লোড হয়নি', 'danger'); document.head.appendChild(sc); }
          return;
        }
        const vid = document.createElement('video'); vid.addEventListener('error', fail); vid.controls = true; vid.setAttribute('controlsList', 'nofullscreen'); vid.setAttribute('webkit-playsinline', ''); vid.playsInline = true; vid.autoplay = true; vid.preload = 'auto'; vid.disablePictureInPicture = false; resume(vid); this.tvBindAudio(vid); vid.src = u;
        if (!/\.(mp4|webm|ogg|mov|m4v)(\?|$)/i.test(u)) vid.addEventListener('loadeddata', () => {});
        box.innerHTML = ''; box.appendChild(vid); this.tvCustomUI(box, vid);
      }
      tvYtListen(fr) {
        if (!this._tvYtBound) {
          this._tvYtBound = 1;
          window.addEventListener('message', e => {
            if (typeof e.origin !== 'string' || e.origin.indexOf('youtube') < 0) return;
            let d = e.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (_) { return; } } if (!d) return;
            const st = d.event === 'onStateChange' ? d.info : (d.event === 'infoDelivery' && d.info ? d.info.playerState : undefined);
            const main = document.querySelector('#tvPlayer iframe');
            if (st === 1 && main && e.source === main.contentWindow && document.getElementById('tvPopupLayer') && Date.now() - (this._tvPopupT || 0) > 1500) this.tvPopupClose();
          });
        }
        fr.addEventListener('load', () => { try { fr.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), '*'); } catch (_) {} });
      }
      tvCustomUI(box, v, hlsGet) {
        v.controls = false; v.removeAttribute('controls');
        const old = box.querySelector('.cp-ui'); if (old) old.remove();
        const PL = '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>', PA = '<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>';
        const ui = document.createElement('div'); ui.className = 'cp-ui';
        ui.innerHTML = '<button type="button" class="cp-center" aria-label="Play">' + PL + '</button><div class="cp-spin"></div><div class="cp-menu"></div>' +
          '<div class="cp-bar"><input class="cp-seek" type="range" min="0" max="1000" step="1" value="0" aria-label="Seek"><div class="cp-row">' +
          '<button type="button" class="cp-pp" aria-label="Play">' + PL + '</button><button type="button" class="cp-sk" data-s="-10">-10</button><button type="button" class="cp-sk" data-s="10">+10</button>' +
          '<span class="cp-time">0:00 / 0:00</span><span class="cp-gap"></span><button type="button" class="cp-sp">1x</button><button type="button" class="cp-q">Auto</button><button type="button" class="cp-cc">CC</button></div></div><input type="file" class="cp-file" accept=".srt,.vtt,text/vtt" hidden>';
        box.appendChild(ui);
        const q = s => ui.querySelector(s), seek = q('.cp-seek'), menu = q('.cp-menu'), file = q('.cp-file');
        const fmt = t => { t = Math.max(0, Math.floor(t || 0)); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s).padStart(2, '0'); };
        let drag = false, cues = [], off = 0, subUrl = '';
        const sync = () => { const p = !v.paused && !v.ended; q('.cp-pp').innerHTML = p ? PA : PL; q('.cp-center').innerHTML = p ? PA : PL; ui.classList.toggle('cp-playing', p); };
        const upd = () => { const d = v.duration || 0; if (!drag) seek.value = d ? Math.round(v.currentTime / d * 1000) : 0; seek.style.setProperty('--p', (seek.value / 10) + '%'); let b = 0; try { if (v.buffered.length) b = v.buffered.end(v.buffered.length - 1) / (d || 1) * 100; } catch (e) { } seek.style.setProperty('--b', b + '%'); q('.cp-time').textContent = fmt(v.currentTime) + ' / ' + fmt(d); };
        const toggle = () => { if (v.paused || v.ended) { const r = v.play(); if (r && r.catch) r.catch(() => { }); } else v.pause(); };
        ['play', 'pause', 'ended'].forEach(e => v.addEventListener(e, sync));
        ['timeupdate', 'loadedmetadata', 'durationchange', 'progress'].forEach(e => v.addEventListener(e, upd));
        ['waiting', 'seeking', 'stalled'].forEach(e => v.addEventListener(e, () => ui.classList.add('cp-wait')));
        ['playing', 'canplay', 'seeked', 'loadeddata'].forEach(e => v.addEventListener(e, () => ui.classList.remove('cp-wait')));
        q('.cp-pp').onclick = q('.cp-center').onclick = e => { e.stopPropagation(); toggle(); };
        ui.querySelectorAll('.cp-sk').forEach(b => b.onclick = e => { e.stopPropagation(); v.currentTime = Math.max(0, Math.min((v.duration || 1e9), v.currentTime + (+b.dataset.s))); });
        seek.addEventListener('input', () => { drag = true; const d = v.duration || 0; if (d) q('.cp-time').textContent = fmt(seek.value / 1000 * d) + ' / ' + fmt(d); seek.style.setProperty('--p', (seek.value / 10) + '%'); });
        seek.addEventListener('change', () => { const d = v.duration || 0; if (d) v.currentTime = seek.value / 1000 * d; drag = false; });
        const closeMenu = () => { menu.classList.remove('open'); menu.innerHTML = ''; menu._k = ''; };
        const openMenu = (k, items) => { if (menu._k === k) { closeMenu(); return; } menu._k = k; menu.innerHTML = items.map((it, i) => '<button type="button" class="' + (it.on ? 'on' : '') + '" data-i="' + i + '">' + it.t + '</button>').join(''); menu.classList.add('open'); menu.querySelectorAll('button').forEach(b => b.onclick = e => { e.stopPropagation(); items[+b.dataset.i].f(); closeMenu(); }); };
        q('.cp-sp').onclick = e => { e.stopPropagation(); openMenu('sp', [0.5, 0.75, 1, 1.25, 1.5, 2].map(r => ({ t: r + 'x', on: v.playbackRate === r, f: () => { v.playbackRate = r; q('.cp-sp').textContent = r + 'x'; } }))); };
        q('.cp-q').onclick = e => {
          e.stopPropagation(); const h = hlsGet ? hlsGet() : this._hls, L = h && h.levels ? h.levels : [];
          if (L.length < 2) { this.toast('এই ভিডিওতে একটাই Quality আছে', 'info'); return; }
          const it = [{ t: 'Auto', on: h.currentLevel === -1 && h.autoLevelEnabled, f: () => { h.currentLevel = -1; q('.cp-q').textContent = 'Auto'; } }];
          L.map((l, i) => ({ l, i })).sort((a, b) => (b.l.height || 0) - (a.l.height || 0)).forEach(o => { const n = o.l.height ? o.l.height + 'p' : Math.round((o.l.bitrate || 0) / 1000) + 'k'; it.push({ t: n, on: !h.autoLevelEnabled && h.currentLevel === o.i, f: () => { h.currentLevel = o.i; q('.cp-q').textContent = n; } }); });
          openMenu('q', it);
        };
        const ts = x => { const h = Math.floor(x / 3600), m = Math.floor(x % 3600 / 60), s = x % 60; return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + s.toFixed(3).padStart(6, '0'); };
        const showSub = () => {
          v.querySelectorAll('track').forEach(t => t.remove()); if (subUrl) { try { URL.revokeObjectURL(subUrl); } catch (e) { } subUrl = ''; }
          if (!cues.length) return;
          const txt = 'WEBVTT\n\n' + cues.map(c => ts(Math.max(0, c.s + off)) + ' --> ' + ts(Math.max(0, c.e + off)) + '\n' + c.t).join('\n\n');
          subUrl = URL.createObjectURL(new Blob([txt], { type: 'text/vtt' }));
          const tr = document.createElement('track'); tr.kind = 'subtitles'; tr.label = 'Subtitle'; tr.default = true; tr.src = subUrl; v.appendChild(tr);
          tr.addEventListener('load', () => { tr.track.mode = 'showing'; }); setTimeout(() => { try { tr.track.mode = 'showing'; } catch (e) { } }, 300);
        };
        const parseSub = txt => {
          const P = x => { const m = x.trim().match(/(?:(\d+):)?(\d+):(\d+)[,.](\d+)/); return m ? (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]) + (+('0.' + m[4])) : 0; };
          return txt.replace(/\r/g, '').replace(/^\uFEFF/, '').split(/\n\s*\n/).map(b => { const l = b.split('\n'), k = l.findIndex(x => x.indexOf('-->') > -1); if (k < 0) return null; const a = l[k].split('-->'); return { s: P(a[0]), e: P(a[1]), t: l.slice(k + 1).join('\n').trim() }; }).filter(c => c && c.t);
        };
        file.onchange = () => { const f = file.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { cues = parseSub(String(r.result || '')); off = 0; if (!cues.length) { this.toast('সাবটাইটেল ফাইল পড়া যায়নি', 'danger'); return; } showSub(); this.toast('সাবটাইটেল যুক্ত হয়েছে', 'success'); }; r.readAsText(f); file.value = ''; };
        q('.cp-cc').onclick = e => {
          e.stopPropagation(); const it = [{ t: 'Subtitle ফাইল দিন (.srt / .vtt)', on: false, f: () => file.click() }];
          if (cues.length) { it.push({ t: 'Sync -0.5s', f: () => { off -= 0.5; showSub(); this.toast('Sync ' + off.toFixed(1) + 's', 'info'); } }, { t: 'Sync +0.5s', f: () => { off += 0.5; showSub(); this.toast('Sync ' + off.toFixed(1) + 's', 'info'); } }, { t: 'Subtitle বন্ধ', f: () => { cues = []; showSub(); } }); }
          openMenu('cc', it);
        };
        v.addEventListener('click', closeMenu);
        if (!hlsGet) v.addEventListener('play', () => { if (document.getElementById('tvPopupLayer')) this.tvPopupClose(); }); /* Main play => Popup off */
        v.addEventListener('dblclick', e => { const r = v.getBoundingClientRect(), x = (e.clientX - r.left) / r.width; if (x < 0.35) v.currentTime = Math.max(0, v.currentTime - 10); else if (x > 0.65) v.currentTime = Math.min(v.duration || 1e9, v.currentTime + 10); else toggle(); });
        sync(); upd();
      }
      tvFsOn() { return !!(document.fullscreenElement || document.webkitFullscreenElement || this._tvPfs); }
      tvFsMark() { const w = document.getElementById('tvWrap'); if (w) w.classList.toggle('is-fs', this.tvFsOn()); }
      tvPfsRot() { const w = document.getElementById('tvWrap'); if (w) w.classList.toggle('tv-rot', this._tvRotMode !== 'port' && window.innerHeight > window.innerWidth); }
      tvPfsEnter() {
        const w = document.getElementById('tvWrap'); if (!w || this._tvPfs) return;
        this._tvPfs = true; try { history.pushState({ tvpfs: 1 }, ''); this._tvPush = true; } catch (e) { } w.classList.add('tv-pfs'); document.body.classList.add('tv-lock'); this.tvPfsRot(); this.tvFsMark();
        if (!this._tvPfsBound) { this._tvPfsBound = 1; window.addEventListener('popstate', () => { if (this._tvPfs) { this._tvPush = false; this.tvPfsExit(); } }); document.addEventListener('keydown', ev => { if (ev.key === 'Escape' && this._tvPfs) this.tvPfsExit(); }); const f = () => { if (this._tvPfs) setTimeout(() => this.tvPfsRot(), 60); }; window.addEventListener('resize', f); window.addEventListener('orientationchange', f); }
      }
      tvPfsExit() {
        if (!this._tvPfs) return; this._tvPfs = false;
        const w = document.getElementById('tvWrap'); if (w) w.classList.remove('tv-pfs', 'tv-rot');
        document.body.classList.remove('tv-lock'); this._tvRotMode = null; this.tvFsMark();
        if (this._tvPush) { this._tvPush = false; try { history.back(); } catch (e) { } }
      }
      async tvPopup() {
        const source = document.querySelector('#tvPlayer video, #tvPlayer iframe'); if (!source) { this.toast('ভিডিও player পাওয়া যায়নি', 'info'); return; }
        if (document.getElementById('tvPopupLayer')) { this.tvPopupClose(); return; }
        const layer = document.createElement('div'); layer.id = 'tvPopupLayer'; layer.className = 'tv-popup-layer';
        const win = document.createElement('div'); win.className = 'tv-popup-window';
        win.innerHTML = `<div class="tv-popup-box"></div><div class="tv-popup-head"><b>${this.tvE(document.getElementById('tvTitle')?.textContent || 'Video')}</b><button type="button" class="tv-popup-close" aria-label="Close popup" onclick="app.tvPopupClose()">×</button></div><div class="tv-popup-tools"><button type="button" aria-label="Audio language" onclick="app.tvPopupAudio()">A</button></div>`;
        const box = win.querySelector('.tv-popup-box'); layer.appendChild(win); document.body.appendChild(layer);
        this._tvPopupHls = null; this._tvPopupLayer = layer; this._tvPopupWin = win; this._tvPopupT = Date.now();
        const u = (this._tvCurrentUrl || (source.tagName === 'VIDEO' ? (source.currentSrc || source.src) : '') || '').trim();
        const t = source.tagName === 'VIDEO' ? (Number(source.currentTime) || 0) : 0;
        let media;
        if (source.tagName === 'IFRAME') {
          /* YouTube: main player-এর মতোই embed; main iframe pause করা হয় */
          try { source.contentWindow.postMessage(JSON.stringify({ event: 'command', func: 'pauseVideo', args: '' }), '*'); } catch (e) {}
          media = document.createElement('iframe'); media.src = source.src; media.setAttribute('allow', source.getAttribute('allow') || 'autoplay; encrypted-media; picture-in-picture; fullscreen'); media.setAttribute('allowfullscreen', ''); box.appendChild(media);
        } else {
          /* Main player-এর মতো একই নতুন <video> + একই custom UI (seek, play/pause, ±10s, speed, quality, CC) */
          try { source.pause(); } catch (e) {}
          media = document.createElement('video'); media.playsInline = true; media.setAttribute('webkit-playsinline', ''); media.setAttribute('controlsList', 'nofullscreen'); media.autoplay = true; media.preload = 'auto';
          media.addEventListener('loadedmetadata', () => { try { if (t > 1) media.currentTime = t; } catch (e) {} media.play().catch(() => {}); }, { once: true });
          box.appendChild(media); this.tvCustomUI(box, media, () => this._tvPopupHls);
          if (/\.m3u8(?:\?|$)/i.test(u)) {
            if (media.canPlayType('application/vnd.apple.mpegurl')) media.src = u;
            else {
              const go = () => { if (window.Hls && Hls.isSupported() && this._tvPopupMedia === media) { this._tvPopupHls = new Hls(); this._tvPopupHls.loadSource(u); this._tvPopupHls.attachMedia(media); } };
              if (window.Hls) go(); else { const sc = document.createElement('script'); sc.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.8/dist/hls.min.js'; sc.onload = go; document.head.appendChild(sc); }
            }
          } else if (u) media.src = u;
        }
        this._tvPopupMedia = media; this.tvPopupInitSeparate(win, media); this.tvPopupRestoreSeparate(win); if (window.GPX) window.GPX.attach(win);
        /* Popup hide / remove / display:none হলে ভিডিও auto বন্ধ */
        const guard = () => {
          if (!this._tvPopupWin) return;
          const w = this._tvPopupWin, L = this._tvPopupLayer;
          const gone = !document.body.contains(w) || !document.body.contains(L);
          let hidden = false;
          if (!gone) { const cs = getComputedStyle(w), cl = getComputedStyle(L); hidden = cs.display === 'none' || cs.visibility === 'hidden' || cl.display === 'none' || cl.visibility === 'hidden' || w.hidden || L.hidden; }
          if (gone || hidden) this.tvPopupClose();
        };
        if (this._tvPopupMO) this._tvPopupMO.disconnect();
        this._tvPopupMO = new MutationObserver(guard);
        this._tvPopupMO.observe(document.body, { childList: true });
        this._tvPopupMO.observe(layer, { attributes: true, attributeFilter: ['style', 'class', 'hidden'] });
        this._tvPopupMO.observe(win, { attributes: true, attributeFilter: ['style', 'hidden'] });
      }
      tvPopupInitSeparate(w, media) {
        let down = false, sx = 0, sy = 0, ox = 0, oy = 0; const h = w.querySelector('.tv-popup-head');
        h.addEventListener('pointerdown', e => { if (e.target.closest('button')) return; down = true; sx = e.clientX; sy = e.clientY; const r = w.getBoundingClientRect(); ox = r.left; oy = r.top; h.setPointerCapture?.(e.pointerId); });
        h.addEventListener('pointermove', e => { if (!down || w._pinch) return; const r = w.getBoundingClientRect(); w.style.left = Math.max(4, Math.min(innerWidth - r.width - 4, ox + e.clientX - sx)) + 'px'; w.style.top = Math.max(4, Math.min(innerHeight - r.height - 4, oy + e.clientY - sy)) + 'px'; w.style.right = 'auto'; w.style.bottom = 'auto'; });
        const end = () => { down = false; this.tvPopupSaveSeparate(w); }; h.addEventListener('pointerup', end); h.addEventListener('pointercancel', end); media.addEventListener('click', e => { if (e.detail !== 1 || w._gpxSkipClick) { w._gpxSkipClick = false; return; } w.classList.toggle('controls-hidden'); });
        new ResizeObserver(() => this.tvPopupSaveSeparate(w)).observe(w);
        /* দুই আঙুলে pinch করে বড়/ছোট */
        const ptrs = new Map(); let p0 = null;
        const dist = () => { const a = [...ptrs.values()]; return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) || 1; };
        const setSize = (k, b) => {
          let nw = Math.max(260, Math.min(innerWidth - 8, b.w * k)), nh = b.h * (nw / b.w);
          if (nh > innerHeight - 8) { nh = innerHeight - 8; nw = nh * b.w / b.h; }
          nh = Math.max(180, nh);
          w.style.width = nw + 'px'; w.style.height = nh + 'px';
          w.style.left = Math.max(4, Math.min(innerWidth - nw - 4, b.l)) + 'px'; w.style.top = Math.max(4, Math.min(innerHeight - nh - 4, b.t)) + 'px'; w.style.right = 'auto'; w.style.bottom = 'auto';
        };
        const onDown = e => { if (e.pointerType === 'mouse') return; ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (ptrs.size === 2) { const r = w.getBoundingClientRect(); p0 = { d: dist(), w: r.width, h: r.height, l: r.left, t: r.top }; w._pinch = true; w._gpxSkipClick = true; } };
        const onMove = e => { if (!ptrs.has(e.pointerId)) return; ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (ptrs.size === 2 && p0) setSize(dist() / p0.d, p0); };
        const onUp = e => { if (!ptrs.delete(e.pointerId)) return; if (ptrs.size < 2) { p0 = null; if (w._pinch) { w._pinch = false; this.tvPopupSaveSeparate(w); setTimeout(() => { w._gpxSkipClick = false; }, 350); } } };
        const onWheel = e => { if (!e.ctrlKey) return; e.preventDefault(); const r = w.getBoundingClientRect(); setSize(Math.exp(-e.deltaY * 0.01), { w: r.width, h: r.height, l: r.left, t: r.top }); };
        w.addEventListener('pointerdown', onDown, true); w.addEventListener('wheel', onWheel, { passive: false });
        document.addEventListener('pointermove', onMove); document.addEventListener('pointerup', onUp); document.addEventListener('pointercancel', onUp);
        w._cleanup = () => { document.removeEventListener('pointermove', onMove); document.removeEventListener('pointerup', onUp); document.removeEventListener('pointercancel', onUp); };
      }
      tvPopupRestoreSeparate(w) { try { const p = JSON.parse(localStorage.getItem('gghor_tv_popup') || 'null'); if (!p) return; if (p.w) w.style.width = p.w + 'px'; if (p.h) w.style.height = p.h + 'px'; if (isFinite(p.x)) { w.style.left = p.x + 'px'; w.style.right = 'auto'; } if (isFinite(p.y)) { w.style.top = p.y + 'px'; w.style.bottom = 'auto'; } } catch (e) {} }
      tvPopupSaveSeparate(w) { const r = w.getBoundingClientRect(); try { localStorage.setItem('gghor_tv_popup', JSON.stringify({ x: r.left, y: r.top, w: r.width, h: r.height })); } catch (e) {} }
      tvPopupAudio() {
        const m = this._tvPopupMedia, w = m && m.closest('.tv-popup-window'); if (!m || !w) return;
        let L = [];
        if (this._tvPopupHls?.audioTracks?.length > 1) L = this._tvPopupHls.audioTracks.map((a, i) => ({ name: this.tvAudioName(a), i, on: i === this._tvPopupHls.audioTrack }));
        else if (m.audioTracks?.length > 1) L = Array.from(m.audioTracks).map((a, i) => ({ name: this.tvAudioName(a), i, on: a.enabled }));
        if (L.length < 2) { this.toast('এই ভিডিওতে একাধিক Audio track পাওয়া যায়নি', 'info'); return; }
        let box = w.querySelector('.tv-popup-audios'); if (!box) { box = document.createElement('div'); box.className = 'tv-popup-audios'; w.appendChild(box); }
        box.innerHTML = L.map(a => `<button type="button" class="${a.on ? 'active' : ''}" onclick="app.tvPopupSetAudio(${a.i})">${this.tvE(a.name)}</button>`).join('');
      }
      tvPopupSetAudio(i) {
        const m = this._tvPopupMedia; if (this._tvPopupHls?.audioTracks?.length > i) this._tvPopupHls.audioTrack = i; else if (m?.audioTracks) Array.from(m.audioTracks).forEach((a, k) => { a.enabled = k === i; });
        const box = m?.closest('.tv-popup-window')?.querySelector('.tv-popup-audios'); if (box) box.remove();
      }
      tvPopupInit() {
        if (this._tvPopupBound) return; const w = document.getElementById('tvWrap'), h = document.getElementById('tvPopupHead'); if (!w || !h) return;
        this._tvPopupBound = true; let down = false, sx = 0, sy = 0, ox = 0, oy = 0;
        h.addEventListener('pointerdown', e => { if (e.target.closest('button')) return; down = true; sx = e.clientX; sy = e.clientY; const r = w.getBoundingClientRect(); ox = r.left; oy = r.top; h.setPointerCapture?.(e.pointerId); });
        h.addEventListener('pointermove', e => { if (!down) return; const r = w.getBoundingClientRect(); const x = Math.max(4, Math.min(window.innerWidth - r.width - 4, ox + e.clientX - sx)); const y = Math.max(4, Math.min(window.innerHeight - r.height - 4, oy + e.clientY - sy)); w.style.left = x + 'px'; w.style.top = y + 'px'; w.style.right = 'auto'; w.style.bottom = 'auto'; });
        const end = () => { if (!down) return; down = false; this.tvPopupSave(); }; h.addEventListener('pointerup', end); h.addEventListener('pointercancel', end);
        new ResizeObserver(() => { if (w.classList.contains('tv-popup-mode')) this.tvPopupSave(); }).observe(w);
      }
      tvPopupRestore() {
        const w = document.getElementById('tvWrap'); if (!w) return;
        try { const p = JSON.parse(localStorage.getItem('gghor_tv_popup') || 'null'); if (!p) return; if (p.w) w.style.width = Math.max(260, Math.min(window.innerWidth - 8, p.w)) + 'px'; if (p.h) w.style.height = Math.max(180, Math.min(window.innerHeight - 8, p.h)) + 'px'; if (isFinite(p.x)) { w.style.left = Math.max(4, Math.min(window.innerWidth - w.offsetWidth - 4, p.x)) + 'px'; w.style.right = 'auto'; } if (isFinite(p.y)) { w.style.top = Math.max(4, Math.min(window.innerHeight - w.offsetHeight - 4, p.y)) + 'px'; w.style.bottom = 'auto'; } } catch (e) { }
      }
      tvPopupSave() {
        const w = document.getElementById('tvWrap'); if (!w || !w.classList.contains('tv-popup-mode')) return; const r = w.getBoundingClientRect();
        try { localStorage.setItem('gghor_tv_popup', JSON.stringify({ x: r.left, y: r.top, w: r.width, h: r.height })); } catch (e) { }
      }
      tvPopupClose() {
        if (this._tvPopupMO) { try { this._tvPopupMO.disconnect(); } catch (e) {} this._tvPopupMO = null; }
        if (this._tvPopupWin && this._tvPopupWin._cleanup) { try { this._tvPopupWin._cleanup(); } catch (e) {} }
        const m = this._tvPopupMedia; this._tvPopupMedia = null;
        if (m) {
          try {
            if (m.tagName === 'VIDEO') { m.pause(); m.removeAttribute('src'); m.load(); }
            else if (m.tagName === 'IFRAME') { m.src = 'about:blank'; }
          } catch (e) {}
        }
        if (this._tvPopupHls) { try { this._tvPopupHls.destroy(); } catch (e) {} this._tvPopupHls = null; }
        const layer = document.getElementById('tvPopupLayer') || this._tvPopupLayer; if (layer) layer.remove();
        this._tvPopupLayer = null; this._tvPopupWin = null;
      }
      tvAudioButton() {
        const L = this.tvAudioList(), menu = document.getElementById('tvAudioMenu'), b = document.querySelector('.tv-audio-btn');
        if (!menu) return;
        if (L.length < 2) { this.toast('এই ভিডিওতে একাধিক Audio track পাওয়া যায়নি', 'info'); return; }
        menu.innerHTML = L.map((a, i) => `<button type="button" class="${a.on ? 'active' : ''}" role="menuitem" onclick="app.tvSetAudio(${i})">${this.tvE(a.name)}</button>`).join('');
        const open = !menu.classList.contains('open'); menu.classList.toggle('open', open); if (b) b.setAttribute('aria-expanded', String(open));
      }
      initPlayerGestures() { const w = document.getElementById('tvWrap'); if (w && window.GPX) window.GPX.attach(w); }
      tvRotate() {
        const w = document.getElementById('tvWrap'); if (!w) return;
        if (!this.tvFsOn()) { this.tvFs(); return; }
        const nat = !!(document.fullscreenElement || document.webkitFullscreenElement);
        const landNow = w.classList.contains('tv-rot') || window.innerWidth > window.innerHeight, target = landNow ? 'portrait' : 'landscape';
        const css = () => {
          if (nat) { this.tvPfsEnter(); try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { } }
          this._tvRotMode = target === 'landscape' ? 'land' : 'port'; this.tvPfsRot();
        };
        if (nat && screen.orientation && screen.orientation.lock) { try { screen.orientation.lock(target).catch(css); } catch (e) { css(); } } else css();
      }
      tvFs() {
        const w = document.getElementById('tvWrap'), v = document.querySelector('#tvPlayer video');
        if (document.fullscreenElement || document.webkitFullscreenElement) { try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { } try { screen.orientation.unlock(); } catch (e) { } return; }
        if (this._tvPfs) { this.tvPfsExit(); return; }
        /* native fullscreen ব্যর্থ হলে: iPhone-এ ভিডিওর নিজস্ব ফুলস্ক্রিন, না হলে পেজ-ভিত্তিক ফুলস্ক্রিন */
        const fallback = () => {
          if (this.tvFsOn()) return;
          if (v && v.webkitEnterFullscreen) { try { v.webkitEnterFullscreen(); return; } catch (e) { } }
          this.tvPfsEnter();
        };
        const req = w.requestFullscreen || w.webkitRequestFullscreen || w.mozRequestFullScreen || w.msRequestFullscreen;
        if (!req) { fallback(); return; }
        try {
          const p = req.call(w);
          if (p && p.then) p.then(() => { this.tvFsMark(); try { screen.orientation.lock('landscape').catch(() => { }); } catch (e) { } }).catch(fallback);
          else setTimeout(fallback, 400);
        } catch (e) { fallback(); }
      }
      tvStop() {
        this.tvPfsExit();
        if (document.fullscreenElement || document.webkitFullscreenElement) { try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { } }
        document.getElementById('tvPlayer').innerHTML = ''; this._tvStarted = false;
        if (this._hls) { try { this._hls.destroy(); } catch (e) { } this._hls = null; }
      }
      tvBack() {
        this.tvStop(); this._tvSeason = null; this.tvGoBack();
      }

      navigate(v) {
        if (!this.currentUser && ['orders','chat','wallet','history'].includes(v)) { this.toast('এই অংশ দেখতে লগইন করুন', 'danger'); this.openAuthModal(); return; }
        if (v === 'chat') { this.openChatPopup(); return; }
        this.currentView = v;
        this.updateBubble();
        this.updateFloatBubbles();
        document.querySelectorAll('.view-page').forEach(p => p.classList.remove('active'));
        document.getElementById(`view-${v}`)?.classList.add('active');
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        const navMap = { home: 0, magazine: 1, book: 1, season: 1, reader: 1, orders: 3, tv: 2, tvmore: 2, tvplat: 2, tvsc: 2, anime: 2, tvcat: 2, tvitem: 2, wallet: 4, account: 5, history: 5 };
        if (navMap[v] !== undefined) document.querySelectorAll('.nav-btn')[navMap[v]]?.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'auto' });
        if (v === 'tv') this.renderTv();
        if (v === 'anime') this.renderAnime();
        if (v === 'tvmore') this.renderTvMore();
        if (v === 'tvplat') this.renderTvPlat();
        if (v === 'tvsc') this.renderTvSc();
        if (v === 'history') this.renderHistory();
        if (v === 'account') { this.histBox(); this.renderWatchLater(); }
        if (v === 'magazine') requestAnimationFrame(() => this.renderMagRails());
                lucide.createIcons();
      }

      openAuthModal() { document.getElementById('userAuthModal').classList.add('active'); }
      openForgotPassword() { this.closeModal('userAuthModal'); document.getElementById('forgotPasswordModal').classList.add('active'); }
      closeModal(id) { document.getElementById(id).classList.remove('active'); }
      openMenuDrawer() { document.getElementById('menuDrawer').classList.add('active'); document.getElementById('menuDrawerOverlay').classList.add('active'); }
      closeMenuDrawer() { document.getElementById('menuDrawer').classList.remove('active'); document.getElementById('menuDrawerOverlay').classList.remove('active'); }
      openNotifications() { if (!this.currentUser) return; document.getElementById('notifDrawer').classList.add('active'); document.getElementById('notifDrawerOverlay').classList.add('active'); }
      closeNotifDrawer() { document.getElementById('notifDrawer').classList.remove('active'); document.getElementById('notifDrawerOverlay').classList.remove('active'); }

      handleAuthClick() { if (this.currentUser) this.navigate('account'); else this.openAuthModal(); }
      async submitUserAuth() {
        const e = document.getElementById('authEmailInput').value.trim();
        const p = document.getElementById('authPasswordInput').value.trim();
        try { await signInWithEmailAndPassword(auth, e, p); this.closeModal('userAuthModal'); this.toast('লগইন সফল!', 'success'); }
        catch (err) { this.toast('ভুল ইমেইল বা পাসওয়ার্ড!', 'danger'); }
      }
      /* ===== Google Sign-In (লগইন + রেজিস্টার একই) ===== */
      async ensureGoogleProfile(user) {
        const ref = doc(db, 'users', user.uid);
        let exists = true;
        try { exists = (await getDoc(ref)).exists(); } catch (e) { console.warn('profile check', e); return; }
        if (!exists) {
          await setDoc(ref, {
            displayName: user.displayName || (user.email ? user.email.split('@')[0] : 'User'),
            phone: user.phoneNumber || '',
            role: 'customer',
            email: user.email || ''
          });
        }
      }
      googleErr(e) {
        const c = String((e && e.code) || '');
        if (c === 'auth/popup-closed-by-user' || c === 'auth/cancelled-popup-request') return;
        console.error('google sign-in', e);
        let m = 'গুগল দিয়ে লগইন ব্যর্থ হয়েছে';
        if (c === 'auth/unauthorized-domain') m = 'এই ডোমেইন Firebase Authorized domains-এ যোগ করা নেই';
        else if (c === 'auth/operation-not-allowed') m = 'Firebase Console-এ Google সাইন-ইন চালু করা নেই';
        else if (c === 'auth/network-request-failed') m = 'ইন্টারনেট সংযোগ সমস্যা, আবার চেষ্টা করুন';
        else if (c === 'auth/account-exists-with-different-credential') m = 'এই ইমেইল দিয়ে আগেই অন্য পদ্ধতিতে অ্যাকাউন্ট খোলা আছে';
        this.toast(m, 'danger');
      }
      async signInWithGoogle() {
        if (!this._lock('google')) return;
        const btns = document.querySelectorAll('.google-btn');
        btns.forEach(b => b.disabled = true);
        try {
          const provider = new GoogleAuthProvider();
          provider.setCustomParameters({ prompt: 'select_account' });
          const res = await signInWithPopup(auth, provider);
          await this.ensureGoogleProfile(res.user);
          this.closeModal('userAuthModal');
          this.toast('গুগল দিয়ে লগইন সফল!', 'success');
          if (this.currentView === 'register') this.navigate('home');
        } catch (e) {
          const c = String((e && e.code) || '');
          if (c === 'auth/popup-blocked' || c === 'auth/operation-not-supported-in-this-environment') {
            try { await signInWithRedirect(auth, new GoogleAuthProvider()); return; } catch (e2) { this.googleErr(e2); }
          } else this.googleErr(e);
        } finally {
          this._unlock('google');
          btns.forEach(b => b.disabled = false);
        }
      }
      async submitForgotPassword() {
        const e = document.getElementById('forgotEmailInput').value.trim();
        if (!e) { this.toast('ইমেইল দিন', 'danger'); return; }
        try {
          await sendPasswordResetEmail(auth, e);
          this.toast('পাসওয়ার্ড রিসেট লিংক পাঠানো হয়েছে!', 'success');
          this.closeModal('forgotPasswordModal');
        } catch(err) { this.toast('লিংক পাঠানো ব্যর্থ হয়েছে', 'danger'); }
      }
      async submitRegistration() {
        const name = document.getElementById('regFullName').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const phone = document.getElementById('regPhone').value.trim();
        const pass = document.getElementById('regPassword').value.trim();
        const cpass = document.getElementById('regConfirmPassword').value.trim();

        if (pass !== cpass) { this.toast('পাসওয়ার্ড মেলেনি!', 'danger'); return; }
        try {
          const res = await createUserWithEmailAndPassword(auth, email, pass);
          await setDoc(doc(db, 'users', res.user.uid), { displayName: name, phone, role: 'customer', email });
          this.toast('অ্যাকাউন্ট তৈরি সম্পন্ন!', 'success');
          this.navigate('home');
        } catch(err) { this.toast('রেজিস্ট্রেশন ব্যর্থ হয়েছে', 'danger'); }
      }
      openProfileEditModal() {
        if (!this.currentUser) return;
        document.getElementById('editProfileName').value = this.currentUser.displayName || '';
        document.getElementById('editProfilePhone').value = this.currentUser.phone || '';
        document.getElementById('profileEditModal').classList.add('active');
      }
      async saveProfileEdit() {
        const name = document.getElementById('editProfileName').value.trim();
        const phone = document.getElementById('editProfilePhone').value.trim();
        const pass = document.getElementById('editProfilePass').value.trim();
        if (!name) { this.toast('নাম দিন', 'danger'); return; }

        await updateDoc(doc(db, 'users', this.currentUser.uid), { displayName: name, phone });
        this.currentUser.displayName = name;
        this.currentUser.phone = phone;

        if (pass) {
          try { await updatePassword(auth.currentUser, pass); } catch(err) { this.toast('পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে', 'danger'); }
        }
        this.updateUserUI();
        this.closeModal('profileEditModal');
        this.toast('প্রোফাইল আপডেট হয়েছে!', 'success');
      }
      logoutUser() { signOut(auth); this.navigate('home'); }

      toast(msg, type = 'info') {
        const root = document.getElementById('toast-container');
        const el = document.createElement('div');
        el.className = 'toast t-' + type;
        el.innerHTML = `<span>${msg}</span>`;
        root.appendChild(el);
        setTimeout(() => el.remove(), 3000);
      }
    }

    window.app = new UserClientApp();
    window.addEventListener('unhandledrejection', ev => {
      try {
        const now = Date.now(); if (window.__lastRej && now - window.__lastRej < 3000) return; window.__lastRej = now;
        console.error('Unhandled:', ev.reason);
        window.app.toast(window.app._errMsg(ev.reason), 'danger');
      } catch (e) {}
    });
    (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', () => window.app.init()) : (() => window.app.init())());
