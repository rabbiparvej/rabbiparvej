      /* GPX: swipe brightness (left) + swipe volume (right) for every <video> player; works offline */
      window.GPX = (function () {
        var KB = 'gghor_gpx_bright', level = 60;
        try { var sv = localStorage.getItem(KB); if (sv !== null && sv !== '' && isFinite(Number(sv))) level = Math.min(100, Math.max(0, Number(sv))); } catch (e) {}
        function factor(l) { return 0.25 + (l / 100) * 1.25; }
        function apply() { var f = factor(level); document.documentElement.style.setProperty('--gpx-b', f.toFixed(3)); document.documentElement.classList.toggle('gpx-on', Math.abs(f - 1) > 0.02); }
        apply();
        function clamp(n) { return Math.max(0, Math.min(100, n)); }
        function attach(wrap) {
          if (!wrap || wrap._gpx) return; wrap._gpx = 1; wrap.classList.add('gpx-w');
          var hud = document.createElement('div'); hud.className = 'gpx-hud'; hud.innerHTML = '<span class="gpx-ic"></span><span class="gpx-bar"><i></i></span><b></b>'; wrap.appendChild(hud);
          var ic = hud.children[0], bar = hud.children[1].firstChild, txt = hud.children[2], ht = 0, st = null;
          function show(kind, val) { ic.textContent = kind === 'b' ? '☀' : (val <= 0 ? '🔇' : val < 50 ? '🔉' : '🔊'); bar.style.width = val + '%'; txt.textContent = Math.round(val) + '%'; hud.classList.add('on'); clearTimeout(ht); ht = setTimeout(function () { hud.classList.remove('on'); }, 900); }
          function showSeek(v) { var d = Number(v.duration) || 0, c = Number(v.currentTime) || 0, p = d ? c / d * 100 : 0; ic.textContent = '↔'; bar.style.width = Math.max(0, Math.min(100, p)) + '%'; txt.textContent = (c < 0 ? 0 : Math.floor(c / 60) + ':' + String(Math.floor(c % 60)).padStart(2, '0')) + ' / ' + (d ? Math.floor(d / 60) + ':' + String(Math.floor(d % 60)).padStart(2, '0') : '--:--'); hud.classList.add('on'); clearTimeout(ht); ht = setTimeout(function () { hud.classList.remove('on'); }, 900); }
          function vid() { return wrap.querySelector('video'); }
          function geo(t) {
            if (wrap.classList.contains('tv-rot') || wrap.classList.contains('nol-rot') || wrap.closest('.nol-rot')) return { x: t.clientY, y: window.innerWidth - t.clientX, W: window.innerHeight, H: window.innerWidth };
            var r = wrap.getBoundingClientRect(); return { x: t.clientX - r.left, y: t.clientY - r.top, W: r.width, H: r.height };
          }
          wrap.addEventListener('touchstart', function (e) {
            st = null; if (e.touches.length !== 1) return;
            var v = vid(); if (!v) return;
            if (e.target.closest && e.target.closest('button,a,input,select')) return;
            var g = geo(e.touches[0]);
            if (g.y < 44 || g.y > g.H - 64 || g.x < 20 || g.x > g.W - 20) return;
            var right = g.x > g.W / 2;
            st = { x: g.x, y: g.y, W: g.W, H: g.H, right: right, mode: 0, base: right ? Math.round((v.muted ? 0 : v.volume) * 100) : level, time: Number(v.currentTime) || 0 };
          }, { passive: true });
          wrap.addEventListener('touchmove', function (e) {
            if (!st || e.touches.length !== 1) return;
            var g = geo(e.touches[0]), dx = g.x - st.x, dy = g.y - st.y;
            if (!st.mode) { if (Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx) * 1.2) st.mode = 1; else if (Math.abs(dx) > 14) st.mode = 2; else return; }
            if (e.cancelable) e.preventDefault();
            if (st.mode === 2) { var sv = vid(), dur = Number(sv && sv.duration) || 0; if (!sv || !dur) return; sv.currentTime = Math.max(0, Math.min(dur, st.time + (dx / st.W) * dur)); showSeek(sv); return; }
            var val = clamp(st.base + (-dy / (st.H * 0.75)) * 100);
            if (st.right) { var v = vid(); if (!v) return; v.muted = val <= 0; if (val > 0) v.volume = val / 100; show('v', val); }
            else { level = val; apply(); show('b', val); }
          }, { passive: false });
          function end() { if (st && st.mode === 2) { wrap._gpxSkipClick = true; setTimeout(function () { wrap._gpxSkipClick = false; }, 80); } if (st && st.mode && st.mode !== 2 && !st.right) { try { localStorage.setItem(KB, String(Math.round(level))); } catch (e) {} } st = null; }
          wrap.addEventListener('touchend', end, { passive: true }); wrap.addEventListener('touchcancel', end, { passive: true });

          /* ---- v26 player upgrades: double-tap seek, speed, buffering spinner, error retry, keyboard ---- */
          var spd = document.createElement('button'); spd.type = 'button'; spd.className = 'gpx-spd'; spd.textContent = '1x'; wrap.appendChild(spd);
          var spin = document.createElement('div'); spin.className = 'gpx-spin'; wrap.appendChild(spin);
          var sl = document.createElement('div'); sl.className = 'gpx-skip l'; sl.innerHTML = '⏪<br>10s'; var sr = document.createElement('div'); sr.className = 'gpx-skip r'; sr.innerHTML = '⏩<br>10s'; wrap.appendChild(sl); wrap.appendChild(sr);
          var er = document.createElement('div'); er.className = 'gpx-err'; er.innerHTML = '<span>ভিডিও চালানো যায়নি। Internet / লিংক চেক করুন।</span><button type="button">আবার চেষ্টা করুন</button>'; wrap.appendChild(er);
          var rates = [1, 1.25, 1.5, 2, 0.75], ri = 0, ut = 0;
          function ui() { wrap.classList.add('gpx-ui'); clearTimeout(ut); ut = setTimeout(function () { wrap.classList.remove('gpx-ui'); }, 3500); }
          wrap.addEventListener('touchstart', ui, { passive: true }); wrap.addEventListener('mousemove', ui);
          spd.addEventListener('click', function (e) { e.stopPropagation(); ri = (ri + 1) % rates.length; var v = vid(); if (v) v.playbackRate = rates[ri]; spd.textContent = rates[ri] + 'x'; ui(); });
          function setWait(on) { wrap.classList.toggle('gpx-wait', !!on); }
          ['waiting', 'loadstart', 'seeking', 'stalled'].forEach(function (n) { wrap.addEventListener(n, function () { setWait(1); wrap.classList.remove('gpx-bad'); }, true); });
          ['playing', 'canplay', 'seeked', 'pause'].forEach(function (n) { wrap.addEventListener(n, function () { setWait(0); }, true); });
          wrap.addEventListener('loadedmetadata', function (e) { var v = e.target; if (v && v.tagName === 'VIDEO') v.playbackRate = rates[ri]; }, true);
          wrap.addEventListener('error', function (e) { if (e.target && e.target.tagName === 'VIDEO' && e.target.error) { setWait(0); wrap.classList.add('gpx-bad'); } }, true);
          er.lastChild.addEventListener('click', function (e) { e.stopPropagation(); var v = vid(); wrap.classList.remove('gpx-bad'); if (v) { var t = v.currentTime; v.load(); v.addEventListener('loadedmetadata', function () { try { v.currentTime = t; } catch (x) {} v.play().catch(function () {}); }, { once: true }); } });
          function skip(dir) { var v = vid(); if (!v) return; var d = Number(v.duration) || 0; v.currentTime = Math.max(0, Math.min(d || 1e9, (Number(v.currentTime) || 0) + dir * 10)); var el = dir < 0 ? sl : sr; el.classList.add('on'); setTimeout(function () { el.classList.remove('on'); }, 450); }
          var lt = 0, lx = 0, sx = 0, sy = 0;
          wrap.addEventListener('touchstart', function (e) { if (e.touches.length === 1) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; } }, { passive: true });
          wrap.addEventListener('touchend', function (e) {
            var t = e.changedTouches[0]; if (!t || Math.abs(t.clientX - sx) > 12 || Math.abs(t.clientY - sy) > 12) return;
            if (e.target.closest && e.target.closest('button,a,input,select')) return;
            var g = geo(t); if (g.y < 44 || g.y > g.H - 64) return;
            var now = Date.now(), zone = g.x < g.W * 0.4 ? -1 : g.x > g.W * 0.6 ? 1 : 0;
            if (zone && now - lt < 320 && Math.abs(t.clientX - lx) < 120) { skip(zone); lt = 0; wrap._gpxSkipClick = true; setTimeout(function () { wrap._gpxSkipClick = false; }, 120); if (e.cancelable) e.preventDefault(); } else { lt = now; lx = t.clientX; }
          }, { passive: false });
          wrap.tabIndex = -1;
          document.addEventListener('keydown', function (e) {
            var v = vid(); if (!v || !v.offsetParent || /INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '')) return;
            var k = e.key;
            if (k === 'ArrowRight') skip(1); else if (k === 'ArrowLeft') skip(-1);
            else if (k === 'ArrowUp') v.volume = Math.min(1, v.volume + .1); else if (k === 'ArrowDown') v.volume = Math.max(0, v.volume - .1);
            else if (k === 'm' || k === 'M') v.muted = !v.muted; else if (k === ' ' || k === 'k' || k === 'K') { v.paused ? v.play() : v.pause(); } else return;
            e.preventDefault();
          });
        }
        return { attach: attach };
      })();
