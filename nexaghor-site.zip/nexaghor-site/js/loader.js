/* NexaGHOR loader: pages/*.html লোড করে <main id="pages">-এ বসায়, তারপর JS ফাইলগুলো ক্রমানুযায়ী চালায় */
(function () {
  var PAGES = ['home', 'product-items', 'item-packages', 'notif-detail', 'checkout', 'magazine', 'book', 'season', 'reader', 'orders', 'wallet', 'tv', 'tvsc', 'tvplat', 'tvmore', 'history', 'anime', 'tvcat', 'tvitem', 'account', 'register'];
  var SCRIPTS = [
    { src: 'https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js' },
    { src: 'js/config.js' },
    { src: 'js/gpx.js' },
    { src: 'js/password-toggle.js' },
    { src: 'js/translations.js' },
    { src: 'js/app.js', module: true }
  ];
  function loadScript(o) {
    return new Promise(function (ok, no) {
      var s = document.createElement('script');
      if (o.module) s.type = 'module';
      s.src = o.src; s.onload = ok; s.onerror = function () { no(new Error('Script load failed: ' + o.src)); };
      document.body.appendChild(s);
    });
  }
  Promise.all(PAGES.map(function (p) {
    return fetch('pages/' + p + '.html').then(function (r) { if (!r.ok) throw new Error('Page load failed: ' + p); return r.text(); });
  })).then(function (parts) {
    document.getElementById('pages').innerHTML = parts.join('\n');
    return SCRIPTS.reduce(function (pr, o) { return pr.then(function () { return loadScript(o); }); }, Promise.resolve());
  }).catch(function (e) {
    console.error(e);
    document.body.insertAdjacentHTML('afterbegin', '<div style="padding:20px;font:14px sans-serif">লোড করা যায়নি — পেজ রিফ্রেশ করুন। (' + e.message + ')</div>');
  });
})();
