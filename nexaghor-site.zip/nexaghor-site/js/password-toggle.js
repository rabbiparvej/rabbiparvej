    (function () {
      var EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
      var EYE_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
      function enhance(inp) {
        if (!inp || inp.getAttribute('data-pw-eye')) return;
        inp.setAttribute('data-pw-eye', '1');
        var parent = inp.parentNode;
        if (!parent) return;
        var wrap = document.createElement('div');
        wrap.className = 'pw-wrap';
        parent.insertBefore(wrap, inp);
        wrap.appendChild(inp);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pw-eye';
        btn.tabIndex = -1;
        btn.innerHTML = EYE_OFF;
        wrap.appendChild(btn);
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          var show = inp.type === 'password';
          inp.type = show ? 'text' : 'password';
          btn.innerHTML = show ? EYE : EYE_OFF;
        });
      }
      function scan() { document.querySelectorAll('input[type="password"]:not([data-pw-eye])').forEach(enhance); }
      scan();
      (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', scan) : (scan)());
      new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
    })();
