try{var __t=localStorage.getItem("gghor_theme");if(__t){document.documentElement.setAttribute("data-theme",__t);}}catch(e){}
